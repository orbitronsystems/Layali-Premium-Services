import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DemoHeader } from './components/common/DemoHeader';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { Toast } from './components/common/Toast';
import { HeroSection } from './components/public/HeroSection';
import { PinterestFeed } from './components/pinterest/PinterestFeed';
import { WorkspacePreviewSection } from './components/public/WorkspacePreviewSection';
import { InspirationSection } from './components/public/InspirationSection';
import { CustomerWorkspace } from './components/workspace/CustomerWorkspace';
import { VendorDashboard } from './components/vendor/VendorDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { PinDetailModal } from './components/pinterest/PinDetailModal';
import { VendorDetailModal } from './components/modals/VendorDetailModal';
import { InquiryModal } from './components/modals/InquiryModal';
import { EventWizardModal } from './components/modals/EventWizardModal';
import { SaveToCollectionModal } from './components/collections/SaveToCollectionModal';
import { CollectionsView } from './components/collections/CollectionsView';
import { EventOnboardingModal } from './components/onboarding/EventOnboardingModal';
import { CategoryLandingPage } from './components/categories/CategoryLandingPage';
import { MobileBottomNav } from './components/navigation/MobileBottomNav';
import { SponsorsShowcaseBar } from './components/sponsors/SponsorsShowcaseBar';
import { PayPalCheckoutModal } from './components/sponsors/PayPalCheckoutModal';
import { PayPalEscrowDashboard } from './components/sponsors/PayPalEscrowDashboard';
import { BryntumRunOfShow } from './components/sponsors/BryntumRunOfShow';
import { ZapierAutomationHub } from './components/sponsors/ZapierAutomationHub';
import { PostmanApiExplorer } from './components/sponsors/PostmanApiExplorer';

const AppContent: React.FC = () => {
  const { role, currentView, setFeedCategoryFilter } = useApp();

  const handleHeroSearch = (query: string, category: string, city: string) => {
    if (category !== 'all') {
      setFeedCategoryFilter(category);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F4] text-[#242320]">
      {/* 1. Client Presentation Helper Bar */}
      <DemoHeader />

      {/* 1.5 Hackathon Sponsor Suite Quick Launch Bar */}
      <SponsorsShowcaseBar />

      {/* 2. Top Navigation Bar */}
      <Navbar />

      {/* 3. Main Body based on Role & Current View */}
      <main className="flex-1 pb-16 md:pb-0">
        {role === 'vendor' ? (
          <VendorDashboard />
        ) : role === 'admin' ? (
          <AdminDashboard />
        ) : (
          /* Customer Experience & Sponsor Showcases */
          <>
            {currentView === 'home' && (
              <>
                <HeroSection onSearchChange={handleHeroSearch} />
                {/* Pinterest Style Visual Feed with Albums & Direct Vendor Contact */}
                <PinterestFeed />
                <WorkspacePreviewSection />
                <InspirationSection />
              </>
            )}

            {currentView === 'discovery' && (
              <PinterestFeed />
            )}

            {currentView === 'collections' && (
              <CollectionsView />
            )}

            {currentView === 'category' && (
              <CategoryLandingPage />
            )}

            {currentView === 'paypal_escrow' && (
              <PayPalEscrowDashboard />
            )}

            {currentView === 'bryntum_timeline' && (
              <BryntumRunOfShow />
            )}

            {currentView === 'zapier_automations' && (
              <ZapierAutomationHub />
            )}

            {currentView === 'postman_api' && (
              <PostmanApiExplorer />
            )}

            {(currentView === 'workspace' || currentView === 'inquiries') && (
              <CustomerWorkspace />
            )}
          </>
        )}
      </main>

      {/* 4. Refined Editorial Footer */}
      <Footer />

      {/* 5. Mobile Thumb Navigation Bar */}
      <MobileBottomNav />

      {/* 6. Modals & Notifications */}
      <PinDetailModal />
      <VendorDetailModal />
      <InquiryModal />
      <EventWizardModal />
      <SaveToCollectionModal />
      <EventOnboardingModal />
      <PayPalCheckoutModal />
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
