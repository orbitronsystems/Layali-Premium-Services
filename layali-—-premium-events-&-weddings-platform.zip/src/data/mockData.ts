import { 
  Vendor, 
  EventModel, 
  EventChecklistItem, 
  EventExpense, 
  BookingInquiry, 
  PinItem, 
  CollectionItem,
  TaxonomyGroup,
  PayPalTransaction,
  BryntumScheduleItem,
  ZapierZap,
  ZapierExecutionLog
} from '../types';

import heroImg from '../assets/images/hero_wedding_reception_1793122952905.jpg';
import venueImg from '../assets/images/venue_citadel_palace_1793122954208.jpg';
import tableImg from '../assets/images/table_floral_styling_1793122954527.jpg';
import bridalImg from '../assets/images/bridal_details_styling_1793122954212.jpg';
import lightingImg from '../assets/images/lighting_fx_wedding_1793203043959.jpg';
import bellyDancerImg from '../assets/images/belly_dancer_zaffah_1793203045275.jpg';
import hostingImg from '../assets/images/vip_hosting_ushers_1793203046270.jpg';
import eventManagementImg from '../assets/images/event_management_gala_1793203046044.jpg';
import birthdayImg from '../assets/images/birthday_party_decor_1793204819609.jpg';
import djImg from '../assets/images/dj_entertainment_wedding_1793204819800.jpg';

export const HERO_IMAGE = heroImg;
export const VENUE_IMAGE = venueImg;
export const TABLE_IMAGE = tableImg;
export const BRIDAL_IMAGE = bridalImg;
export const LIGHTING_IMAGE = lightingImg;
export const BELLY_DANCER_IMAGE = bellyDancerImg;
export const HOSTING_IMAGE = hostingImg;
export const EVENT_MANAGEMENT_IMAGE = eventManagementImg;
export const BIRTHDAY_IMAGE = birthdayImg;
export const DJ_IMAGE = djImg;

// The 8 Master Taxonomy Groups (Section 8 of Master Build Prompt)
export const TAXONOMY_GROUPS: TaxonomyGroup[] = [
  {
    id: 'venues_planning',
    title: 'Venues & Event Planning',
    titleAr: 'القاعات وتنظيم الفعاليات',
    description: 'Palaces, Nile ballrooms, outdoor gardens, beach resorts, and luxury planners.',
    descriptionAr: 'القصور، القاعات النيلية، الحدائق المفتوحة، المنتجعات الشاطئية، وأرقى منظمي الحفلات.',
    iconName: 'Building2',
    categories: [
      { id: 'venues', name: 'Wedding Venues & Ballrooms', nameAr: 'قاعات وأماكن الأفراح' },
      { id: 'wedding_planners', name: 'Wedding & Event Planners', nameAr: 'منظمو حفلات الزفاف' }
    ]
  },
  {
    id: 'decor_styling',
    title: 'Décor, Florals & Styling',
    titleAr: 'الديكور والزهور وتنسيق المسارح',
    description: 'Custom kosha staging, floral architecture, tablescapes, and balloon art.',
    descriptionAr: 'تصميم الكوشة والمسارح، هندسة الزهور، تنسيق الطاولات، وفنون البالونات.',
    iconName: 'Sparkles',
    categories: [
      { id: 'floral_decor', name: 'Floral Designers & Kosha', nameAr: 'تصميم الزهور والكوشة' },
      { id: 'party_decor', name: 'Themed Décor & Balloon Art', nameAr: 'ديكورات المناسبات والبالونات' }
    ]
  },
  {
    id: 'entertainment_performers',
    title: 'Entertainment & Performers',
    titleAr: 'العروض والترفيه والفرق الفنية',
    description: 'Celebrity DJs, live bands, oriental belly dancers, and traditional zaffah troupes.',
    descriptionAr: 'الدي جي، الفرق الموسيقية الحية، الراقصات الشرقيات، وفرق الزفة المصرية الأصيلة.',
    iconName: 'Music',
    categories: [
      { id: 'dj_sound', name: 'DJs & Live Performers', nameAr: 'الدي جي والعازفون الحيون' },
      { id: 'belly_dancers', name: 'Belly Dancers & Zaffah', nameAr: 'الراقصات والزفة التراثية' }
    ]
  },
  {
    id: 'production_technical',
    title: 'Production & Technical Services',
    titleAr: 'الإنتاج الفني وهندسة المسارح والإضاءة',
    description: 'Intelligent lighting design, concert sound systems, LED screens, and special FX.',
    descriptionAr: 'هندسة الإضاءة الذكية، أنظمة الصوت الكبرى، شاشات العرض، والمؤثرات البصرية.',
    iconName: 'Zap',
    categories: [
      { id: 'lighting_fx', name: 'Lighting Design & FX', nameAr: 'هندسة الإضاءة والمؤثرات' },
      { id: 'event_management', name: 'Mega Event Production', nameAr: 'إدارة وإنتاج الفعاليات الكبرى' }
    ]
  },
  {
    id: 'photography_media',
    title: 'Photography & Cinema',
    titleAr: 'التصوير الفوتوغرافي والسينمائي',
    description: 'Fine-art wedding photography, 4K documentary films, and aerial drone coverage.',
    descriptionAr: 'التوثيق الفوتوغرافي الفاخر، الأفلام السينمائية بدقة 4K، والتصوير الجوي.',
    iconName: 'Camera',
    categories: [
      { id: 'photography', name: 'Wedding & Event Photography', nameAr: 'تصوير الأفراح والفعاليات' }
    ]
  },
  {
    id: 'food_hospitality',
    title: 'Food, Catering & Hospitality',
    titleAr: 'الضيافة والبوفيه والحلويات',
    description: 'Gourmet wedding buffets, 5-tier wedding cakes, live cooking stations, and dessert galleries.',
    descriptionAr: 'بوفيهات العشاء الفاخرة، كعكات الزفاف متعددة الأدوار، ومحطات الحلويات الملكية.',
    iconName: 'Utensils',
    categories: [
      { id: 'catering', name: 'Haute Catering & Wedding Cakes', nameAr: 'الضيافة وبوفيهات الحلويات' }
    ]
  },
  {
    id: 'beauty_fashion',
    title: 'Beauty, Bridal & Fashion',
    titleAr: 'أزياء العرائس والبدلات والتجميل',
    description: 'Bespoke bridal couture gowns, custom French lace veils, tuxedos, and bridal glam.',
    descriptionAr: 'فساتين الزفاف الراقية، الطرحات المطرزة يدوياً، البدلات الرجالية، وتجهيز العروس.',
    iconName: 'Crown',
    categories: [
      { id: 'bridal_beauty', name: 'Bridal Couture & Styling', nameAr: 'أزياء العرائس والجمال' }
    ]
  },
  {
    id: 'rentals_logistics',
    title: 'Rentals, Ushers & Logistics',
    titleAr: 'المراسم والاستقبال واللوجستيات',
    description: 'VIP hostesses, digital QR registration, luxury seating, and guest coordination.',
    descriptionAr: 'فريق مضيفات كبار الشخصيات، الدخول الذكي بالباركود، وتنسيق استقبال المعازيم.',
    iconName: 'Users',
    categories: [
      { id: 'hosting_ushers', name: 'VIP Hostesses & Ushering', nameAr: 'مضيفات كبار الشخصيات والمراسم' }
    ]
  }
];

// Starter Collections / Boards (Section 11 of Master Build Prompt)
export const INITIAL_COLLECTIONS: CollectionItem[] = [
  {
    id: 'col-my-wedding',
    name: 'My Wedding',
    nameAr: 'حفل زفافي',
    description: 'Core inspiration, ceremony moodboards, and selected styles.',
    descriptionAr: 'لوحة الأفكار الأساسية ومراسم حفل الزفاف.',
    pinIds: ['pin-palais-ballroom', 'pin-tablescape-runner', 'pin-lighting-arch'],
    coverImageUrl: VENUE_IMAGE,
    createdAt: '2026-10-20'
  },
  {
    id: 'col-venue-ideas',
    name: 'Venue Ideas',
    nameAr: 'أفكار القاعات والقصور',
    description: 'Waterfront palaces, glasshouses, and historic architectural spaces.',
    descriptionAr: 'قصور النيل والقاعات التاريخية الفسيحة في مصر.',
    pinIds: ['pin-palais-ballroom', 'pin-nile-sunset-view'],
    coverImageUrl: HERO_IMAGE,
    createdAt: '2026-10-21'
  },
  {
    id: 'col-decor-flowers',
    name: 'Décor and Flowers',
    nameAr: 'الديكور والزهور',
    description: 'Candlelit tablescapes, organic greenery, and Kosha floral runners.',
    descriptionAr: 'تنسيقات الشموع الدافئة وممرات الزهور الطبيعية.',
    pinIds: ['pin-tablescape-runner', 'pin-birthday-garden'],
    coverImageUrl: TABLE_IMAGE,
    createdAt: '2026-10-22'
  },
  {
    id: 'col-lighting-stage',
    name: 'Lighting and Stage',
    nameAr: 'الإضاءة وهندسة المسرح',
    description: 'Warm fairy canopies, laser mapping, and high-impact concert staging.',
    descriptionAr: 'أسقف النجوم المضيئة والمؤثرات البصرية للمسرح.',
    pinIds: ['pin-lighting-arch', 'pin-pyramids-gala', 'pin-dj-percussion'],
    coverImageUrl: LIGHTING_IMAGE,
    createdAt: '2026-10-23'
  },
  {
    id: 'col-photography',
    name: 'Photography',
    nameAr: 'التصوير السينمائي',
    description: 'Raw emotion, sunset portraits, and fine-art editorial composition.',
    descriptionAr: 'اللقطات التوثيقية التذكارية والأفلام السينمائية.',
    pinIds: ['pin-nile-sunset-view', 'pin-bridal-calligraphy'],
    coverImageUrl: HERO_IMAGE,
    createdAt: '2026-10-24'
  },
  {
    id: 'col-birthday-ideas',
    name: 'Birthday & Private Parties',
    nameAr: 'أعياد الميلاد والحفلات الخاصة',
    description: 'Pastel balloon arches, custom three-tier cakes, and garden celebrations.',
    descriptionAr: 'تنسيقات البالونات الفاخرة وكعكات أعياد الميلاد في الحدائق.',
    pinIds: ['pin-birthday-garden', 'pin-dj-percussion'],
    coverImageUrl: BIRTHDAY_IMAGE,
    createdAt: '2026-10-25'
  },
  {
    id: 'col-corporate-event',
    name: 'Corporate Galas & Productions',
    nameAr: 'الفعاليات المؤسسية الكبرى',
    description: 'Mega stages, international delegations, Pyramids galas, and VIP protocols.',
    descriptionAr: 'المسارح العملاقة واستقبال الوفود وكبار الشخصيات أمام الأهرامات.',
    pinIds: ['pin-pyramids-gala', 'pin-vip-hostesses'],
    coverImageUrl: EVENT_MANAGEMENT_IMAGE,
    createdAt: '2026-10-26'
  }
];

export const INITIAL_VENDORS: Vendor[] = [
  {
    id: 'vendor-palais-du-nil',
    name: 'Palais du Nil Grand Ballroom & Gardens',
    nameAr: 'قصر النيل — القاعة الملكية والحدائق',
    category: 'venues',
    city: 'Cairo',
    cityAr: 'القاهرة',
    neighborhood: 'Zamalek, Cairo',
    neighborhoodAr: 'الزمالك، القاهرة',
    phone: '+20 100 234 5678',
    email: 'events@palaisdunil.com.eg',
    whatsapp: '+201002345678',
    instagram: '@palaisdunil.events',
    startingPriceEgp: 320000,
    coverImage: VENUE_IMAGE,
    galleryImages: [VENUE_IMAGE, HERO_IMAGE, TABLE_IMAGE],
    description: 'An iconic historic palace overlooking the majestic Nile River in Zamalek, featuring imperial arabesque archways, crystal chandeliers, and expansive manicured private lawns.',
    descriptionAr: 'قصر تاريخي عريق يطل مباشرة على ضفاف النيل بالزمالك، يتميز بأقواس أرابيسك شاهقة وثريات كريستال وحدائق خاصة شاسعة للأفراح الفاخرة.',
    rating: 4.95,
    reviewsCount: 38,
    featured: true,
    status: 'active',
    capacity: '200 – 600 Guests',
    eventTypes: ['wedding', 'engagement', 'corporate_gala'],
    packages: [
      {
        id: 'pkg-palais-classic',
        name: 'The Royal Nile Celebration',
        nameAr: 'الباقة الملكية النيلية',
        priceEgp: 380000,
        description: 'Complete ballroom rental, banquet table setups, state-of-the-art intelligent lighting, and bridal suite.',
        descriptionAr: 'حجز القاعة بالكامل مع تجهيز طاولات الوليمة، إضاءة سينمائية متطورة وجناح خاص للعروسين.',
        features: ['Full Nile View Terrace', 'Crystal Chandelier Lighting', 'Private Bridal Suite', 'Dedicated Event Concierge'],
        featuresAr: ['تراس كامل بإطلالة على النيل', 'إضاءة ثريات الكريستال', 'جناح خاص للعروس', 'منسق خدمة مخصص للحدث']
      }
    ],
    reviews: []
  },
  {
    id: 'vendor-lumina-lighting',
    name: 'Lumina Architectural Lighting & Special FX',
    nameAr: 'لومينا لهندسة الإضاءة والمؤثرات البصرية',
    category: 'lighting_fx',
    city: 'Sheikh Zayed',
    cityAr: 'الشيخ زايد',
    neighborhood: 'Beverly Hills & 6th of October',
    neighborhoodAr: 'بيفرلي هيلز والسادس من أكتوبر',
    phone: '+20 101 987 6543',
    email: 'info@luminalighting.eg',
    whatsapp: '+201019876543',
    instagram: '@lumina.lighting.egypt',
    startingPriceEgp: 85000,
    coverImage: LIGHTING_IMAGE,
    galleryImages: [LIGHTING_IMAGE, VENUE_IMAGE, HERO_IMAGE],
    description: 'Premier architectural illumination, intelligent moving beams, 3D video mapping, fairy-light canopies, and cold spark pyrotechnics for Egyptian luxury events.',
    descriptionAr: 'أحدث أنظمة الإضاءة المعمارية الذكية، أجهزة الليزر والمابينج ثلاثي الأبعاد، أسقف الإضاءة الخيالية والألعاب النارية الباردة الآمنة.',
    rating: 4.96,
    reviewsCount: 42,
    featured: true,
    status: 'active',
    capacity: 'Up to 2,000 Guests Staging',
    eventTypes: ['wedding', 'engagement', 'birthday', 'corporate_gala', 'private_party'],
    packages: [
      {
        id: 'pkg-lumina-grand',
        name: 'The Grand Starlight Symphony',
        nameAr: 'باقة سماء النجوم والإضاءة المعمارية',
        priceEgp: 120000,
        description: 'Overhead fairy-light canopy of 10,000 warm micro-bulbs, 16 beam moving heads, and synchronized entrance spotlighting.',
        descriptionAr: 'سقف إضاءة ساحر يضم ١٠ آلاف مصباح دافئ، ١٦ وحدة إضاءة متحركة وإضاءة سينمائية لدخول العروسين.',
        features: ['10,000 Warm Micro-lights', '16 Moving Beam Heads', 'Laser Mapping Projections', 'On-site Light Engineer Team'],
        featuresAr: ['سقف مضيء متكامل', '١٦ كشاف إضاءة متحرك', 'عروض ليزر وإسقاط ضوئي', 'طاقم مهندسي إضاءة طوال الحفل']
      }
    ],
    reviews: []
  },
  {
    id: 'vendor-amira-bellydance',
    name: 'Amira & Royal Egyptian Zaffah Troupe',
    nameAr: 'أميرة وفرقة الزفة والاستعراضات الشرقية الملكية',
    category: 'belly_dancers',
    city: 'Cairo',
    cityAr: 'القاهرة',
    neighborhood: 'Heliopolis & Zamalek',
    neighborhoodAr: 'مصر الجديدة والزمالك',
    phone: '+20 114 555 1234',
    email: 'booking@amirashow.eg',
    whatsapp: '+201145551234',
    instagram: '@amira.bellydance.official',
    startingPriceEgp: 45000,
    coverImage: BELLY_DANCER_IMAGE,
    galleryImages: [BELLY_DANCER_IMAGE, HERO_IMAGE],
    description: 'Internationally acclaimed classical oriental belly dance soloist accompanied by authentic Egyptian folkloric tabla masters, shamadan candle balancing, and full zaffah ensemble.',
    descriptionAr: 'نجمة الاستعراض الشرقي الكلاسيكي مع فرقة الطبول التراثية وزفة الشمعدان الملكية لتقديم أرقى العروض الفنية التي تبهج ضيوف الحفل.',
    rating: 4.98,
    reviewsCount: 65,
    featured: true,
    status: 'active',
    capacity: '20-Performer Troupe',
    eventTypes: ['wedding', 'engagement', 'birthday', 'cultural_celebration'],
    packages: [
      {
        id: 'pkg-amira-royal',
        name: 'The Imperial Shamadan & Solo Performance',
        nameAr: 'العرض الملكي لزفة الشمعدان والاستعراض الشرقي',
        priceEgp: 65000,
        description: 'Grand entrance zaffah with golden shamadan candle balance, 45-minute live orchestral solo show with bespoke costume change.',
        descriptionAr: 'زفة الشمعدان التراثية الفاخرة مع عرض استعراضي مدته ٤٥ دقيقة مع تبديل أزياء صممت خصيصاً للحفل.',
        features: ['Shamadan Candle Entrance', '12 Master Percussionists', 'Bespoke Silk Costumes', 'Live Mizmar & Nay Ensemble'],
        featuresAr: ['استعراض الشمعدان المصري', '١٢ عازف إيقاع محترف', 'أزياء حريرية مطرزة', 'تخت شرقي ومزمار بلدي']
      }
    ],
    reviews: []
  },
  {
    id: 'vendor-dj-ramy',
    name: 'DJ Ramy & Live Percussion Fusion Egypt',
    nameAr: 'دي جي رامي وعازف الإيقاع الحي',
    category: 'dj_sound',
    city: 'New Cairo',
    cityAr: 'القاهرة الجديدة',
    neighborhood: 'Tagamoa & Zamalek',
    neighborhoodAr: 'التجمع والزمالك',
    phone: '+20 102 999 4411',
    email: 'bookings@djramy.eg',
    whatsapp: '+201029994411',
    instagram: '@djramy.percussion',
    startingPriceEgp: 38000,
    coverImage: DJ_IMAGE,
    galleryImages: [DJ_IMAGE, LIGHTING_IMAGE],
    description: 'High-energy contemporary wedding and party DJ paired with master oriental darbouka percussionist, synchronized Pioneer setups, and full dancefloor energy.',
    descriptionAr: 'دي جي حفلات الزفاف والسهرات الشبابية مع عازف درامز وإيقاع شرقي مباشر يلهب حماس المدعوين على مسارح الحفلات الفاخرة.',
    rating: 4.95,
    reviewsCount: 48,
    featured: true,
    status: 'active',
    capacity: 'Concert Sound for 1,000 Pax',
    eventTypes: ['wedding', 'engagement', 'birthday', 'private_party', 'corporate_gala'],
    packages: [
      {
        id: 'pkg-dj-full',
        name: 'The Ultimate Party & Percussion Set',
        nameAr: 'باقة السهرة الحماسية مع الإيقاع الحي',
        priceEgp: 50000,
        description: '4-hour uninterrupted set, live acoustic percussionist on stage, wireless mic setup, and custom wedding entrance track.',
        descriptionAr: 'أربع ساعات من الموسيقى المتواصلة مع عازف إيقاع مباشر وميكروفونات لاسلكية وتوزيع خاص لدخول الحفل.',
        features: ['4-Hour Live Set', 'Stage Percussionist', 'Pioneer Nexus Rig', 'Sound Check & Engineer'],
        featuresAr: ['٤ ساعات أداء موسيقي', 'عازف إيقاع على المسرح', 'أجهزة بايونير الاحترافية', 'مهندس صوت مخصص']
      }
    ],
    reviews: []
  },
  {
    id: 'vendor-party-atelier',
    name: 'Party Atelier Egypt & Balloon Couture',
    nameAr: 'بارتي أتيليه لتصميم حفلات أعياد الميلاد والبالونات',
    category: 'party_decor',
    city: 'Sheikh Zayed',
    cityAr: 'الشيخ زايد',
    neighborhood: 'Al Guezira & Zayed',
    neighborhoodAr: 'الجزيرة والشيخ زايد',
    phone: '+20 115 777 9922',
    email: 'hello@partyatelier.eg',
    whatsapp: '+201157779922',
    instagram: '@partyatelier.egypt',
    startingPriceEgp: 25000,
    coverImage: BIRTHDAY_IMAGE,
    galleryImages: [BIRTHDAY_IMAGE, TABLE_IMAGE],
    description: 'Bespoke birthday styling, organic balloon architecture, custom backdrops, personalized cake tables, and children or milestone celebration aesthetics.',
    descriptionAr: 'أرقى ديكورات أعياد الميلاد والمناسبات الخاصة، تصميم أقواس البالونات العضوية، طاولات الحلوى المصممة، وديكورات الحفلات الفاخرة.',
    rating: 4.92,
    reviewsCount: 37,
    featured: true,
    status: 'active',
    capacity: 'Bespoke Party Installations',
    eventTypes: ['birthday', 'baby_shower', 'graduation', 'private_party', 'anniversary'],
    packages: [
      {
        id: 'pkg-party-milestone',
        name: 'The Milestone Garden Balloon & Cake Setup',
        nameAr: 'باقة أعياد الميلاد الكبرى في الحديقة',
        priceEgp: 35000,
        description: 'Full organic balloon arch, personalized neon sign, styled marble dessert plinths, and flower arrangements.',
        descriptionAr: 'قوس بالونات عضوي ضخم، لوحة نيون مخصصة باسم صاحب الحفل، طاولات رخامية للحلويات وتنسيقات زهور طبيعية.',
        features: ['Custom Neon Sign', 'Organic Balloon Installation', '3 Marble Plinths', 'Lighting Accents'],
        featuresAr: ['لوحة نيون باسم صاحب العيد', 'أقواس بالونات راقية', 'طاولات عرض الحلويات', 'إضاءات دافئة مخصصة']
      }
    ],
    reviews: []
  },
  {
    id: 'vendor-prestige-hosting',
    name: 'Prestige Protocol & VIP Hostesses Egypt',
    nameAr: 'بريستيج لخدمات الاستقبال والضيافة والمراسم الملكية',
    category: 'hosting_ushers',
    city: 'New Cairo',
    cityAr: 'القاهرة الجديدة',
    neighborhood: 'Fifth Settlement & Katameya',
    neighborhoodAr: 'التجمع الخامس والقطامية',
    phone: '+20 102 333 8899',
    email: 'concierge@prestigehosting.eg',
    whatsapp: '+201023338899',
    instagram: '@prestige.hostesses.eg',
    startingPriceEgp: 35000,
    coverImage: HOSTING_IMAGE,
    galleryImages: [HOSTING_IMAGE, VENUE_IMAGE],
    description: 'Elite multilingual hostess and ushering teams for luxury weddings, palatial receptions, and high-profile galas. Digital QR check-in, guest escorting, and VIP table seating management.',
    descriptionAr: 'فريق مضيفين ومضيفات على أعلى مستوى من اللباقة والأناقة لإدارة استقبال وتسكين المعازيم والترحيب بكبار الشخصيات بأنظمة الدخول الذكية.',
    rating: 4.93,
    reviewsCount: 31,
    featured: true,
    status: 'active',
    capacity: 'Teams of 8 to 40 Hostesses',
    eventTypes: ['wedding', 'corporate_gala', 'conference_launch', 'engagement'],
    packages: [],
    reviews: []
  },
  {
    id: 'vendor-orbitron-events',
    name: 'Orbitron Premier Event Management & Mega Productions',
    nameAr: 'أوربيترون لإدارة الفعاليات الكبرى والحفلات الأسطورية',
    category: 'event_management',
    city: 'Giza',
    cityAr: 'الجيزة',
    neighborhood: 'Pyramids Plateau & Sheikh Zayed',
    neighborhoodAr: 'هضبة الأهرامات والشيخ زايد',
    phone: '+20 100 000 7711',
    email: 'productions@orbitronevents.eg',
    whatsapp: '+201000007711',
    instagram: '@orbitron.events.egypt',
    startingPriceEgp: 250000,
    coverImage: EVENT_MANAGEMENT_IMAGE,
    galleryImages: [EVENT_MANAGEMENT_IMAGE, LIGHTING_IMAGE, HERO_IMAGE],
    description: 'Turnkey mega event production house specializing in Pyramids Plateau galas, international celebrity artist bookings, architectural rigging, sound engineering, and luxury brand celebrations.',
    descriptionAr: 'الشركة الرائدة في تنظيم الحفلات الكبرى وحفلات الزفاف الأسطورية بمنطقة الأهرامات والقصور، مع حجز كبار الفنانين وهندسة الصوت والمسارح العملاقة.',
    rating: 4.99,
    reviewsCount: 54,
    featured: true,
    status: 'active',
    capacity: 'From 300 to 5,000 Guests',
    eventTypes: ['corporate_gala', 'conference_launch', 'wedding'],
    packages: [],
    reviews: []
  },
  {
    id: 'vendor-nour-planner',
    name: 'Nour Atelier Wedding Architecture & Planning',
    nameAr: 'نور أتيليه لهندسة وتصميم حفلات الزفاف',
    category: 'wedding_planners',
    city: 'New Cairo',
    cityAr: 'القاهرة الجديدة',
    neighborhood: 'Lake View & Katameya Heights',
    neighborhoodAr: 'ليك فيو وقطامية هايتس',
    phone: '+20 122 777 4433',
    email: 'atelier@nourweddings.eg',
    whatsapp: '+201227774433',
    instagram: '@nour.atelier.weddings',
    startingPriceEgp: 95000,
    coverImage: HERO_IMAGE,
    galleryImages: [HERO_IMAGE, TABLE_IMAGE, BRIDAL_IMAGE],
    description: 'Bespoke wedding planners crafting seamless high-society celebrations across Egypt. Concept design, budget oversight, vendor contract negotiations, and day-of execution.',
    descriptionAr: 'تخطيط وتصميم متكامل لحفلات الزفاف الراقية في مصر، من فكرة الديكور وجدول المواعيد وإدارة الميزانية إلى الإشراف الميداني يوم الفرح.',
    rating: 4.97,
    reviewsCount: 39,
    featured: true,
    status: 'active',
    eventTypes: ['wedding', 'engagement', 'private_party'],
    packages: [],
    reviews: []
  },
  {
    id: 'vendor-karim-cinema',
    name: 'Karim Tamer Fine Art Cinema & Visuals',
    nameAr: 'كريم تامر — للتصوير السينمائي والفوتوغرافي',
    category: 'photography',
    city: 'Cairo',
    cityAr: 'القاهرة',
    neighborhood: 'Garden City & New Cairo',
    neighborhoodAr: 'جاردن سيتي والقاهرة الجديدة',
    phone: '+20 100 444 3322',
    email: 'studio@karimtamer.com',
    whatsapp: '+201004443322',
    instagram: '@karimtamer.weddings',
    startingPriceEgp: 65000,
    coverImage: HERO_IMAGE,
    galleryImages: [HERO_IMAGE, BRIDAL_IMAGE, TABLE_IMAGE],
    description: 'Documentary fine-art wedding photography and 4K cinema films capturing raw emotion, timeless aesthetics, and authentic Egyptian joy.',
    descriptionAr: 'توثيق سينمائي وفوتوغرافي للأعراس بأحدث التقنيات وعدسات السينما، لالتقاط اللحظات الحية والبهجة المصرية بأسلوب راقٍ وخالد.',
    rating: 4.98,
    reviewsCount: 44,
    featured: true,
    status: 'active',
    eventTypes: ['wedding', 'engagement', 'birthday', 'corporate_gala'],
    packages: [],
    reviews: []
  },
  {
    id: 'vendor-maison-fleurs',
    name: 'Maison des Fleurs Scenography',
    nameAr: 'ميزون دي فلور لتصميم وتنسيق الزهور',
    category: 'floral_decor',
    city: 'Sheikh Zayed',
    cityAr: 'الشيخ زايد',
    neighborhood: 'Al Guezira, Sheikh Zayed',
    neighborhoodAr: 'الجزيرة، الشيخ زايد',
    phone: '+20 111 888 7766',
    email: 'atelier@maisonfleurs.eg',
    whatsapp: '+201118887766',
    instagram: '@maisonfleurs.egypt',
    startingPriceEgp: 140000,
    coverImage: TABLE_IMAGE,
    galleryImages: [TABLE_IMAGE, HERO_IMAGE, VENUE_IMAGE],
    description: 'Haute-couture botanical scenography, luxury imported florals, custom Kosha designs, and bespoke candelabra tablescapes crafted by leading Egyptian floral architects.',
    descriptionAr: 'تصميم ديكورات زهور راقية ومستوردة، تصميم الكوشة الحصرية، وتنسيق طاولات الزفاف الملكية بأرقى المعايير العالمية في مصر.',
    rating: 4.9,
    reviewsCount: 29,
    featured: true,
    status: 'active',
    eventTypes: ['wedding', 'engagement', 'corporate_gala', 'private_party'],
    packages: [],
    reviews: []
  },
  {
    id: 'vendor-le-cirque-catering',
    name: 'Le Cirque Nile Haute Gastronomy',
    nameAr: 'لو سيرك النيل — الضيافة وفنون الطهي الرفيعة',
    category: 'catering',
    city: 'Giza',
    cityAr: 'الجيزة',
    neighborhood: 'Pyramids View & Giza',
    neighborhoodAr: 'منطقة الأهرامات والجيزة',
    phone: '+20 106 222 1199',
    email: 'events@lecirquegroup.eg',
    whatsapp: '+201062221199',
    instagram: '@lecirque.catering.cairo',
    startingPriceEgp: 180000,
    coverImage: TABLE_IMAGE,
    galleryImages: [TABLE_IMAGE, VENUE_IMAGE, HERO_IMAGE],
    description: 'Michelin-trained culinary brigade presenting gourmet fusion buffets, live carving stations, bespoke wedding cakes, and five-star silver service.',
    descriptionAr: 'فريق طهاة عالميون يقدمون أشهى بوفيهات الطعام الفاخر ومحطات الطهي الحية وكعكات الزفاف الملكية مع خدمة فضية راقية.',
    rating: 4.94,
    reviewsCount: 52,
    featured: false,
    status: 'active',
    eventTypes: ['wedding', 'corporate_gala', 'birthday', 'private_party'],
    packages: [],
    reviews: []
  }
];

// Pinterest-Style Visual Inspiration Pins with varied heights and event tags
export const INITIAL_PINS: PinItem[] = [
  {
    id: 'pin-lighting-arch',
    vendorId: 'vendor-lumina-lighting',
    vendorName: 'Lumina Architectural Lighting',
    vendorNameAr: 'لومينا لهندسة الإضاءة والمؤثرات',
    vendorCategory: 'lighting_fx',
    vendorCity: 'Sheikh Zayed',
    vendorCityAr: 'الشيخ زايد',
    vendorPhone: '+20 101 987 6543',
    vendorEmail: 'info@luminalighting.eg',
    vendorWhatsapp: '+201019876543',
    vendorStartingPriceEgp: 85000,
    imageUrl: LIGHTING_IMAGE,
    title: 'Warm Micro-Fairy Canopy & Architectural Arch Illumination',
    titleAr: 'سقف الإضاءة الخيالية وإضاءة الأقواس التاريخية الذهبية',
    description: 'Overhead warm fairy-light canopy with 12 motorized beam movers casting romantic rays on Cairo historic stone walls.',
    descriptionAr: 'سقف متلألئ بآلاف المصابيح الدقيقة مع كشافات إضاءة سينمائية تبرز جمال العمارة التراثية في حفل زفاف أسطوري.',
    tags: ['#LightingVendors', '#FairyLightCanopy', '#ZayedWeddings', '#StageFX', '#CairoNights'],
    likesCount: 284,
    aspectRatio: 'tall',
    eventTypes: ['wedding', 'engagement', 'private_party'],
    collectionIds: ['col-lighting-stage', 'col-my-wedding']
  },
  {
    id: 'pin-bellydancer-zaffah',
    vendorId: 'vendor-amira-bellydance',
    vendorName: 'Amira & Royal Egyptian Zaffah',
    vendorNameAr: 'أميرة وفرقة الزفة الشرقية الملكية',
    vendorCategory: 'belly_dancers',
    vendorCity: 'Cairo',
    vendorCityAr: 'القاهرة',
    vendorPhone: '+20 114 555 1234',
    vendorEmail: 'booking@amirashow.eg',
    vendorWhatsapp: '+201145551234',
    vendorStartingPriceEgp: 45000,
    imageUrl: BELLY_DANCER_IMAGE,
    title: 'Golden Silk Oriental Dance & Percussion Zaffah',
    titleAr: 'استعراض الحرير الذهبي وزفة الطبول الملكية',
    description: 'Dynamic entrance solo show with traditional Egyptian tabla players creating unforgettable joy for wedding guests.',
    descriptionAr: 'عرض استعراضي كلاسيكي مبهر مع فرقة إيقاعات الطبول المصرية الأصيلة في ليلة زفاف ساحرة.',
    tags: ['#BellyDancers', '#EgyptianZaffah', '#OrientalShow', '#TraditionalPercussion', '#Celebration'],
    likesCount: 412,
    aspectRatio: 'tall',
    eventTypes: ['wedding', 'engagement', 'birthday', 'cultural_celebration'],
    collectionIds: []
  },
  {
    id: 'pin-birthday-garden',
    vendorId: 'vendor-party-atelier',
    vendorName: 'Party Atelier Egypt & Balloon Couture',
    vendorNameAr: 'بارتي أتيليه لتصميم حفلات أعياد الميلاد',
    vendorCategory: 'party_decor',
    vendorCity: 'Sheikh Zayed',
    vendorCityAr: 'الشيخ زايد',
    vendorPhone: '+20 115 777 9922',
    vendorEmail: 'hello@partyatelier.eg',
    vendorWhatsapp: '+201157779922',
    vendorStartingPriceEgp: 25000,
    imageUrl: BIRTHDAY_IMAGE,
    title: 'Pastel Garden Balloon Arch & Pyramids Sunset View',
    titleAr: 'قوس بالونات باستيل فخم وكعكة عيد ميلاد بإطلالة الأهرامات',
    description: 'Chic outdoor private party celebration in Cairo with organic balloon installation, marble plinths, and bespoke 3-tier celebration cake.',
    descriptionAr: 'تنسيق استثنائي لحفل عيد ميلاد وسهرة عائلية راقية في حديقة خاصة مع قوس بالونات متدرج الألوان وبوفيه حلويات فاخر.',
    tags: ['#BirthdayParty', '#BalloonCouture', '#GardenParty', '#PrivateCelebration', '#CakeDesign'],
    likesCount: 389,
    aspectRatio: 'tall',
    eventTypes: ['birthday', 'baby_shower', 'graduation', 'private_party', 'anniversary'],
    collectionIds: ['col-birthday-ideas', 'col-decor-flowers']
  },
  {
    id: 'pin-dj-percussion',
    vendorId: 'vendor-dj-ramy',
    vendorName: 'DJ Ramy & Live Percussion Fusion',
    vendorNameAr: 'دي جي رامي وعازف الإيقاع الحي',
    vendorCategory: 'dj_sound',
    vendorCity: 'New Cairo',
    vendorCityAr: 'القاهرة الجديدة',
    vendorPhone: '+20 102 999 4411',
    vendorEmail: 'bookings@djramy.eg',
    vendorWhatsapp: '+201029994411',
    vendorStartingPriceEgp: 38000,
    imageUrl: DJ_IMAGE,
    title: 'Concert Stage DJ Performance with Live Percussionist',
    titleAr: 'سهرة الدي جي والإيقاع الحي والمسرح المضيء بالليزر',
    description: 'Electrifying wedding and party music performance with live oriental darbouka drum rhythms, moving lasers, and packed dance floor.',
    descriptionAr: 'حفل موسيقي شبابي صاخب يجمع بين أقوى معزوفات الدي جي والإيقاع الشرقي الحي مع أحدث مؤثرات الليزر.',
    tags: ['#WeddingDJ', '#LivePercussion', '#LaserShow', '#DanceFloor', '#PartyVibes'],
    likesCount: 461,
    aspectRatio: 'tall',
    eventTypes: ['wedding', 'engagement', 'birthday', 'private_party', 'corporate_gala'],
    collectionIds: ['col-lighting-stage', 'col-birthday-ideas']
  },
  {
    id: 'pin-vip-hostesses',
    vendorId: 'vendor-prestige-hosting',
    vendorName: 'Prestige Protocol & VIP Hostesses',
    vendorNameAr: 'بريستيج لخدمات الاستقبال والضيافة',
    vendorCategory: 'hosting_ushers',
    vendorCity: 'New Cairo',
    vendorCityAr: 'القاهرة الجديدة',
    vendorPhone: '+20 102 333 8899',
    vendorEmail: 'concierge@prestigehosting.eg',
    vendorWhatsapp: '+201023338899',
    vendorStartingPriceEgp: 35000,
    imageUrl: HOSTING_IMAGE,
    title: 'Red Carpet Royal Welcome & VIP Guest Ushering',
    titleAr: 'استقبال السجادة الحمراء وبروتوكول كبار الشخصيات',
    description: 'Elegant multilingual hostesses greeting guests with digital tablet check-in at historic Baron Palace entrance.',
    descriptionAr: 'فريق مضيفات محترف بالزي الموحد الأنيق لاستقبال وتسكين المعازيم بنظام الدخول الرقمي الراقي.',
    tags: ['#HostingCompanies', '#VIPHostesses', '#EventUshers', '#BaronPalace', '#GuestProtocol'],
    likesCount: 195,
    aspectRatio: 'tall',
    eventTypes: ['wedding', 'corporate_gala', 'conference_launch', 'engagement'],
    collectionIds: ['col-corporate-event']
  },
  {
    id: 'pin-pyramids-gala',
    vendorId: 'vendor-orbitron-events',
    vendorName: 'Orbitron Premier Event Management',
    vendorNameAr: 'أوربيترون لإدارة الفعاليات الكبرى',
    vendorCategory: 'event_management',
    vendorCity: 'Giza',
    vendorCityAr: 'الجيزة',
    vendorPhone: '+20 100 000 7711',
    vendorEmail: 'productions@orbitronevents.eg',
    vendorWhatsapp: '+201000007711',
    vendorStartingPriceEgp: 250000,
    imageUrl: EVENT_MANAGEMENT_IMAGE,
    title: 'Symphonic Pyramids Gala Staging & Mega Banquet',
    titleAr: 'مسرح الحفلات الأسطوري أمام أهرامات الجيزة',
    description: 'Monumental 50-meter architectural stage with full live philharmonic orchestra and lavish seated dinner tables facing the illuminated Pyramids.',
    descriptionAr: 'إنتاج استثنائي متكامل لمسرح ضخم مع فرقة سيمفونية وموائد عشاء فاخرة بإطلالة مباشرة على أهرامات الجيزة.',
    tags: ['#EventsManagement', '#MegaProduction', '#PyramidsGala', '#ConcertStaging', '#GizaPlateau'],
    likesCount: 538,
    aspectRatio: 'tall',
    eventTypes: ['corporate_gala', 'conference_launch', 'wedding'],
    collectionIds: ['col-corporate-event', 'col-lighting-stage']
  },
  {
    id: 'pin-palais-ballroom',
    vendorId: 'vendor-palais-du-nil',
    vendorName: 'Palais du Nil Grand Ballroom',
    vendorNameAr: 'قصر النيل — القاعة الملكية',
    vendorCategory: 'venues',
    vendorCity: 'Cairo',
    vendorCityAr: 'القاهرة',
    vendorPhone: '+20 100 234 5678',
    vendorEmail: 'events@palaisdunil.com.eg',
    vendorWhatsapp: '+201002345678',
    vendorStartingPriceEgp: 320000,
    imageUrl: VENUE_IMAGE,
    title: 'Imperial Archways & Crystal Chandeliers Ballroom',
    titleAr: 'أقواس الأرابيسك الملكية وثريات الكريستال الفخمة',
    description: 'Historic ballroom architecture with bespoke circular stage, floral kosha, and round banquet tables for 500 guests.',
    descriptionAr: 'قاعة تاريخية فسيحة بالزمالك تتزين بأقواس شاهقة وثريات كريستال وكوشة زفاف أسطورية.',
    tags: ['#Venues', '#ZamalekPalace', '#CrystalBallroom', '#RoyalKosha', '#CairoWeddings'],
    likesCount: 367,
    aspectRatio: 'square',
    eventTypes: ['wedding', 'engagement', 'corporate_gala'],
    collectionIds: ['col-my-wedding', 'col-venue-ideas']
  },
  {
    id: 'pin-tablescape-runner',
    vendorId: 'vendor-maison-fleurs',
    vendorName: 'Maison des Fleurs Scenography',
    vendorNameAr: 'ميزون دي فلور للزهور والكوشة',
    vendorCategory: 'floral_decor',
    vendorCity: 'Sheikh Zayed',
    vendorCityAr: 'الشيخ زايد',
    vendorPhone: '+20 111 888 7766',
    vendorEmail: 'atelier@maisonfleurs.eg',
    vendorWhatsapp: '+201118887766',
    vendorStartingPriceEgp: 140000,
    imageUrl: TABLE_IMAGE,
    title: 'Fine Linen Tablescape with Peonies & Brass Candelabras',
    titleAr: 'طاولات العشاء الملكية بالشموع والورود الإنجليزية',
    description: 'Champagne gold cutlery, organic eucalyptus runners, and scented ivory tapers for an intimate dining atmosphere.',
    descriptionAr: 'تنسيق أنيق لطاولات المدعوين بأدوات مائدة مذهبة وشموع عطرية وزهور بيضاء طبيعية مستوردة.',
    tags: ['#FloralScenography', '#Tablescape', '#GoldenCutlery', '#CandlelitDinner', '#LuxuryDecor'],
    likesCount: 290,
    aspectRatio: 'wide',
    eventTypes: ['wedding', 'engagement', 'anniversary', 'private_party'],
    collectionIds: ['col-my-wedding', 'col-decor-flowers']
  },
  {
    id: 'pin-bridal-calligraphy',
    vendorId: 'vendor-nour-planner',
    vendorName: 'Nour Atelier Wedding Architecture',
    vendorNameAr: 'نور أتيليه لهندسة وتصميم حفلات الزفاف',
    vendorCategory: 'wedding_planners',
    vendorCity: 'New Cairo',
    vendorCityAr: 'القاهرة الجديدة',
    vendorPhone: '+20 122 777 4433',
    vendorEmail: 'atelier@nourweddings.eg',
    vendorWhatsapp: '+201227774433',
    vendorStartingPriceEgp: 95000,
    imageUrl: BRIDAL_IMAGE,
    title: 'Handmade Arabic Calligraphy Invitation & Natural Pearls',
    titleAr: 'بطاقات الدعوة بالخط العربي الأصيل واللؤلؤ الطبيعي',
    description: 'Gold embossed handmade cotton paper wedding invitations with custom wax seal and natural heirloom jewelry flatlay.',
    descriptionAr: 'دعوات زفاف مطرزة بالذهب ومكتوبة بخط عربي فخم مع أختام الشمع الطبيعي وحبات اللؤلؤ التراثي.',
    tags: ['#WeddingPlanners', '#ArabicCalligraphy', '#WaxSeal', '#BridalDetails', '#FineArtStationery'],
    likesCount: 315,
    aspectRatio: 'tall',
    eventTypes: ['wedding', 'engagement', 'cultural_celebration'],
    collectionIds: ['col-photography', 'col-my-wedding']
  },
  {
    id: 'pin-nile-sunset-view',
    vendorId: 'vendor-karim-cinema',
    vendorName: 'Karim Tamer Fine Art Cinema',
    vendorNameAr: 'كريم تامر — للتصوير السينمائي',
    vendorCategory: 'photography',
    vendorCity: 'Cairo',
    vendorCityAr: 'القاهرة',
    vendorPhone: '+20 100 444 3322',
    vendorEmail: 'studio@karimtamer.com',
    vendorWhatsapp: '+201004443322',
    vendorStartingPriceEgp: 65000,
    imageUrl: HERO_IMAGE,
    title: 'Twilight Nile Terrace Reception & Gown Silhouette',
    titleAr: 'غروب النيل وتوثيق سينمائي للحظات الفرح الخالدة',
    description: 'Open-air long imperial banquet table glowing under sunset sky overlooking the historic city of Cairo.',
    descriptionAr: 'لقطة سينمائية عريضة لمأدبة حفل الزفاف على تراس النيل مع نسمات الغروب وأضواء القاهرة الساحرة.',
    tags: ['#Photography', '#NileWedding', '#SunsetReception', '#CinematicFilm', '#CairoVisuals'],
    likesCount: 472,
    aspectRatio: 'wide',
    eventTypes: ['wedding', 'engagement', 'corporate_gala', 'private_party'],
    collectionIds: ['col-venue-ideas', 'col-photography']
  }
];

export const INITIAL_EVENTS: EventModel[] = [
  {
    id: 'event-nour-tarek',
    title: "Nour & Tarek's Grand Nile Wedding",
    titleAr: 'حفل زفاف نور وطارق الملكي على النيل',
    type: 'wedding',
    date: '2026-12-18',
    city: 'Cairo',
    cityAr: 'القاهرة',
    venueName: 'Palais du Nil Grand Ballroom',
    plannedBudgetEgp: 1250000,
    guestCount: 350,
    savedVendorIds: [
      'vendor-palais-du-nil',
      'vendor-lumina-lighting',
      'vendor-amira-bellydance',
      'vendor-dj-ramy',
      'vendor-prestige-hosting',
      'vendor-nour-planner'
    ]
  },
  {
    id: 'event-farida-engagement',
    title: "Farida's Sunset Engagement Gala",
    titleAr: 'حفل خطوبة فريدة عند الغروب',
    type: 'engagement',
    date: '2027-02-20',
    city: 'Sheikh Zayed',
    cityAr: 'الشيخ زايد',
    venueName: 'Villa Di Mare & Garden Lounge',
    plannedBudgetEgp: 450000,
    guestCount: 140,
    savedVendorIds: ['vendor-lumina-lighting', 'vendor-maison-fleurs', 'vendor-party-atelier']
  }
];

export const INITIAL_CHECKLIST: EventChecklistItem[] = [
  {
    id: 'task-1',
    eventId: 'event-nour-tarek',
    title: 'Finalize venue deposit and secure Nile Ballroom contract',
    titleAr: 'سداد عربون القاعة وتأكيد عقد قصر النيل رسمياً',
    category: 'venue',
    dueDate: '2026-11-01',
    completed: true,
    notes: '20% deposit confirmed via Palais du Nil concierge'
  },
  {
    id: 'task-2',
    eventId: 'event-nour-tarek',
    title: 'Approve Lumina architectural lighting mockups & starlight canopy',
    titleAr: 'اعتماد مخطط إضاءة لومينا المعمارية وسقف النجوم المضيء',
    category: 'decor',
    dueDate: '2026-11-12',
    completed: true,
    notes: '10,000 micro-bulbs and warm gold mood confirmed'
  },
  {
    id: 'task-3',
    eventId: 'event-nour-tarek',
    title: 'Book Amira oriental solo show & 12-performer shamadan zaffah',
    titleAr: 'تأكيد حجز استعراض أميرة وزفة الشمعدان الملكية مع ١٢ عازف إيقاع',
    category: 'music',
    dueDate: '2026-11-18',
    completed: false,
    notes: 'Costume styling matched to champagne gold theme'
  },
  {
    id: 'task-4',
    eventId: 'event-nour-tarek',
    title: 'Confirm Prestige Hostesses VIP seating & QR check-in team',
    titleAr: 'تأكيد فريق بريستيج لاستقبال كبار الشخصيات والدخول الذكي بالباركود',
    category: 'logistics',
    dueDate: '2026-11-25',
    completed: false,
    notes: '16 hostesses briefed on VIP table arrangements'
  }
];

export const INITIAL_EXPENSES: EventExpense[] = [
  {
    id: 'exp-1',
    eventId: 'event-nour-tarek',
    title: 'Palais du Nil — Venue Rental & Initial Deposit',
    titleAr: 'قصر النيل — إيجار القاعة والدفعة الأولى',
    category: 'venue',
    amountEgp: 380000,
    vendorName: 'Palais du Nil Grand Ballroom',
    paid: true,
    date: '2026-10-15'
  },
  {
    id: 'exp-2',
    eventId: 'event-nour-tarek',
    title: 'Lumina — Architectural Starlight Ceiling & FX',
    titleAr: 'لومينا — سقف الإضاءة الخيالية والمؤثرات البصرية',
    category: 'decor',
    amountEgp: 85000,
    vendorName: 'Lumina Architectural Lighting',
    paid: true,
    date: '2026-10-20'
  },
  {
    id: 'exp-3',
    eventId: 'event-nour-tarek',
    title: 'Amira Show — Royal Shamadan Zaffah Retainer',
    titleAr: 'أميرة شو — عربون حجز زفة الشمعدان والاستعراض',
    category: 'entertainment',
    amountEgp: 45000,
    vendorName: 'Amira & Royal Egyptian Zaffah',
    paid: false,
    date: '2026-11-10'
  },
  {
    id: 'exp-4',
    eventId: 'event-nour-tarek',
    title: 'Prestige Hostesses — VIP Reception Team',
    titleAr: 'بريستيج هوسبيتس — فريق تنظيم الاستقبال والمراسم',
    category: 'other',
    amountEgp: 35000,
    vendorName: 'Prestige Protocol & VIP Hostesses',
    paid: false,
    date: '2026-11-15'
  }
];

export const INITIAL_INQUIRIES: BookingInquiry[] = [
  {
    id: 'inq-101',
    eventId: 'event-nour-tarek',
    eventName: "Nour & Tarek's Grand Nile Wedding",
    vendorId: 'vendor-palais-du-nil',
    vendorName: 'Palais du Nil Grand Ballroom & Gardens',
    vendorNameAr: 'قصر النيل — القاعة الملكية والحدائق',
    vendorCategory: 'venues',
    customerName: 'Tarek Mansour',
    customerEmail: 'tarek.mansour@example.eg',
    customerPhone: '+20 100 234 5678',
    eventDate: '2026-12-18',
    guestCount: 350,
    requirements: 'Interested in the Imperial Garden & Ballroom package. Requiring Nile terrace cocktail hour at 5:00 PM followed by seated dinner in the Grand Ballroom.',
    status: 'confirmed',
    createdAt: '2026-10-12',
    quotedPriceEgp: 380000,
    vendorNotes: 'Confirmed for Dec 18, 2026. Complimentary bridal suite and red carpet Nile arrival included.',
    depositRequiredEgp: 100000
  },
  {
    id: 'inq-102',
    eventId: 'event-nour-tarek',
    eventName: "Nour & Tarek's Grand Nile Wedding",
    vendorId: 'vendor-lumina-lighting',
    vendorName: 'Lumina Architectural Lighting',
    vendorNameAr: 'لومينا لهندسة الإضاءة والمؤثرات',
    vendorCategory: 'lighting_fx',
    customerName: 'Nour El-Din',
    customerEmail: 'nour.eldin@example.eg',
    customerPhone: '+20 102 889 1234',
    eventDate: '2026-12-18',
    guestCount: 350,
    requirements: 'Custom warm starlight ceiling over dining area and laser mapping on ballroom arches.',
    status: 'response_received',
    createdAt: '2026-10-21',
    quotedPriceEgp: 85000,
    vendorNotes: 'Quotation sent: includes 10,000 warm micro-bulbs, 16 beam moving heads, and 4 technicians.',
    depositRequiredEgp: 30000
  }
];

// =============================================================
// HACKATHON SPONSORS INITIAL DATA: PayPal, Bryntum, Zapier
// =============================================================

export const INITIAL_PAYPAL_TRANSACTIONS: PayPalTransaction[] = [
  {
    id: 'PAYID-M7X92-EGY-8921',
    orderId: 'ORD-NIL-2026-101',
    vendorId: 'vendor-palais-du-nil',
    vendorName: 'Palais du Nil Grand Ballroom & Gardens',
    vendorNameAr: 'قصر النيل — القاعة الملكية والحدائق',
    inquiryId: 'inq-101',
    amountEgp: 100000,
    currency: 'USD',
    convertedAmount: 2032.52,
    tier: 1,
    tierName: 'Milestone 1: 20% Booking Deposit (Date Lock)',
    status: 'escrow_held',
    date: '2026-10-14 18:42:10',
    payerEmail: 'tarek.mansour@example.eg',
    payerName: 'Tarek Mansour',
    payerId: 'PAYERID-EG-99382',
    notes: 'Escrow release scheduled upon venue setup inspection 48h prior to wedding.'
  },
  {
    id: 'PAYID-K4L81-EGY-3319',
    orderId: 'ORD-LUM-2026-044',
    vendorId: 'vendor-lumina-lighting',
    vendorName: 'Lumina Architectural Lighting',
    vendorNameAr: 'لومينا لهندسة الإضاءة والمؤثرات',
    amountEgp: 30000,
    currency: 'EGP',
    convertedAmount: 30000,
    tier: 1,
    tierName: 'Milestone 1: Booking Deposit',
    status: 'escrow_held',
    date: '2026-10-22 14:15:33',
    payerEmail: 'nour.eldin@example.eg',
    payerName: 'Nour El-Din',
    payerId: 'PAYERID-EG-44012',
    notes: 'Lighting truss & laser mapping deposit held in PayPal Smart Escrow.'
  }
];

export const INITIAL_BRYNTUM_SCHEDULE: BryntumScheduleItem[] = [
  {
    id: 'bry-1',
    title: 'Floral Kosha & Backdrop Architecture Setup',
    titleAr: 'تركيب كوشة الزهور وتنسيق المنصة الملكية',
    startTime: '13:00',
    endTime: '16:30',
    trackId: 'staging',
    vendorId: 'vendor-le-fleuriste',
    vendorName: 'Le Fleuriste Wedding & Kosha Design',
    vendorNameAr: 'لو فلوريست لتصميم الكوشة والزهور',
    zone: 'Grand Ballroom Stage',
    zoneAr: 'منصة القاعة الكبرى',
    status: 'confirmed',
    notes: 'Requires 4,000 Dutch white hydrangeas and custom curved gold arches.',
    notesAr: 'تحتاج 4000 زهرة هيدرانجيا بيضاء هولندية وأقواس ذهبية مقوسة.',
    color: '#8E735B'
  },
  {
    id: 'bry-2',
    title: 'Sound System Acoustic Tuning & Truss Rigging',
    titleAr: 'ضبط الصوت وتجهيز شبكة الإضاءة الهندسية',
    startTime: '15:00',
    endTime: '17:00',
    trackId: 'lighting_sound',
    vendorId: 'vendor-lumina-lighting',
    vendorName: 'Lumina Architectural Lighting',
    vendorNameAr: 'لومينا لهندسة الإضاءة والمؤثرات',
    zone: 'Ballroom Ceiling Truss',
    zoneAr: 'شبكة سقف القاعة المعلقة',
    status: 'confirmed',
    notes: '16 moving beam heads focus test & wireless lavalier checks.',
    notesAr: 'اختبار 16 كشاف متحرك وفحص ميكروفونات الزفة.',
    color: '#3B6A9E'
  },
  {
    id: 'bry-3',
    title: 'Bride & Groom Golden Hour Sunset Photoshoot',
    titleAr: 'جلسة تصوير العروسين وقت الغروب الساحر',
    startTime: '16:45',
    endTime: '18:15',
    trackId: 'photo_cinema',
    vendorId: 'vendor-karim-photo',
    vendorName: 'Karim Sherif Wedding Cinema & Photography',
    vendorNameAr: 'كريم شريف لسينما وتصوير الأعراس',
    zone: 'Nile Terrace & Royal Gardens',
    zoneAr: 'حدائق النيل الملكية والممشى',
    status: 'confirmed',
    notes: 'Drone 4K aerial shots and 35mm film portraits.',
    notesAr: 'تصوير جوي بالدرون بدقة 4K وصور فوتوغرافية كلاسيكية.',
    color: '#7A8B7B'
  },
  {
    id: 'bry-4',
    title: 'Royal Egyptian Zaffah with Mazamir & Tabla',
    titleAr: 'الزفة المصرية الكبرى بالمزامير والطبول الأصيلة',
    startTime: '18:30',
    endTime: '19:45',
    trackId: 'zaffa_entertainment',
    vendorId: 'vendor-amira-bellydance',
    vendorName: 'Amira & Royal Egyptian Zaffah',
    vendorNameAr: 'أميرة وفرقة الزفة الشرقية الملكية',
    zone: 'Palace Grand Foyer & Main Staircase',
    zoneAr: 'بهو القصر والدرج الرخامي الملكي',
    status: 'confirmed',
    notes: '12 percussionists, traditional bagpipes, and golden silk procession.',
    notesAr: '12 عازف إيقاع وطبول، مزمار بلدي، وموكب استعراضي بالحرير الذهبي.',
    color: '#B79A66'
  },
  {
    id: 'bry-5',
    title: 'Oriental Solo Dance & Silk Fan Spectacular',
    titleAr: 'استعراض الصولو الشرقي وأوشحة الحرير المضيئة',
    startTime: '20:15',
    endTime: '21:15',
    trackId: 'zaffa_entertainment',
    vendorId: 'vendor-amira-bellydance',
    vendorName: 'Amira & Royal Egyptian Zaffah',
    vendorNameAr: 'أميرة وفرقة الزفة الشرقية الملكية',
    zone: 'Main Dance Floor',
    zoneAr: 'ساحة الرقص الرئيسية',
    status: 'confirmed',
    notes: 'Performance directly preceding open buffet banquet.',
    notesAr: 'العرض الاستعراضي الرئيسي مباشرة قبل بدء بوفيه العشاء المفتوح.',
    color: '#C47055'
  },
  {
    id: 'bry-6',
    title: 'Imperial Open Buffet & Five-Tier Cake Cutting',
    titleAr: 'بوفيه العشاء الإمبراطوري ومراسم تقطيع كعكة الزفاف',
    startTime: '21:15',
    endTime: '22:45',
    trackId: 'catering_hospitality',
    vendorId: 'vendor-palais-du-nil',
    vendorName: 'Palais du Nil Haute Catering',
    vendorNameAr: 'خدمات الضيافة الراقية بقصر النيل',
    zone: 'Imperial Dining Wing',
    zoneAr: 'جناح الضيافة الملكي',
    status: 'confirmed',
    notes: 'Gourmet Mediterranean & Egyptian seafood carving stations.',
    notesAr: 'محطات طهي حي ومأكولات بحرية فاخرة.',
    color: '#657B6C'
  },
  {
    id: 'bry-7',
    title: 'High-Energy DJ Set, Cold Sparks & Late Night Afterparty',
    titleAr: 'حفل الدي جي الصاخب وعروض الشرر البارد',
    startTime: '22:45',
    endTime: '01:30',
    trackId: 'lighting_sound',
    vendorId: 'vendor-dj-tamer',
    vendorName: 'DJ Tamer & Nile Sound Production',
    vendorNameAr: 'دي جي تامر وهندسة الصوت الاحترافية',
    zone: 'Main Stage & Dance Floor',
    zoneAr: 'المسرح وساحة الاحتفال الكبرى',
    status: 'confirmed',
    notes: 'Cold spark pyrotechnics sync on musical drop at 23:00.',
    notesAr: 'إطلاق شلالات الشرر البارد بالتزامن مع ذروة الموسيقى في تمام 23:00.',
    color: '#8A588C'
  }
];

export const INITIAL_ZAPIER_ZAPS: ZapierZap[] = [
  {
    id: 'zap-paypal-sync',
    title: 'PayPal Deposit Captured ➔ Multi-Channel Event Confirmation',
    titleAr: 'تأكيد عربون باي بال ➔ تنبيه واتساب وتقويم جوجل والمجلد السحابي',
    description: 'When a couple pays a milestone deposit via PayPal Smart Escrow, immediately notify the couple & vendor via WhatsApp (Twilio), schedule the event on Google Calendar with Bryntum timeline link, and spin up a shared Google Drive folder.',
    descriptionAr: 'عند إتمام دفع العربون عبر باي بال، يتم إرسال إشعار واتساب للعميل والمورد فوراً، وجدولة الموعد في تقويم جوجل، وإنشاء مجلد سحابي للمشروع.',
    enabled: true,
    triggerApp: 'paypal',
    triggerEvent: 'payment.capture.completed',
    totalRuns: 28,
    lastRun: '14 mins ago',
    steps: [
      { id: 's1', app: 'paypal', appName: 'PayPal Escrow', action: 'New Escrow Deposit Captured', actionAr: 'التقاط دفعة العربون بالضمان', icon: 'CreditCard' },
      { id: 's2', app: 'twilio', appName: 'Twilio WhatsApp', action: 'Send Bilingual WhatsApp Receipt to Couple & Vendor', actionAr: 'إرسال إيصال واتساب للطرفين', icon: 'MessageSquare' },
      { id: 's3', app: 'gcalendar', appName: 'Google Calendar', action: 'Create Wedding Block & Sync Bryntum Schedule', actionAr: 'حجز الموعد ومزامنة جدول برينتوم', icon: 'Calendar' },
      { id: 's4', app: 'gdrive', appName: 'Google Drive', action: 'Create Shared Moodboard & Contract Folder', actionAr: 'إنشاء مجلد العقود والمخططات', icon: 'Folder' }
    ],
    samplePayload: {
      event: 'paypal.escrow.milestone_paid',
      transaction_id: 'PAYID-M7X92-EGY-8921',
      event_title: "Nour & Tarek's Grand Nile Wedding",
      vendor_name: 'Palais du Nil Grand Ballroom & Gardens',
      amount_egp: 100000,
      currency: 'USD',
      converted_usd: 2032.52,
      milestone_tier: 1,
      payer_name: 'Tarek Mansour',
      payer_email: 'tarek.mansour@example.eg',
      phone_whatsapp: '+20 100 234 5678',
      bryntum_run_of_show_url: 'https://layali.eg/workspace/timeline?event=event-nour-tarek'
    }
  },
  {
    id: 'zap-inquiry-crm',
    title: 'New Vendor Inquiry ➔ Agency Slack Channel & HubSpot CRM Lead',
    titleAr: 'طلب عرض سعر جديد ➔ إشعار قناة سلاك وتسجيل العميل في هاب سبوت',
    description: 'When a couple clicks "Request Official Quotation", automatically alert the vendor on private Slack/Telegram and sync lead information to HubSpot CRM for follow-up.',
    descriptionAr: 'عند طلب عرض سعر من أي مورد، يتم إرسال تنبيه فوري لفريق العمل عبر سلاك وتسجيل بيانات العميل في نظام إدارة العملاء.',
    enabled: true,
    triggerApp: 'layali',
    triggerEvent: 'inquiry.submitted',
    totalRuns: 64,
    lastRun: '2 hours ago',
    steps: [
      { id: 's1', app: 'layali', appName: 'Layali Marketplace', action: 'New Booking Inquiry Received', actionAr: 'استلام طلب حجز أو عرض سعر', icon: 'Send' },
      { id: 's2', app: 'slack', appName: 'Slack Agency Channel', action: 'Post Rich Card to #wedding-leads Channel', actionAr: 'نشر بطاقة تفاصيل الحجز في سلاك', icon: 'Hash' },
      { id: 's3', app: 'hubspot', appName: 'HubSpot CRM', action: 'Create Deal Stage: "Quotation Pending"', actionAr: 'إنشاء صفقة جديدة في مرحلة التسعير', icon: 'TrendingUp' }
    ],
    samplePayload: {
      event: 'layali.inquiry.created',
      inquiry_id: 'inq-102',
      customer_name: 'Nour El-Din',
      customer_phone: '+20 102 889 1234',
      vendor_id: 'vendor-lumina-lighting',
      event_date: '2026-12-18',
      guest_count: 350,
      budget_tier: '85,000 EGP',
      specialty: 'Lighting Design & FX'
    }
  },
  {
    id: 'zap-bryntum-callsheet',
    title: 'Bryntum Run-of-Show Published ➔ Vendor Dispatch Call Sheets (Gmail)',
    titleAr: 'اعتماد جدول برينتوم ➔ إرسال مواعيد الحضور التفصيلية للموردين بالإيميل',
    description: 'When the wedding planner finalizes the master schedule in Bryntum, generate and email customized call sheets to each confirmed vendor with arrival times, stage zones, and technical notes.',
    descriptionAr: 'عند اعتماد التوقيتات في جدول برينتوم التفاعلي، يرسل النظام بريداً إلكترونياً رسمياً لكل مورد بموعد حضوره والموقع المخصص له.',
    enabled: true,
    triggerApp: 'bryntum',
    triggerEvent: 'timeline.published',
    totalRuns: 19,
    lastRun: 'Yesterday',
    steps: [
      { id: 's1', app: 'bryntum', appName: 'Bryntum Scheduler', action: 'Master Run-of-Show Published', actionAr: 'اعتماد ونشر جدول الفعالية', icon: 'Clock' },
      { id: 's2', app: 'gmail', appName: 'Gmail Dispatch', action: 'Email Personalized Call Sheet to All 7 Booked Vendors', actionAr: 'إرسال جدول الحضور لـ 7 موردين', icon: 'Mail' }
    ],
    samplePayload: {
      event: 'bryntum.timeline.finalized',
      event_name: "Nour & Tarek's Grand Nile Wedding",
      total_vendors: 7,
      start_time: '13:00',
      end_time: '01:30',
      coordinator: 'Orbitron Wedding Production Agency'
    }
  }
];

export const INITIAL_ZAPIER_LOGS: ZapierExecutionLog[] = [
  {
    id: 'log-101',
    zapId: 'zap-paypal-sync',
    zapTitle: 'PayPal Deposit Captured ➔ Multi-Channel Event Confirmation',
    timestamp: '2026-10-29 08:14:22',
    status: 'success',
    triggerSummary: 'PayPal Escrow Deposit Captured (100,000 EGP)',
    payloadJson: JSON.stringify({
      orderId: 'ORD-NIL-2026-101',
      transactionId: 'PAYID-M7X92-EGY-8921',
      vendor: 'Palais du Nil Grand Ballroom & Gardens',
      customer: 'Tarek Mansour',
      whatsappNotificationSent: true,
      calendarEventCreated: true,
      status: 'HTTP 200 OK'
    }, null, 2)
  },
  {
    id: 'log-102',
    zapId: 'zap-inquiry-crm',
    zapTitle: 'New Vendor Inquiry ➔ Agency Slack Channel & HubSpot CRM Lead',
    timestamp: '2026-10-29 06:30:11',
    status: 'success',
    triggerSummary: 'New Inquiry Submitted to Lumina Lighting',
    payloadJson: JSON.stringify({
      inquiryId: 'inq-102',
      customer: 'Nour El-Din',
      slackNotifiedChannel: '#wedding-leads',
      hubspotDealId: 'DEAL-99812',
      status: 'HTTP 200 OK'
    }, null, 2)
  }
];

