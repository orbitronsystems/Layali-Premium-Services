export type UserRole = 'customer' | 'vendor' | 'admin';
export type Language = 'en' | 'ar';

export type EventType = 
  | 'wedding' 
  | 'engagement' 
  | 'birthday' 
  | 'anniversary' 
  | 'baby_shower' 
  | 'graduation' 
  | 'corporate_gala' 
  | 'conference_launch' 
  | 'private_party' 
  | 'cultural_celebration';

export type VendorCategory = 
  | 'venues'
  | 'wedding_planners'
  | 'lighting_fx'
  | 'belly_dancers'
  | 'hosting_ushers'
  | 'event_management'
  | 'photography'
  | 'floral_decor'
  | 'catering'
  | 'dj_sound'
  | 'party_decor'
  | 'bridal_beauty';

export interface ServicePackage {
  id: string;
  name: string;
  nameAr: string;
  priceEgp: number;
  description: string;
  descriptionAr: string;
  features: string[];
  featuresAr: string[];
}

export interface VendorReview {
  id: string;
  author: string;
  authorAr: string;
  rating: number;
  date: string;
  comment: string;
  commentAr: string;
}

export interface Vendor {
  id: string;
  name: string;
  nameAr: string;
  category: VendorCategory;
  city: 'Cairo' | 'New Cairo' | 'Sheikh Zayed' | 'Giza' | 'Alexandria';
  cityAr: string;
  neighborhood: string;
  neighborhoodAr: string;
  phone: string;
  email: string;
  whatsapp: string;
  instagram?: string;
  startingPriceEgp: number;
  coverImage: string;
  galleryImages: string[];
  description: string;
  descriptionAr: string;
  packages: ServicePackage[];
  reviews: VendorReview[];
  rating: number;
  reviewsCount: number;
  featured?: boolean;
  status: 'active' | 'pending_approval' | 'rejected';
  capacity?: string;
  eventTypes?: EventType[];
}

export interface PinItem {
  id: string;
  vendorId: string;
  vendorName: string;
  vendorNameAr: string;
  vendorCategory: VendorCategory;
  vendorCity: string;
  vendorCityAr: string;
  vendorPhone: string;
  vendorEmail: string;
  vendorWhatsapp: string;
  vendorStartingPriceEgp: number;
  imageUrl: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  tags: string[];
  likesCount: number;
  aspectRatio: 'tall' | 'wide' | 'square';
  eventTypes: EventType[];
  collectionIds?: string[];
}

export interface CollectionItem {
  id: string;
  name: string;
  nameAr: string;
  description?: string;
  descriptionAr?: string;
  pinIds: string[];
  coverImageUrl?: string;
  createdAt: string;
}

export interface OnboardingPreferences {
  eventType: EventType;
  categories: VendorCategory[];
  city: string;
  budgetRange?: string;
  isActive: boolean;
}

export interface TaxonomyGroup {
  id: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  iconName: string;
  categories: {
    id: VendorCategory;
    name: string;
    nameAr: string;
  }[];
}

export interface EventChecklistItem {
  id: string;
  eventId: string;
  title: string;
  titleAr: string;
  category: 'venue' | 'attire' | 'photo' | 'music' | 'decor' | 'logistics';
  dueDate: string;
  completed: boolean;
  notes?: string;
}

export interface EventExpense {
  id: string;
  eventId: string;
  title: string;
  titleAr: string;
  category: 'venue' | 'catering' | 'photography' | 'decor' | 'attire' | 'entertainment' | 'other';
  amountEgp: number;
  vendorName?: string;
  paid: boolean;
  date: string;
}

export type InquiryStatus = 'draft' | 'inquiry_submitted' | 'response_received' | 'confirmed' | 'cancelled';

export interface BookingInquiry {
  id: string;
  eventId?: string;
  eventName?: string;
  vendorId: string;
  vendorName: string;
  vendorNameAr: string;
  vendorCategory: VendorCategory;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  eventType?: EventType;
  eventDate: string;
  guestCount: number;
  requirements: string;
  status: InquiryStatus;
  createdAt: string;
  quotedPriceEgp?: number;
  vendorNotes?: string;
  depositRequiredEgp?: number;
}

export interface EventModel {
  id: string;
  title: string;
  titleAr: string;
  type: EventType;
  date: string;
  city: string;
  cityAr: string;
  venueName: string;
  plannedBudgetEgp: number;
  guestCount: number;
  savedVendorIds: string[];
}

// -------------------------------------------------------------
// HACKATHON SPONSORS INTEGRATIONS: PayPal, Bryntum, Zapier
// -------------------------------------------------------------

export type CurrencyCode = 'EGP' | 'USD' | 'EUR' | 'AED';

export interface PayPalMilestone {
  tier: 1 | 2 | 3;
  name: string;
  nameAr: string;
  percentage: number;
  status: 'escrow_locked' | 'released' | 'refunded';
  amountEgp: number;
  releaseCondition: string;
  releaseConditionAr: string;
}

export interface PayPalTransaction {
  id: string; // PAYID-xxx
  orderId: string;
  vendorId: string;
  vendorName: string;
  vendorNameAr?: string;
  inquiryId?: string;
  amountEgp: number;
  currency: CurrencyCode;
  convertedAmount: number;
  tier: 1 | 2 | 3;
  tierName: string;
  status: 'escrow_held' | 'released' | 'refunded';
  date: string;
  payerEmail: string;
  payerName: string;
  payerId: string;
  notes?: string;
}

export type BryntumTrackId = 
  | 'staging' 
  | 'lighting_sound' 
  | 'photo_cinema' 
  | 'zaffa_entertainment' 
  | 'catering_hospitality';

export interface BryntumScheduleItem {
  id: string;
  title: string;
  titleAr: string;
  startTime: string; // HH:mm format e.g. "15:00"
  endTime: string;   // HH:mm format e.g. "17:30"
  trackId: BryntumTrackId;
  vendorId?: string;
  vendorName: string;
  vendorNameAr?: string;
  zone: string;
  zoneAr: string;
  status: 'confirmed' | 'in_progress' | 'completed' | 'conflict';
  notes?: string;
  notesAr?: string;
  color?: string;
}

export interface ZapierStep {
  id: string;
  app: 'paypal' | 'layali' | 'twilio' | 'gcalendar' | 'gdrive' | 'slack' | 'hubspot' | 'gmail' | 'bryntum' | 'postman';
  appName: string;
  action: string;
  actionAr: string;
  icon: string;
}

export interface ZapierZap {
  id: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  enabled: boolean;
  triggerApp: string;
  triggerEvent: string;
  steps: ZapierStep[];
  totalRuns: number;
  lastRun?: string;
  samplePayload: Record<string, any>;
}

export interface ZapierExecutionLog {
  id: string;
  zapId: string;
  zapTitle: string;
  timestamp: string;
  status: 'success' | 'filtered' | 'error';
  triggerSummary: string;
  payloadJson: string;
}

