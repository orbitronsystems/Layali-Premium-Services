import { Language, VendorCategory, InquiryStatus, EventType } from '../types';

export const TRANSLATIONS = {
  en: {
    brand: 'LAYALI',
    brandTag: 'BY ORBITRON SYSTEMS',
    platformSubtitle: 'Visual Event Discovery & Vendor Marketplace',
    demoNotice: 'Presentation Demo Mode · Orbitron Systems Client Showcase',
    demoBadge: 'CLIENT DEMO',
    
    // Nav
    navExplore: 'Explore',
    navDiscover: 'Discover',
    navCategories: 'Categories',
    navInspiration: 'Inspiration',
    navVendors: 'Vendors',
    navVenues: 'Venues',
    navServices: 'Services & Vendors',
    navMoodboard: 'Saved Boards',
    navStartPlanning: 'Plan My Event',
    navSavedCollections: 'Saved Collections',
    navWorkspace: 'Event Workspace',
    navBecomeVendor: 'Become a Vendor',
    navSignIn: 'Sign In',
    
    // View Modes
    viewModePins: 'Visual Inspiration Feed',
    viewModeVendors: 'Verified Vendors',
    viewModeMoodboard: 'My Moodboard',
    viewModeCollections: 'Saved Collections & Boards',
    
    // Roles
    roleCustomer: 'Customer View',
    roleVendor: 'Vendor Portal (Palais du Nil)',
    roleAdmin: 'Platform Administration',
    resetData: 'Reset Demo Data',
    
    // Hero
    heroPretitle: 'VISUAL EVENT DISCOVERY & VENDOR MARKETPLACE',
    heroTitle: 'Find the people behind your perfect event.',
    heroSubtitle: 'Explore authentic portfolios from Egypt’s leading venues, lighting designers, wedding planners, belly dancers, DJs, hosting agencies, and event production houses.',
    heroCtaPrimary: 'Start Planning Event',
    heroCtaSecondary: 'Explore Vendors',
    heroCtaPersonalize: 'Personalize Feed',
    heroCtaExplore: 'Browse Visual Feed',
    
    // Search & Suggestions
    searchPlaceholder: 'Search wedding décor, DJs, venues, photographers, lighting...',
    popularSuggestionsTitle: 'Popular Searches & Ideas',
    suggestion1: 'Outdoor wedding venues',
    suggestion2: 'Luxury wedding stage & Kosha',
    suggestion3: 'Cairo wedding photographers',
    suggestion4: 'Birthday party decorators',
    suggestion5: 'Belly dancers for events',
    suggestion6: 'Corporate event production',
    suggestion7: 'DJ and lighting packages',
    suggestion8: 'Gourmet wedding catering',
    
    // Event Types Shortcuts
    allEvents: 'All Events',
    evtWedding: 'Weddings',
    evtEngagement: 'Engagements',
    evtBirthday: 'Birthdays & Parties',
    evtCorporate: 'Corporate Galas',
    evtPrivate: 'Private Celebrations',
    evtCultural: 'Cultural & Zaffah',
    
    // Categories specifically requested by client
    catVenues: 'Venues & Ballrooms',
    catPlanners: 'Wedding & Event Planners',
    catLighting: 'Lighting Design & FX',
    catBellyDancers: 'Belly Dancers & Zaffah',
    catHosting: 'VIP Hostesses & Ushers',
    catEventManagement: 'Mega Event Production',
    catPhoto: 'Photography & Cinema',
    catFloral: 'Floral Designers & Kosha',
    catCatering: 'Haute Catering & Cakes',
    catDjSound: 'DJs & Live Performers',
    catPartyDecor: 'Birthday Décor & Balloons',
    catBridalBeauty: 'Bridal Couture & Styling',

    // Discovery Filters
    filterCategory: 'Category Reference',
    filterCity: 'Location in Egypt',
    filterBudget: 'Maximum Starting Budget',
    filterEventType: 'Event Type',
    sortBy: 'Sort by',
    sortFeatured: 'Featured & Trending',
    sortPriceAsc: 'Price: Low to High',
    sortPriceDesc: 'Price: High to Low',
    sortRating: 'Highest Rating',
    resultsCount: 'results available in Egypt',
    clearFilters: 'Reset Filters',
    emptyResults: 'No visual items or vendors match your filters. Try selecting another category or resetting filters.',
    
    // Onboarding Flow
    onboardingTitle: 'Personalize Your Event Discovery',
    onboardingSubtitle: 'Answer 3 quick questions to tailor your feed with the most relevant vendors and visual inspiration in Egypt.',
    onboardingStep1Question: 'What kind of celebration are you planning?',
    onboardingStep2Question: 'Which services are you most interested in?',
    onboardingStep3Question: 'Where will your event take place in Egypt?',
    onboardingStep4Question: 'What is your approximate budget?',
    onboardingSkip: 'Skip and explore all',
    onboardingBack: 'Back',
    onboardingNext: 'Next Step',
    onboardingFinish: 'View My Tailored Feed',
    tailoredFeedActive: 'Showing inspiration tailored for',
    resetTailoredFeed: 'Show all inspiration',
    changePreferences: 'Change Preferences',
    
    // Collections / Boards
    collectionsTitle: 'My Saved Collections & Moodboards',
    collectionsSubtitle: 'Organize your favorite event visuals, venues, and decor references into curated boards.',
    createCollectionBtn: 'New Collection',
    collectionNamePlaceholder: 'e.g. Dream Kosha Designs',
    saveToBoard: 'Save to Board',
    chooseCollectionTitle: 'Save Inspiration to Collection',
    savedToCollection: 'Saved to collection',
    removedFromCollection: 'Removed from collection',
    noPinsInCollection: 'No inspiration images saved in this collection yet.',
    deleteCollectionConfirm: 'Are you sure you want to delete this collection?',
    
    // Vendor Contact & Pin Card
    startingFrom: 'Starting from',
    capacity: 'Capacity',
    reviews: 'reviews',
    requestQuote: 'Request Quote',
    viewProfile: 'View Details',
    saveFavorite: 'Save',
    savedFavorite: 'Saved',
    sampleReviewNote: 'Verified Egyptian Client Review (Demo Data)',
    callVendor: 'Direct Dial Phone',
    whatsappVendor: 'Chat on WhatsApp',
    emailVendor: 'Email Vendor',
    contactVendorHeader: 'Direct Vendor Contact Info',
    seeAllInCat: 'See all verified vendors in',
    allWorksByVendor: 'View all works by this vendor',
    
    // Workspace
    workspaceTitle: 'Event Planning Workspace',
    activeEvent: 'Active Event',
    createEventBtn: 'Create New Event',
    switchEvent: 'Switch Event',
    daysRemaining: 'Days to Celebration',
    planningProgress: 'Planning Progress',
    budgetUtilization: 'Budget Spent',
    tasksCompleted: 'Tasks Completed',
    activeInquiriesCount: 'Active Inquiries',
    
    // Workspace Tabs
    tabOverview: 'Overview',
    tabChecklist: 'Checklist & Tasks',
    tabBudget: 'Budget & Expenses',
    tabVendors: 'Saved Vendors',
    tabInquiries: 'Inquiries & Quotes',
    tabTimeline: 'Run of Show & Notes',
    
    // Checklist
    addTask: 'Add New Task',
    taskFilterAll: 'All Tasks',
    taskFilterPending: 'To Do',
    taskFilterCompleted: 'Completed',
    dueOn: 'Due',
    markComplete: 'Mark complete',
    markIncomplete: 'Reopen task',
    noTasks: 'No tasks in this category yet. Click Add New Task to get started.',
    taskCategoryVenue: 'Venue',
    taskCategoryAttire: 'Attire & Beauty',
    taskCategoryPhoto: 'Photography',
    taskCategoryMusic: 'Music & Performers',
    taskCategoryDecor: 'Decor & Florals',
    taskCategoryLogistics: 'Logistics',
    
    // Budget
    plannedBudget: 'Planned Budget',
    recordedExpenses: 'Total Committed',
    remainingBudget: 'Remaining Balance',
    addExpense: 'Record Expense',
    expenseTitle: 'Expense Description',
    expenseAmount: 'Amount (EGP)',
    expenseCategory: 'Category',
    expenseVendor: 'Vendor Name (Optional)',
    expensePaid: 'Paid in Full',
    expensePending: 'Deposit / Payment Pending',
    expenseDate: 'Date',
    actions: 'Actions',
    
    // Inquiries
    inquiryStatusDraft: 'Draft',
    inquiryStatusSubmitted: 'Inquiry Submitted',
    inquiryStatusReceived: 'Quote Received',
    inquiryStatusConfirmed: 'Confirmed Booking',
    inquiryStatusCancelled: 'Cancelled',
    inquiryVendor: 'Vendor',
    inquiryEvent: 'Associated Event',
    inquiryGuestCount: 'Guests',
    inquiryRequirements: 'Event Requirements',
    inquiryQuotedPrice: 'Quoted Price',
    inquiryDeposit: 'Deposit Required',
    inquiryAcceptQuote: 'Accept & Confirm',
    inquiryDeclineQuote: 'Decline Quote',
    inquiryViewDetails: 'View Inquiry',
    
    // Inquiry Modal
    requestQuoteTitle: 'Submit Booking Inquiry',
    selectEventForInquiry: 'Select Target Event',
    yourName: 'Full Name',
    yourEmail: 'Email Address',
    yourPhone: 'Mobile Phone',
    eventDate: 'Preferred Event Date',
    guestCountInput: 'Estimated Guest Count',
    specialRequirements: 'Requirements & Inclusions',
    submitInquiryBtn: 'Send Booking Inquiry',
    inquiryDisclaimer: 'Demonstration booking flow: This sends an inquiry to the vendor demo portal without external obligations.',
    
    // Event Wizard
    wizardTitle: 'Event Planning Setup',
    wizardStep1: 'Celebration Type',
    wizardStep2: 'Date & Location',
    wizardStep3: 'Guest Count',
    wizardStep4: 'Budget Estimate',
    wizardStep5: 'Summary & Review',
    prevStep: 'Back',
    nextStep: 'Next',
    createEventSubmit: 'Create Event Workspace',
    categoryAll: 'All Categories',
    cityAll: 'All Locations (Egypt)',
    searchButton: 'Search',

    // Admin Dashboard
    adminPortalTitle: 'Platform Administration',
    adminSubtitle: 'Orbitron Systems governance, vendor approvals, and RFP management',
    kpiTotalEvents: 'Total Event Workspaces',
    kpiActiveCustomers: 'Active Event Planners',
    kpiRegisteredVendors: 'Registered Egyptian Vendors',
    kpiGrossVolume: 'Gross Budget Inquiries (EGP)',
    pendingVendorsTitle: 'Pending Partner Approvals',
    rejectVendor: 'Decline Application',
    approveVendor: 'Approve & Publish',
    allInquiriesTitle: 'All System RFPs & Bookings',

    // Vendor Portal
    vendorPortalTitle: 'Vendor Partner Portal',
    inboxTitle: 'Received Customer Inquiries',
    sendQuotationBtn: 'Send Custom Quote',
    confirmInquiryBtn: 'Confirm Direct Booking',
    quoteAmountInput: 'Official Quoted Price (EGP)',
    depositAmountInput: 'Required Advance Deposit (EGP)',
    vendorNotesInput: 'Contract Notes & Package Details',

    // Become a vendor demo
    becomeVendorTitle: 'List Your Event Business on Layali',
    becomeVendorSubtitle: 'Connect with couples, families, and corporate planners seeking high-end event services across Egypt.',
    becomeVendorSubmit: 'Submit Partner Application',
    
    // Toast
    toastVendorSaved: 'Vendor added to your event favorites',
    toastVendorRemoved: 'Vendor removed from favorites',
    toastPinLiked: 'Added to your inspiration moodboard',
    toastPinUnliked: 'Removed from your inspiration moodboard',
    toastCollectionCreated: 'New collection board created',
    toastAddedToCollection: 'Added to your collection board',
    toastTaskAdded: 'New planning task added successfully',
    toastTaskUpdated: 'Task status updated',
    toastExpenseAdded: 'Expense recorded & budget recalculated',
    toastInquirySent: 'Booking inquiry submitted to vendor',
    toastQuoteSent: 'Quotation dispatched to couple workspace',
    toastInquiryConfirmed: 'Booking confirmed and added to calendar',
    toastVendorApproved: 'Vendor application approved and published',
    toastDataReset: 'Demo state has been restored to default sample data'
  },
  
  ar: {
    brand: 'ليالي',
    brandTag: 'بواسطة أنظمة أوربيترون',
    platformSubtitle: 'منصة اكتشاف الفعاليات البصرية وسوق الموردين الفاخر',
    demoNotice: 'العرض التوضيحي التنفيذي · عرض خاص لعملاء أوربيترون سيستمز',
    demoBadge: 'عرض توضيحي',
    
    // Nav
    navExplore: 'استكشف',
    navDiscover: 'استكشف',
    navCategories: 'التصنيفات',
    navInspiration: 'معرض الإلهام',
    navVendors: 'الموردون',
    navVenues: 'القاعات',
    navServices: 'الموردون والخدمات',
    navMoodboard: 'اللوحات المحفوظة',
    navStartPlanning: 'ابدأ التخطيط',
    navSavedCollections: 'لوحاتي المحفوظة',
    navWorkspace: 'مساحة تخطيط الحدث',
    navBecomeVendor: 'انضم كمورد',
    navSignIn: 'تسجيل الدخول',
    
    // View Modes
    viewModePins: 'معرض الصور والإلهام (بينترست)',
    viewModeVendors: 'الموردون المعتمدون',
    viewModeMoodboard: 'لوحة إلهامي',
    viewModeCollections: 'لوحات الصور المحفوظة والمجموعات',
    
    // Roles
    roleCustomer: 'واجهة العميل',
    roleVendor: 'بوابة المورد (قصر النيل)',
    roleAdmin: 'لوحة التحكم الإدارية للمنصة',
    resetData: 'استعادة بيانات العرض التجريبي',
    
    // Hero
    heroPretitle: 'اكتشاف بصري فاخر وسوق الموردين المعتمدين',
    heroTitle: 'اكتشف المبدعين وراء حفل مناسبتك القادمة.',
    heroSubtitle: 'استكشف ألبومات وأعمال أرقى القاعات، مهندسي الإضاءة، منظمي الأفراح، الراقصات والزفة، الدي جي، وشركات الإنتاج الكبرى في مصر.',
    heroCtaPrimary: 'ابدأ تخطيط حفل الزفاف',
    heroCtaSecondary: 'استكشف الموردين المعتمدين',
    heroCtaPersonalize: 'تخصيص المعرض لحدثي',
    heroCtaExplore: 'تصفح معرض الإلهام',
    
    // Search & Suggestions
    searchPlaceholder: 'ابحث عن ديكور زفاف، دي جي، قاعات، مصورين، إضاءة...',
    popularSuggestionsTitle: 'أفكار وعمليات بحث شائعة',
    suggestion1: 'قاعات أفراح مفتوحة على النيل',
    suggestion2: 'كوشة ومسرح زفاف فاخر',
    suggestion3: 'مصورو أفراح سينمائيون في القاهرة',
    suggestion4: 'ديكورات حفلات أعياد الميلاد والبالونات',
    suggestion5: 'راقصات شرقيات لحفلات الزفاف',
    suggestion6: 'إنتاج الفعاليات الكبرى أمام الأهرامات',
    suggestion7: 'باقات الدي جي والإضاءة المعمارية',
    suggestion8: 'بوفيهات وضيافة الأعراس الملكية',
    
    // Event Types Shortcuts
    allEvents: 'كافة المناسبات',
    evtWedding: 'حفلات الزفاف',
    evtEngagement: 'حفلات الخطوبة',
    evtBirthday: 'أعياد الميلاد والحفلات',
    evtCorporate: 'الفعاليات المؤسسية',
    evtPrivate: 'السهرات الخاصة',
    evtCultural: 'الزفة والمناسبات التراثية',
    
    // Categories specifically requested by client
    catVenues: 'القاعات والقصور',
    catPlanners: 'منظمو حفلات الزفاف',
    catLighting: 'هندسة الإضاءة والمؤثرات',
    catBellyDancers: 'الراقصات والزفة التراثية',
    catHosting: 'مضيفات كبار الشخصيات والمراسم',
    catEventManagement: 'إدارة وإنتاج الفعاليات الكبرى',
    catPhoto: 'التصوير الفوتوغرافي والسينما',
    catFloral: 'تصميم الزهور والكوشة',
    catCatering: 'الضيافة وبوفيهات الحلويات',
    catDjSound: 'الدي جي والعازفون الحيون',
    catPartyDecor: 'ديكورات الحفلات والبالونات',
    catBridalBeauty: 'أزياء العرائس والجمال',

    // Discovery Filters
    filterCategory: 'التصنيف المرجعي',
    filterCity: 'المحافظة / المنطقة',
    filterBudget: 'الحد الأقصى للميزانية الأولية',
    filterEventType: 'نوع المناسبة',
    sortBy: 'الترتيب حسب',
    sortFeatured: 'الموصى به والأكثر رواجاً',
    sortPriceAsc: 'السعر: من الأقل للأعلى',
    sortPriceDesc: 'السعر: من الأعلى للأقل',
    sortRating: 'الأعلى تقييماً',
    resultsCount: 'نتيجة متاحة في مصر',
    clearFilters: 'إعادة ضبط الفلاتر',
    emptyResults: 'لم يتم العثور على نتائج في هذا التصنيف. يرجى تجربة تصنيف آخر.',
    
    // Onboarding Flow
    onboardingTitle: 'تخصيص تجربة اكتشاف مناسبتك',
    onboardingSubtitle: 'أجب عن ٣ أسئلة سريعة لتخصيص معرض الصور والموردين وفقاً لنوع حدثك وموقعك وميزانيتك في مصر.',
    onboardingStep1Question: 'ما نوع المناسبة التي تخطط لها؟',
    onboardingStep2Question: 'ما هي أهم الخدمات التي تبحث عنها أولاً؟',
    onboardingStep3Question: 'أين ستقام مناسبتك في مصر؟',
    onboardingStep4Question: 'ما هي الميزانية التقديرية للحفل؟',
    onboardingSkip: 'تخطي واستكشاف الكل',
    onboardingBack: 'السابق',
    onboardingNext: 'الخطوة التالية',
    onboardingFinish: 'عرض المعرض المخصص لي',
    tailoredFeedActive: 'يتم عرض إلهام مخصص لمناسبة',
    resetTailoredFeed: 'عرض كافة الإلهامات',
    changePreferences: 'تعديل التفضيلات',
    
    // Collections / Boards
    collectionsTitle: 'لوحاتي المحفوظة ومجموعات الإلهام',
    collectionsSubtitle: 'نظّم صور الديكور، القاعات، وأفكار الإضاءة المفضلة في لوحات مخصصة لمناسبتك.',
    createCollectionBtn: 'إنشاء لوحة جديدة',
    collectionNamePlaceholder: 'مثال: تصميمات الكوشة المفضلة',
    saveToBoard: 'حفظ في لوحة',
    chooseCollectionTitle: 'اختر اللوحة لحفظ الإلهام',
    savedToCollection: 'تم الحفظ في اللوحة بنجاح',
    removedFromCollection: 'تمت إزالة الصورة من اللوحة',
    noPinsInCollection: 'لا توجد صور محفوظة في هذه اللوحة بعد.',
    deleteCollectionConfirm: 'هل أنت متأكد من حذف هذه اللوحة؟',
    
    // Vendor Contact & Pin Card
    startingFrom: 'يبدأ من',
    capacity: 'السعة الاستيعابية',
    reviews: 'تقييم',
    requestQuote: 'طلب عرض سعر',
    viewProfile: 'عرض التفاصيل',
    saveFavorite: 'حفظ للمفضلة',
    savedFavorite: 'تم الحفظ',
    sampleReviewNote: 'تقييم معتمد من عميل مصري (بيانات تجريبية)',
    callVendor: 'الاتصال الهاتفي المباشر',
    whatsappVendor: 'محادثة عبر واتساب',
    emailVendor: 'إرسال بريد إلكتروني',
    contactVendorHeader: 'بيانات التواصل المباشر مع المورد',
    seeAllInCat: 'استعراض كافة الموردين في تصنيف',
    allWorksByVendor: 'مشاهدة كافة أعمال هذا المورد',
    
    // Workspace
    workspaceTitle: 'مساحة إدارة وتنسيق الفعالية',
    activeEvent: 'الحدث الحالي',
    createEventBtn: 'إنشاء حدث جديد',
    switchEvent: 'تبديل الحدث',
    daysRemaining: 'يوم متبقي على الحفل',
    planningProgress: 'نسبة إنجاز التخطيط',
    budgetUtilization: 'المصروف من الميزانية',
    tasksCompleted: 'المهام المنجزة',
    activeInquiriesCount: 'طلبات الحجز الحالية',
    
    // Workspace Tabs
    tabOverview: 'نظرة عامة',
    tabChecklist: 'قائمة المهام والجدول',
    tabBudget: 'الميزانية والمصروفات',
    tabVendors: 'الموردون المفضلون',
    tabInquiries: 'عروض الأسعار والحجوزات',
    tabTimeline: 'جدول اليوم والملاحظات',
    
    // Checklist
    addTask: 'إضافة مهمة جديدة',
    taskFilterAll: 'كافة المهام',
    taskFilterPending: 'قيد التنفيذ',
    taskFilterCompleted: 'المكتملة',
    dueOn: 'موعد الإنجاز',
    markComplete: 'تحديد كمكتملة',
    markIncomplete: 'إعادة فتح المهمة',
    noTasks: 'لا توجد مهام في هذا التصنيف حالياً. انقر على إضافة مهمة لبدء التخطيط.',
    taskCategoryVenue: 'المكان والقاعة',
    taskCategoryAttire: 'أزياء العرائس',
    taskCategoryPhoto: 'التصوير',
    taskCategoryMusic: 'الموسيقى والترفيه',
    taskCategoryDecor: 'الديكور والزهور',
    taskCategoryLogistics: 'اللوجستيات والمراسم',
    
    // Budget
    plannedBudget: 'الميزانية المحددة',
    recordedExpenses: 'إجمالي المصروفات والالتزامات',
    remainingBudget: 'المبلغ المتبقي',
    addExpense: 'تسجيل بند مصروف',
    expenseTitle: 'بيان المصروف',
    expenseAmount: 'المبلغ (جنيه مصري)',
    expenseCategory: 'التصنيف',
    expenseVendor: 'اسم المورد (اختياري)',
    expensePaid: 'مدفوع بالكامل',
    expensePending: 'مستحق / عربون معلق',
    expenseDate: 'التاريخ',
    actions: 'الإجراءات',
    
    // Inquiries
    inquiryStatusDraft: 'مسودة',
    inquiryStatusSubmitted: 'تم تقديم طلب السعر',
    inquiryStatusReceived: 'تم استلام عرض السعر',
    inquiryStatusConfirmed: 'حجز مؤكد رسمياً',
    inquiryStatusCancelled: 'ملغي',
    inquiryVendor: 'المورد',
    inquiryEvent: 'الحدث المرتبط',
    inquiryGuestCount: 'عدد الضيوف',
    inquiryRequirements: 'متطلبات وتفاصيل الحفل',
    inquiryQuotedPrice: 'السعر المقدم في العرض',
    inquiryDeposit: 'العربون المطلوب',
    inquiryAcceptQuote: 'الموافقة وتأكيد الحجز',
    inquiryDeclineQuote: 'رفض العرض',
    inquiryViewDetails: 'معاينة الطلب',
    
    // Inquiry Modal
    requestQuoteTitle: 'طلب عرض سعر وباقة مخصصة',
    selectEventForInquiry: 'اختر الحدث المستهدف',
    yourName: 'الاسم بالكامل',
    yourEmail: 'البريد الإلكتروني',
    yourPhone: 'رقم الهاتف المحمول',
    eventDate: 'تاريخ الحدث المقترح',
    guestCountInput: 'العدد التقديري للضيوف',
    specialRequirements: 'المتطلبات الخاصة والتفاصيل',
    submitInquiryBtn: 'إرسال طلب عرض السعر',
    inquiryDisclaimer: 'نموذج تجريبي تفاعلي: يرسل الطلب مباشرة إلى بوابة المورد في العرض دون أي التزام مالي خارجي.',

    // Event Wizard
    wizardTitle: 'إعداد وتنظيم الحدث',
    wizardStep1: 'نوع المناسبة',
    wizardStep2: 'الموعد والمكان',
    wizardStep3: 'عدد الضيوف',
    wizardStep4: 'تقدير الميزانية',
    wizardStep5: 'الملخص والتأكيد',
    prevStep: 'السابق',
    nextStep: 'التالي',
    createEventSubmit: 'إنشاء مساحة التخطيط',
    
    // Admin Dashboard
    adminPortalTitle: 'لوحة التحكم الإدارية',
    adminSubtitle: 'حوكمة أنظمة أوربيترون، اعتماد الموردين ومتابعة مؤشرات الطلبات',
    kpiTotalEvents: 'إجمالي أحداث التخطيط',
    kpiActiveCustomers: 'منظمو الحفلات النشطون',
    kpiRegisteredVendors: 'الموردون المعتمدون في مصر',
    kpiGrossVolume: 'إجمالي حجم الميزانيات (ج.م)',
    pendingVendorsTitle: 'طلبات انضمام الموردين المعلقة',
    rejectVendor: 'رفض الطلب',
    approveVendor: 'اعتماد ونشر المورد',
    allInquiriesTitle: 'سجل طلبات الأسعار والحجوزات',

    // Discovery & Search Helpers
    categoryAll: 'جميع الأقسام',
    cityAll: 'كافة المناطق (مصر)',
    searchButton: 'بحث',

    // Vendor Portal
    vendorPortalTitle: 'بوابة الشريك المعتمد',
    inboxTitle: 'طلبات العملاء المستلمة',
    sendQuotationBtn: 'إرسال عرض سعر مخصص',
    confirmInquiryBtn: 'تأكيد الحجز المباشر',
    quoteAmountInput: 'السعر الإجمالي المقترح (جنيه مصري)',
    depositAmountInput: 'مبلغ العربون المطلوب (جنيه مصري)',
    vendorNotesInput: 'ملاحظات العقد ومواصفات الباقة',

    // Become a vendor demo
    becomeVendorTitle: 'سجل شركتك أو خدماتك في منصة ليالي',
    becomeVendorSubtitle: 'تواصل مباشرة مع العائلات والشركات والمقبلين على الزواج الباحثين عن خدمات فعاليات راقية في مصر.',
    becomeVendorSubmit: 'تقديم طلب الانضمام كشريك',
    
    // Toast
    toastVendorSaved: 'تمت إضافة المورد إلى قائمة مفضلة الحدث',
    toastVendorRemoved: 'تمت إزالة المورد من المفضلة',
    toastPinLiked: 'تمت إضافة الصورة إلى لوحة إلهامك',
    toastPinUnliked: 'تمت إزالة الصورة من لوحة الإلهام',
    toastCollectionCreated: 'تم إنشاء لوحة مجموعة جديدة بنجاح',
    toastAddedToCollection: 'تمت إضافة الإلهام إلى لوحتك بنجاح',
    toastTaskAdded: 'تمت إضافة مهمة تخطيط جديدة بنجاح',
    toastTaskUpdated: 'تم تحديث حالة المهمة',
    toastExpenseAdded: 'تم تسجيل المصروف وإعادة حساب الميزانية فوراً',
    toastInquirySent: 'تم إرسال طلب عرض السعر إلى بوابة المورد',
    toastQuoteSent: 'تم إرسال عرض السعر إلى مساحة العميل بنجاح',
    toastInquiryConfirmed: 'تم تأكيد الحجز وإدراجه في جدول الحدث',
    toastVendorApproved: 'تم اعتماد المورد ونشره في دليل المنصة',
    toastDataReset: 'تمت استعادة البيانات التوضيحية الافتراضية بنجاح'
  }
};

export function formatEgp(amount: number, lang: Language): string {
  const formatted = new Intl.NumberFormat(lang === 'ar' ? 'ar-EG' : 'en-EG').format(amount);
  return lang === 'ar' ? `${formatted} ج.م` : `${formatted} EGP`;
}

export function getCategoryLabel(category: VendorCategory, lang: Language): string {
  const dict = TRANSLATIONS[lang];
  switch (category) {
    case 'venues': return dict.catVenues;
    case 'wedding_planners': return dict.catPlanners;
    case 'lighting_fx': return dict.catLighting;
    case 'belly_dancers': return dict.catBellyDancers;
    case 'hosting_ushers': return dict.catHosting;
    case 'event_management': return dict.catEventManagement;
    case 'photography': return dict.catPhoto;
    case 'floral_decor': return dict.catFloral;
    case 'catering': return dict.catCatering;
    case 'dj_sound': return dict.catDjSound;
    case 'party_decor': return dict.catPartyDecor;
    case 'bridal_beauty': return dict.catBridalBeauty;
    default: return category;
  }
}

export function getEventTypeName(type: EventType, lang: Language): string {
  const dict = TRANSLATIONS[lang];
  switch (type) {
    case 'wedding': return dict.evtWedding;
    case 'engagement': return dict.evtEngagement;
    case 'birthday': return dict.evtBirthday;
    case 'corporate_gala': return dict.evtCorporate;
    case 'conference_launch': return dict.evtCorporate;
    case 'private_party': return dict.evtPrivate;
    case 'anniversary': return dict.evtPrivate;
    case 'cultural_celebration': return dict.evtCultural;
    default: return type;
  }
}

export function getInquiryStatusLabel(status: InquiryStatus, lang: Language): { label: string; color: string } {
  const dict = TRANSLATIONS[lang];
  switch (status) {
    case 'draft':
      return { label: dict.inquiryStatusDraft, color: 'text-stone-600 bg-stone-100' };
    case 'inquiry_submitted':
      return { label: dict.inquiryStatusSubmitted, color: 'text-amber-800 bg-amber-50' };
    case 'response_received':
      return { label: dict.inquiryStatusReceived, color: 'text-blue-800 bg-blue-50' };
    case 'confirmed':
      return { label: dict.inquiryStatusConfirmed, color: 'text-emerald-800 bg-emerald-50' };
    case 'cancelled':
      return { label: dict.inquiryStatusCancelled, color: 'text-rose-800 bg-rose-50' };
  }
}
