import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  UserRole, 
  Language, 
  Vendor, 
  EventModel, 
  EventChecklistItem, 
  EventExpense, 
  BookingInquiry,
  PinItem,
  VendorCategory,
  CollectionItem,
  OnboardingPreferences,
  PayPalTransaction,
  BryntumScheduleItem,
  ZapierZap,
  ZapierExecutionLog,
  ServicePackage
} from '../types';
import { 
  INITIAL_VENDORS, 
  INITIAL_EVENTS, 
  INITIAL_CHECKLIST, 
  INITIAL_EXPENSES, 
  INITIAL_INQUIRIES,
  INITIAL_PINS,
  INITIAL_COLLECTIONS,
  INITIAL_PAYPAL_TRANSACTIONS,
  INITIAL_BRYNTUM_SCHEDULE,
  INITIAL_ZAPIER_ZAPS,
  INITIAL_ZAPIER_LOGS
} from '../data/mockData';
import { TRANSLATIONS } from '../utils/translations';

interface ToastState {
  id: number;
  message: string;
}

export type ViewType = 
  | 'home' 
  | 'discovery' 
  | 'collections' 
  | 'workspace' 
  | 'inquiries' 
  | 'category' 
  | 'bryntum_timeline' 
  | 'zapier_automations' 
  | 'paypal_escrow'
  | 'postman_api';

export interface PayPalCheckoutTarget {
  vendor: Vendor;
  inquiryId?: string;
  package?: ServicePackage;
  quoteAmountEgp?: number;
  depositAmountEgp?: number;
  eventId?: string;
}

interface AppContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  
  // Pinterest Feed state
  pins: PinItem[];
  likedPinIds: string[];
  toggleLikePin: (pinId: string) => void;
  selectedPin: PinItem | null;
  setSelectedPinId: (pinId: string | null) => void;
  feedCategoryFilter: string;
  setFeedCategoryFilter: (cat: string) => void;
  feedViewMode: 'pins' | 'vendors' | 'moodboard';
  setFeedViewMode: (mode: 'pins' | 'vendors' | 'moodboard') => void;

  // Collections / Boards
  collections: CollectionItem[];
  activeCollectionId: string | null;
  setActiveCollectionId: (id: string | null) => void;
  createCollection: (name: string, nameAr?: string, description?: string) => string;
  deleteCollection: (id: string) => void;
  renameCollection: (id: string, name: string, nameAr?: string) => void;
  savePinToCollection: (pinId: string, collectionId: string) => void;
  removePinFromCollection: (pinId: string, collectionId: string) => void;
  saveTargetPin: PinItem | null;
  openSaveToCollectionModal: (pin: PinItem) => void;
  closeSaveToCollectionModal: () => void;

  // Onboarding & Personalization
  onboarding: OnboardingPreferences | null;
  saveOnboardingPreferences: (prefs: OnboardingPreferences) => void;
  clearOnboardingPreferences: () => void;
  isOnboardingModalOpen: boolean;
  setIsOnboardingModalOpen: (open: boolean) => void;

  // Category Landing Page
  activeCategoryPage: VendorCategory | null;
  openCategoryPage: (category: VendorCategory) => void;

  // Selection modals
  selectedVendor: Vendor | null;
  setSelectedVendorId: (vendorId: string | null) => void;
  inquiryTargetVendor: Vendor | null;
  openInquiryModal: (vendor: Vendor) => void;
  closeInquiryModal: () => void;
  isEventWizardOpen: boolean;
  setIsEventWizardOpen: (open: boolean) => void;

  // Data & active state
  events: EventModel[];
  activeEvent: EventModel;
  setActiveEventId: (id: string) => void;
  vendors: Vendor[];
  checklist: EventChecklistItem[];
  expenses: EventExpense[];
  inquiries: BookingInquiry[];
  
  // Handlers
  toggleSaveVendor: (vendorId: string) => void;
  createNewEvent: (eventData: { title: string; titleAr: string; type: any; date: string; city: string; cityAr: string; venueName: string; plannedBudgetEgp: number; guestCount: number }) => void;
  addChecklistTask: (task: { title: string; titleAr: string; category: any; dueDate: string; notes?: string }) => void;
  toggleTaskCompletion: (taskId: string) => void;
  deleteChecklistTask: (taskId: string) => void;
  addExpenseItem: (expense: { title: string; titleAr: string; category: any; amountEgp: number; vendorName?: string; paid: boolean; date: string }) => void;
  deleteExpenseItem: (expenseId: string) => void;
  submitBookingInquiry: (inquiry: { eventId: string; vendorId: string; customerName: string; customerEmail: string; customerPhone: string; eventDate: string; guestCount: number; requirements: string }) => void;
  vendorRespondQuote: (inquiryId: string, quoteEgp: number, depositEgp: number, notes: string) => void;
  vendorConfirmInquiry: (inquiryId: string) => void;
  customerAcceptQuote: (inquiryId: string) => void;
  customerDeclineQuote: (inquiryId: string) => void;
  adminApproveVendor: (vendorId: string) => void;
  adminRejectVendor: (vendorId: string) => void;
  resetDemoData: () => void;

  // -------------------------------------------------------------
  // SPONSORS: PayPal, Bryntum, Zapier
  // -------------------------------------------------------------
  // 1. PayPal
  payPalTransactions: PayPalTransaction[];
  isPayPalModalOpen: boolean;
  payPalTarget: PayPalCheckoutTarget | null;
  openPayPalModal: (target: PayPalCheckoutTarget) => void;
  closePayPalModal: () => void;
  processPayPalPayment: (tx: PayPalTransaction) => void;
  releaseEscrowMilestone: (transactionId: string) => void;
  refundEscrowTransaction: (transactionId: string) => void;
  vendorPayPalBalance: number;
  withdrawVendorPayoutPayPal: (amountEgp: number, paypalEmail: string) => void;

  // 2. Bryntum
  bryntumSchedule: BryntumScheduleItem[];
  addScheduleItem: (item: Omit<BryntumScheduleItem, 'id'>) => void;
  updateScheduleItem: (id: string, updates: Partial<BryntumScheduleItem>) => void;
  deleteScheduleItem: (id: string) => void;
  resetBryntumPreset: (preset: 'cairo_wedding' | 'gouna_beach' | 'corporate_gala') => void;

  // 3. Zapier
  zaps: ZapierZap[];
  zapierLogs: ZapierExecutionLog[];
  toggleZap: (zapId: string) => void;
  testRunZap: (zapId: string) => Promise<{ success: boolean; log: ZapierExecutionLog }>;
  activeZapTestingId: string | null;

  // Toast
  toast: ToastState | null;
  showToast: (message: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

const STORAGE_KEY_PREFIX = 'layali_egypt_demo_v2_';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRoleState] = useState<UserRole>(() => {
    return (localStorage.getItem(`${STORAGE_KEY_PREFIX}role`) as UserRole) || 'customer';
  });

  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem(`${STORAGE_KEY_PREFIX}lang`) as Language) || 'en';
  });

  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [selectedVendorId, setSelectedVendorId] = useState<string | null>(null);
  const [selectedPinId, setSelectedPinId] = useState<string | null>(null);
  const [inquiryTargetVendor, setInquiryTargetVendor] = useState<Vendor | null>(null);
  const [isEventWizardOpen, setIsEventWizardOpen] = useState(false);

  // Pinterest state
  const [feedCategoryFilter, setFeedCategoryFilter] = useState<string>('all');
  const [feedViewMode, setFeedViewMode] = useState<'pins' | 'vendors' | 'moodboard'>('pins');

  const [pins, setPins] = useState<PinItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}pins`);
    return saved ? JSON.parse(saved) : INITIAL_PINS;
  });

  const [likedPinIds, setLikedPinIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}liked_pins`);
    return saved ? JSON.parse(saved) : ['pin-lighting-arch', 'pin-bellydancer-zaffah'];
  });

  // Collections state
  const [collections, setCollections] = useState<CollectionItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}collections`);
    return saved ? JSON.parse(saved) : INITIAL_COLLECTIONS;
  });
  const [activeCollectionId, setActiveCollectionId] = useState<string | null>(null);
  const [saveTargetPin, setSaveTargetPin] = useState<PinItem | null>(null);

  // Onboarding state
  const [onboarding, setOnboarding] = useState<OnboardingPreferences | null>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}onboarding`);
    return saved ? JSON.parse(saved) : null;
  });
  const [isOnboardingModalOpen, setIsOnboardingModalOpen] = useState(false);

  // Category page state
  const [activeCategoryPage, setActiveCategoryPage] = useState<VendorCategory | null>(null);

  const [events, setEvents] = useState<EventModel[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}events`);
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  const [activeEventId, setActiveEventId] = useState<string>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}active_event`);
    return saved || INITIAL_EVENTS[0].id;
  });

  const [vendors, setVendors] = useState<Vendor[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}vendors`);
    return saved ? JSON.parse(saved) : INITIAL_VENDORS;
  });

  const [checklist, setChecklist] = useState<EventChecklistItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}checklist`);
    return saved ? JSON.parse(saved) : INITIAL_CHECKLIST;
  });

  const [expenses, setExpenses] = useState<EventExpense[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}expenses`);
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  const [inquiries, setInquiries] = useState<BookingInquiry[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}inquiries`);
    return saved ? JSON.parse(saved) : INITIAL_INQUIRIES;
  });

  const [toast, setToast] = useState<ToastState | null>(null);

  // -------------------------------------------------------------
  // SPONSORS STATE: PayPal, Bryntum, Zapier
  // -------------------------------------------------------------
  // 1. PayPal Escrow State
  const [payPalTransactions, setPayPalTransactions] = useState<PayPalTransaction[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}paypal_txs`);
    return saved ? JSON.parse(saved) : INITIAL_PAYPAL_TRANSACTIONS;
  });
  const [isPayPalModalOpen, setIsPayPalModalOpen] = useState(false);
  const [payPalTarget, setPayPalTarget] = useState<PayPalCheckoutTarget | null>(null);
  const [vendorPayPalBalance, setVendorPayPalBalance] = useState<number>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}vendor_paypal_bal`);
    return saved ? Number(saved) : 100000;
  });

  // 2. Bryntum Scheduler State
  const [bryntumSchedule, setBryntumSchedule] = useState<BryntumScheduleItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}bryntum_schedule`);
    return saved ? JSON.parse(saved) : INITIAL_BRYNTUM_SCHEDULE;
  });

  // 3. Zapier Automations State
  const [zaps, setZaps] = useState<ZapierZap[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}zaps`);
    return saved ? JSON.parse(saved) : INITIAL_ZAPIER_ZAPS;
  });
  const [zapierLogs, setZapierLogs] = useState<ZapierExecutionLog[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}zapier_logs`);
    return saved ? JSON.parse(saved) : INITIAL_ZAPIER_LOGS;
  });
  const [activeZapTestingId, setActiveZapTestingId] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}paypal_txs`, JSON.stringify(payPalTransactions));
  }, [payPalTransactions]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}vendor_paypal_bal`, vendorPayPalBalance.toString());
  }, [vendorPayPalBalance]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}bryntum_schedule`, JSON.stringify(bryntumSchedule));
  }, [bryntumSchedule]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}zaps`, JSON.stringify(zaps));
  }, [zaps]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}zapier_logs`, JSON.stringify(zapierLogs));
  }, [zapierLogs]);

  // Sync HTML dir and lang
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    localStorage.setItem(`${STORAGE_KEY_PREFIX}lang`, language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}role`, role);
  }, [role]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}liked_pins`, JSON.stringify(likedPinIds));
  }, [likedPinIds]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}pins`, JSON.stringify(pins));
  }, [pins]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}collections`, JSON.stringify(collections));
  }, [collections]);

  useEffect(() => {
    if (onboarding) {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}onboarding`, JSON.stringify(onboarding));
    }
  }, [onboarding]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}events`, JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}active_event`, activeEventId);
  }, [activeEventId]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}vendors`, JSON.stringify(vendors));
  }, [vendors]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}checklist`, JSON.stringify(checklist));
  }, [checklist]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}expenses`, JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}inquiries`, JSON.stringify(inquiries));
  }, [inquiries]);

  const showToast = (message: string) => {
    const id = Date.now();
    setToast({ id, message });
    setTimeout(() => {
      setToast((prev) => (prev?.id === id ? null : prev));
    }, 3800);
  };

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    if (newRole === 'vendor') {
      setCurrentView('workspace');
    } else if (newRole === 'admin') {
      setCurrentView('workspace');
    }
  };

  const activeEvent = events.find((e) => e.id === activeEventId) || events[0] || INITIAL_EVENTS[0];
  const selectedVendor = vendors.find((v) => v.id === selectedVendorId) || null;
  const selectedPin = pins.find((p) => p.id === selectedPinId) || null;

  const toggleLikePin = (pinId: string) => {
    setLikedPinIds((prev) => {
      const isLiked = prev.includes(pinId);
      const updated = isLiked ? prev.filter((id) => id !== pinId) : [...prev, pinId];
      showToast(isLiked ? TRANSLATIONS[language].toastPinUnliked : TRANSLATIONS[language].toastPinLiked);
      return updated;
    });
  };

  // Collections & Boards handlers
  const createCollection = (name: string, nameAr?: string, description?: string): string => {
    const newId = `col-${Date.now()}`;
    const newCol: CollectionItem = {
      id: newId,
      name,
      nameAr: nameAr || name,
      description: description || '',
      descriptionAr: description || '',
      pinIds: [],
      createdAt: new Date().toISOString().split('T')[0]
    };
    setCollections((prev) => [newCol, ...prev]);
    showToast(language === 'ar' ? `تم إنشاء لوحة "${newCol.nameAr}"` : `Created board "${newCol.name}"`);
    return newId;
  };

  const deleteCollection = (id: string) => {
    setCollections((prev) => prev.filter((c) => c.id !== id));
    if (activeCollectionId === id) {
      setActiveCollectionId(null);
    }
    showToast(language === 'ar' ? 'تم حذف اللوحة' : 'Collection board deleted');
  };

  const renameCollection = (id: string, name: string, nameAr?: string) => {
    setCollections((prev) =>
      prev.map((c) => (c.id === id ? { ...c, name, nameAr: nameAr || name } : c))
    );
    showToast(language === 'ar' ? 'تم تحديث اسم اللوحة' : 'Collection renamed');
  };

  const savePinToCollection = (pinId: string, collectionId: string) => {
    setCollections((prev) =>
      prev.map((col) => {
        if (col.id === collectionId) {
          if (!col.pinIds.includes(pinId)) {
            const pin = pins.find((p) => p.id === pinId);
            return {
              ...col,
              pinIds: [...col.pinIds, pinId],
              coverImageUrl: col.coverImageUrl || pin?.imageUrl
            };
          }
        }
        return col;
      })
    );

    setPins((prev) =>
      prev.map((pin) => {
        if (pin.id === pinId) {
          const current = pin.collectionIds || [];
          if (!current.includes(collectionId)) {
            return { ...pin, collectionIds: [...current, collectionId] };
          }
        }
        return pin;
      })
    );

    const targetCol = collections.find((c) => c.id === collectionId);
    showToast(
      language === 'ar'
        ? `تم الحفظ في لوحة "${targetCol?.nameAr || ''}"`
        : `Saved to "${targetCol?.name || 'Board'}"`
    );
    setSaveTargetPin(null);
  };

  const removePinFromCollection = (pinId: string, collectionId: string) => {
    setCollections((prev) =>
      prev.map((col) => {
        if (col.id === collectionId) {
          return {
            ...col,
            pinIds: col.pinIds.filter((id) => id !== pinId)
          };
        }
        return col;
      })
    );

    setPins((prev) =>
      prev.map((pin) => {
        if (pin.id === pinId && pin.collectionIds) {
          return {
            ...pin,
            collectionIds: pin.collectionIds.filter((id) => id !== collectionId)
          };
        }
        return pin;
      })
    );

    showToast(language === 'ar' ? 'تم إزالة الصورة من اللوحة' : 'Removed from collection');
  };

  const openSaveToCollectionModal = (pin: PinItem) => {
    setSaveTargetPin(pin);
  };

  const closeSaveToCollectionModal = () => {
    setSaveTargetPin(null);
  };

  // Onboarding handlers
  const saveOnboardingPreferences = (prefs: OnboardingPreferences) => {
    setOnboarding(prefs);
    setIsOnboardingModalOpen(false);
    showToast(language === 'ar' ? 'تم تخصيص الخلاصة لحدثك بنجاح!' : 'Your event feed has been personalized!');
  };

  const clearOnboardingPreferences = () => {
    setOnboarding(null);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}onboarding`);
    showToast(language === 'ar' ? 'تم استعادة الخلاصة العامة' : 'Feed reset to general view');
  };

  // Category page handler
  const openCategoryPage = (category: VendorCategory) => {
    setActiveCategoryPage(category);
    setCurrentView('category');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openInquiryModal = (vendor: Vendor) => {
    setInquiryTargetVendor(vendor);
  };

  const closeInquiryModal = () => {
    setInquiryTargetVendor(null);
  };

  const toggleSaveVendor = (vendorId: string) => {
    setEvents((prev) =>
      prev.map((ev) => {
        if (ev.id === activeEventId) {
          const isSaved = ev.savedVendorIds.includes(vendorId);
          const updated = isSaved
            ? ev.savedVendorIds.filter((id) => id !== vendorId)
            : [...ev.savedVendorIds, vendorId];
          showToast(
            isSaved
              ? TRANSLATIONS[language].toastVendorRemoved
              : TRANSLATIONS[language].toastVendorSaved
          );
          return { ...ev, savedVendorIds: updated };
        }
        return ev;
      })
    );
  };

  const createNewEvent = (data: {
    title: string;
    titleAr: string;
    type: any;
    date: string;
    city: string;
    cityAr: string;
    venueName: string;
    plannedBudgetEgp: number;
    guestCount: number;
  }) => {
    const newId = `event-${Date.now()}`;
    const newEvent: EventModel = {
      id: newId,
      ...data,
      savedVendorIds: []
    };
    setEvents((prev) => [newEvent, ...prev]);
    setActiveEventId(newId);
    setIsEventWizardOpen(false);
    setCurrentView('workspace');
    showToast(
      language === 'ar'
        ? `تم إنشاء مساحة حفل "${data.titleAr}" بنجاح!`
        : `Created workspace for "${data.title}" successfully!`
    );
  };

  const addChecklistTask = (task: {
    title: string;
    titleAr: string;
    category: any;
    dueDate: string;
    notes?: string;
  }) => {
    const newTask: EventChecklistItem = {
      id: `task-${Date.now()}`,
      eventId: activeEventId,
      ...task,
      completed: false
    };
    setChecklist((prev) => [newTask, ...prev]);
    showToast(TRANSLATIONS[language].toastTaskAdded);
  };

  const toggleTaskCompletion = (taskId: string) => {
    setChecklist((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, completed: !t.completed } : t))
    );
    showToast(TRANSLATIONS[language].toastTaskUpdated);
  };

  const deleteChecklistTask = (taskId: string) => {
    setChecklist((prev) => prev.filter((t) => t.id !== taskId));
  };

  const addExpenseItem = (expense: {
    title: string;
    titleAr: string;
    category: any;
    amountEgp: number;
    vendorName?: string;
    paid: boolean;
    date: string;
  }) => {
    const newExpense: EventExpense = {
      id: `exp-${Date.now()}`,
      eventId: activeEventId,
      ...expense
    };
    setExpenses((prev) => [newExpense, ...prev]);
    showToast(TRANSLATIONS[language].toastExpenseAdded);
  };

  const deleteExpenseItem = (expenseId: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== expenseId));
  };

  const submitBookingInquiry = (data: {
    eventId: string;
    vendorId: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    eventDate: string;
    guestCount: number;
    requirements: string;
  }) => {
    const targetVendor = vendors.find((v) => v.id === data.vendorId);
    const targetEvent = events.find((e) => e.id === data.eventId);

    const newInquiry: BookingInquiry = {
      id: `inq-${Date.now()}`,
      eventId: data.eventId,
      eventName: targetEvent?.title || 'Wedding Celebration',
      vendorId: data.vendorId,
      vendorName: targetVendor?.name || 'Partner Vendor',
      vendorNameAr: targetVendor?.nameAr || 'المورد',
      vendorCategory: targetVendor?.category || 'venues',
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      customerPhone: data.customerPhone,
      eventDate: data.eventDate,
      guestCount: data.guestCount,
      requirements: data.requirements,
      status: 'inquiry_submitted',
      createdAt: new Date().toISOString().split('T')[0]
    };

    setInquiries((prev) => [newInquiry, ...prev]);

    // Trigger Zapier Zap #2 (Inquiry CRM & Slack alert)
    const zap2 = zaps.find((z) => z.id === 'zap-inquiry-crm');
    if (zap2 && zap2.enabled) {
      const newLog: ZapierExecutionLog = {
        id: `log-${Date.now()}`,
        zapId: zap2.id,
        zapTitle: zap2.title,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        status: 'success',
        triggerSummary: `New Inquiry for ${targetVendor?.name || 'Vendor'} (${data.customerName})`,
        payloadJson: JSON.stringify({
          event: 'layali.inquiry.created',
          inquiry_id: newInquiry.id,
          customer_name: data.customerName,
          customer_email: data.customerEmail,
          customer_phone: data.customerPhone,
          vendor_id: data.vendorId,
          vendor_name: targetVendor?.name,
          event_date: data.eventDate,
          guest_count: data.guestCount,
          requirements: data.requirements,
          status: 'SUCCESS'
        }, null, 2)
      };
      setZapierLogs((prev) => [newLog, ...prev]);
      setZaps((prev) =>
        prev.map((z) =>
          z.id === 'zap-inquiry-crm'
            ? { ...z, totalRuns: z.totalRuns + 1, lastRun: 'Just now' }
            : z
        )
      );
    }

    closeInquiryModal();
    showToast(TRANSLATIONS[language].toastInquirySent);
  };

  const vendorRespondQuote = (
    inquiryId: string,
    quoteEgp: number,
    depositEgp: number,
    notes: string
  ) => {
    setInquiries((prev) =>
      prev.map((inq) =>
        inq.id === inquiryId
          ? {
              ...inq,
              status: 'response_received',
              quotedPriceEgp: quoteEgp,
              depositRequiredEgp: depositEgp,
              vendorNotes: notes
            }
          : inq
      )
    );
    showToast(TRANSLATIONS[language].toastQuoteSent);
  };

  const vendorConfirmInquiry = (inquiryId: string) => {
    setInquiries((prev) =>
      prev.map((inq) => (inq.id === inquiryId ? { ...inq, status: 'confirmed' } : inq))
    );
    showToast(TRANSLATIONS[language].toastInquiryConfirmed);
  };

  const customerAcceptQuote = (inquiryId: string) => {
    const targetInq = inquiries.find((i) => i.id === inquiryId);
    setInquiries((prev) =>
      prev.map((inq) => (inq.id === inquiryId ? { ...inq, status: 'confirmed' } : inq))
    );

    if (targetInq?.quotedPriceEgp) {
      const newExp: EventExpense = {
        id: `exp-${Date.now()}`,
        eventId: targetInq.eventId || activeEventId,
        title: `${targetInq.vendorName} — Contracted Service`,
        titleAr: `${targetInq.vendorNameAr} — العقد المؤكد`,
        category: (targetInq.vendorCategory === 'lighting_fx'
          ? 'decor'
          : targetInq.vendorCategory === 'belly_dancers'
          ? 'entertainment'
          : targetInq.vendorCategory === 'venues'
          ? 'venue'
          : 'other') as any,
        amountEgp: targetInq.quotedPriceEgp,
        vendorName: targetInq.vendorName,
        paid: false,
        date: new Date().toISOString().split('T')[0]
      };
      setExpenses((prev) => [newExp, ...prev]);
    }

    showToast(TRANSLATIONS[language].toastInquiryConfirmed);
  };

  const customerDeclineQuote = (inquiryId: string) => {
    setInquiries((prev) =>
      prev.map((inq) => (inq.id === inquiryId ? { ...inq, status: 'cancelled' } : inq))
    );
  };

  const adminApproveVendor = (vendorId: string) => {
    setVendors((prev) =>
      prev.map((v) => (v.id === vendorId ? { ...v, status: 'active' } : v))
    );
    showToast(TRANSLATIONS[language].toastVendorApproved);
  };

  const adminRejectVendor = (vendorId: string) => {
    setVendors((prev) =>
      prev.map((v) => (v.id === vendorId ? { ...v, status: 'rejected' } : v))
    );
  };

  // -------------------------------------------------------------
  // PAYPAL HANDLERS
  // -------------------------------------------------------------
  const openPayPalModal = (target: PayPalCheckoutTarget) => {
    setPayPalTarget(target);
    setIsPayPalModalOpen(true);
  };

  const closePayPalModal = () => {
    setIsPayPalModalOpen(false);
    setPayPalTarget(null);
  };

  const processPayPalPayment = (tx: PayPalTransaction) => {
    setPayPalTransactions((prev) => [tx, ...prev]);

    // If linked to an inquiry, mark as confirmed
    if (tx.inquiryId) {
      setInquiries((prev) =>
        prev.map((inq) =>
          inq.id === tx.inquiryId
            ? { ...inq, status: 'confirmed' }
            : inq
        )
      );
    }

    // Add corresponding event expense
    const newExpense: EventExpense = {
      id: `exp-${Date.now()}`,
      eventId: activeEventId,
      title: `${tx.vendorName} — PayPal Escrow (${tx.tierName})`,
      titleAr: `${tx.vendorNameAr || tx.vendorName} — دفعة باي بال المحمية (${tx.tierName})`,
      category: 'other',
      amountEgp: tx.amountEgp,
      vendorName: tx.vendorName,
      paid: true,
      date: new Date().toISOString().split('T')[0]
    };
    setExpenses((prev) => [newExpense, ...prev]);

    // Increase vendor balance
    setVendorPayPalBalance((prev) => prev + tx.amountEgp);

    // Trigger Zapier Zap automatically (Zap #1: PayPal deposit captured)
    const zap1 = zaps.find((z) => z.id === 'zap-paypal-sync');
    if (zap1 && zap1.enabled) {
      const newLog: ZapierExecutionLog = {
        id: `log-${Date.now()}`,
        zapId: zap1.id,
        zapTitle: zap1.title,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        status: 'success',
        triggerSummary: `Live PayPal Deposit Captured (${tx.amountEgp.toLocaleString()} EGP)`,
        payloadJson: JSON.stringify({
          event: 'paypal.escrow.milestone_paid',
          transaction_id: tx.id,
          order_id: tx.orderId,
          vendor: tx.vendorName,
          amount_egp: tx.amountEgp,
          currency: tx.currency,
          payer: tx.payerName,
          email: tx.payerEmail,
          status: 'SUCCESS'
        }, null, 2)
      };
      setZapierLogs((prev) => [newLog, ...prev]);
      setZaps((prev) =>
        prev.map((z) =>
          z.id === 'zap-paypal-sync'
            ? { ...z, totalRuns: z.totalRuns + 1, lastRun: 'Just now' }
            : z
        )
      );
    }

    closePayPalModal();
    showToast(language === 'ar' ? 'تم تأكيد دفعة باي بال وحجز المورد بالضمان بنجاح!' : 'PayPal deposit captured! Date reserved with Smart Escrow.');
  };

  const releaseEscrowMilestone = (transactionId: string) => {
    setPayPalTransactions((prev) =>
      prev.map((t) =>
        t.id === transactionId
          ? { ...t, status: 'released' }
          : t
      )
    );
    showToast(language === 'ar' ? 'تم تحرير دفعة الضمان وإيداعها في محفظة المورد!' : 'Escrow milestone released directly to vendor PayPal balance!');
  };

  const refundEscrowTransaction = (transactionId: string) => {
    setPayPalTransactions((prev) =>
      prev.map((t) =>
        t.id === transactionId
          ? { ...t, status: 'refunded' }
          : t
      )
    );
    showToast(language === 'ar' ? 'تم استرداد المبلغ عبر باي بال وفق سياسة حماية المشتري.' : 'Refund issued via PayPal Buyer Protection guarantee.');
  };

  const withdrawVendorPayoutPayPal = (amountEgp: number, paypalEmail: string) => {
    if (amountEgp > vendorPayPalBalance) {
      showToast(language === 'ar' ? 'الرصيد المتاح غير كافٍ للسحب' : 'Insufficient balance for payout');
      return;
    }
    setVendorPayPalBalance((prev) => prev - amountEgp);
    showToast(language === 'ar' ? `تم تحويل ${amountEgp.toLocaleString()} ج.م فوراً إلى حساب باي بال: ${paypalEmail}` : `Instant PayPal Payout of ${amountEgp.toLocaleString()} EGP sent to ${paypalEmail}`);
  };

  // -------------------------------------------------------------
  // BRYNTUM SCHEDULER HANDLERS
  // -------------------------------------------------------------
  const addScheduleItem = (item: Omit<BryntumScheduleItem, 'id'>) => {
    const newItem: BryntumScheduleItem = {
      ...item,
      id: `bry-${Date.now()}`
    };
    setBryntumSchedule((prev) => [...prev, newItem].sort((a, b) => a.startTime.localeCompare(b.startTime)));
    showToast(language === 'ar' ? 'تمت إضافة الفقرة إلى جدول برينتوم بنجاح' : 'Schedule block added to Bryntum Run-of-Show');
  };

  const updateScheduleItem = (id: string, updates: Partial<BryntumScheduleItem>) => {
    setBryntumSchedule((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item)).sort((a, b) => a.startTime.localeCompare(b.startTime))
    );
    showToast(language === 'ar' ? 'تم تحديث توقيتات الفقرة في برينتوم' : 'Bryntum timeline block updated');
  };

  const deleteScheduleItem = (id: string) => {
    setBryntumSchedule((prev) => prev.filter((item) => item.id !== id));
    showToast(language === 'ar' ? 'تم حذف الفقرة من الجدول' : 'Timeline item removed');
  };

  const resetBryntumPreset = (preset: 'cairo_wedding' | 'gouna_beach' | 'corporate_gala') => {
    if (preset === 'cairo_wedding') {
      setBryntumSchedule(INITIAL_BRYNTUM_SCHEDULE);
    } else if (preset === 'gouna_beach') {
      setBryntumSchedule([
        {
          id: 'gouna-1',
          title: 'Beachside Bamboo Canopy & Pampas Setup',
          titleAr: 'تجهيز مظلات البامبو وزهور البامباس الشاطئية',
          startTime: '14:00',
          endTime: '16:30',
          trackId: 'staging',
          vendorName: 'Le Fleuriste Wedding & Kosha Design',
          vendorNameAr: 'لو فلوريست للزهور',
          zone: 'Red Sea Beachfront Deck',
          zoneAr: 'شاطئ البحر الأحمر المفتوح',
          status: 'confirmed',
          color: '#B79A66'
        },
        {
          id: 'gouna-2',
          title: 'Acoustic Saxophone & Sunset Cocktail Hour',
          titleAr: 'عزف الساكسفون وقت الغروب الساحر',
          startTime: '17:00',
          endTime: '18:30',
          trackId: 'zaffa_entertainment',
          vendorName: 'Amira & Royal Egyptian Zaffah',
          vendorNameAr: 'أميرة وفرقة العروض الشرقية',
          zone: 'Sunset Pier',
          zoneAr: 'رصيف الغروب البحري',
          status: 'confirmed',
          color: '#C47055'
        },
        {
          id: 'gouna-3',
          title: 'Seafood Barbecue Live Stations',
          titleAr: 'محطات الشواء الحي للمأكولات البحرية الفاخرة',
          startTime: '19:00',
          endTime: '21:00',
          trackId: 'catering_hospitality',
          vendorName: 'Palais du Nil Haute Catering',
          vendorNameAr: 'خدمات الضيافة الملكية',
          zone: 'Lagoon Terrace',
          zoneAr: 'تراس البحيرة',
          status: 'confirmed',
          color: '#657B6C'
        },
        {
          id: 'gouna-4',
          title: 'Deep House DJ & LED Water Lights',
          titleAr: 'حفل الديب هاوس وإضاءة مياه اللاجون',
          startTime: '21:00',
          endTime: '02:00',
          trackId: 'lighting_sound',
          vendorName: 'DJ Tamer & Nile Sound Production',
          vendorNameAr: 'دي جي تامر',
          zone: 'Beach Club Main Stage',
          zoneAr: 'مسرح النادي الشاطئي',
          status: 'confirmed',
          color: '#8A588C'
        }
      ]);
    } else {
      setBryntumSchedule([
        {
          id: 'corp-1',
          title: 'LED Video Wall & Keynote Audio Calibration',
          titleAr: 'معايرة شاشات العرض العملاقة والصوتيات للمؤتمر',
          startTime: '12:00',
          endTime: '15:00',
          trackId: 'lighting_sound',
          vendorName: 'Lumina Architectural Lighting',
          vendorNameAr: 'لومينا للإضاءة والمؤثرات',
          zone: 'Convention Plenary Hall',
          zoneAr: 'قاعة المؤتمرات الرئيسية',
          status: 'confirmed',
          color: '#3B6A9E'
        },
        {
          id: 'corp-2',
          title: 'Executive VIP Registration & Hostess Welcoming',
          titleAr: 'استقبال كبار الزوار وتسجيل الحضور بالبوابات',
          startTime: '16:00',
          endTime: '17:30',
          trackId: 'zaffa_entertainment',
          vendorName: 'Royal Elite VIP Hosting',
          vendorNameAr: 'رويال إيليت للاستضافة والتشريفات',
          zone: 'Grand Atrium',
          zoneAr: 'البهو الرئيسي',
          status: 'confirmed',
          color: '#B79A66'
        },
        {
          id: 'corp-3',
          title: 'Annual Awards Gala Dinner & Keynote Speech',
          titleAr: 'عشاء حفل الجوائز السنوي والكلمات الرسمية',
          startTime: '18:00',
          endTime: '20:30',
          trackId: 'catering_hospitality',
          vendorName: 'Palais du Nil Haute Catering',
          vendorNameAr: 'خدمات الضيافة الملكية',
          zone: 'Main Banquet Hall',
          zoneAr: 'قاعة المأدبة الكبرى',
          status: 'confirmed',
          color: '#657B6C'
        }
      ]);
    }
    showToast(language === 'ar' ? 'تم تحميل قالب التوقيتات لبرينتوم بنجاح' : 'Bryntum preset timeline loaded');
  };

  // -------------------------------------------------------------
  // ZAPIER HANDLERS
  // -------------------------------------------------------------
  const toggleZap = (zapId: string) => {
    setZaps((prev) =>
      prev.map((z) => (z.id === zapId ? { ...z, enabled: !z.enabled } : z))
    );
    showToast(language === 'ar' ? 'تم تحديث حالة تفعيل مسار زابيير' : 'Zapier workflow state toggled');
  };

  const testRunZap = async (zapId: string): Promise<{ success: boolean; log: ZapierExecutionLog }> => {
    setActiveZapTestingId(zapId);
    const targetZap = zaps.find((z) => z.id === zapId);
    
    // Simulate real webhook roundtrip
    await new Promise((resolve) => setTimeout(resolve, 800));

    const newLog: ZapierExecutionLog = {
      id: `log-${Date.now()}`,
      zapId: zapId,
      zapTitle: targetZap?.title || 'Zapier Workflow',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      status: 'success',
      triggerSummary: `Manual Test Trigger via Layali Studio (${targetZap?.triggerApp || 'Webhook'})`,
      payloadJson: JSON.stringify({
        source: 'layali.event_marketplace',
        zap_id: zapId,
        test_run: true,
        triggered_at: new Date().toISOString(),
        payload: targetZap?.samplePayload || {},
        response_code: 200,
        webhook_status: 'delivered'
      }, null, 2)
    };

    setZapierLogs((prev) => [newLog, ...prev]);
    setZaps((prev) =>
      prev.map((z) =>
        z.id === zapId ? { ...z, totalRuns: z.totalRuns + 1, lastRun: 'Just now' } : z
      )
    );
    setActiveZapTestingId(null);
    showToast(language === 'ar' ? 'تم إرسال الحدث إلى مسار زابيير بنجاح (200 OK)!' : 'Zapier event successfully fired and delivered (200 OK)!');
    return { success: true, log: newLog };
  };

  const resetDemoData = () => {
    setVendors(INITIAL_VENDORS);
    setEvents(INITIAL_EVENTS);
    setActiveEventId(INITIAL_EVENTS[0].id);
    setChecklist(INITIAL_CHECKLIST);
    setExpenses(INITIAL_EXPENSES);
    setInquiries(INITIAL_INQUIRIES);
    setLikedPinIds(['pin-lighting-arch', 'pin-bellydancer-zaffah']);
    setRoleState('customer');
    setCurrentView('home');
    setFeedCategoryFilter('all');
    setFeedViewMode('pins');
    setPayPalTransactions(INITIAL_PAYPAL_TRANSACTIONS);
    setVendorPayPalBalance(100000);
    setBryntumSchedule(INITIAL_BRYNTUM_SCHEDULE);
    setZaps(INITIAL_ZAPIER_ZAPS);
    setZapierLogs(INITIAL_ZAPIER_LOGS);
    showToast(TRANSLATIONS[language].toastDataReset);
  };

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        language,
        setLanguage,
        currentView,
        setCurrentView,
        pins,
        likedPinIds,
        toggleLikePin,
        selectedPin,
        setSelectedPinId,
        feedCategoryFilter,
        setFeedCategoryFilter,
        feedViewMode,
        setFeedViewMode,
        collections,
        activeCollectionId,
        setActiveCollectionId,
        createCollection,
        deleteCollection,
        renameCollection,
        savePinToCollection,
        removePinFromCollection,
        saveTargetPin,
        openSaveToCollectionModal,
        closeSaveToCollectionModal,
        onboarding,
        saveOnboardingPreferences,
        clearOnboardingPreferences,
        isOnboardingModalOpen,
        setIsOnboardingModalOpen,
        activeCategoryPage,
        openCategoryPage,
        selectedVendor,
        setSelectedVendorId,
        inquiryTargetVendor,
        openInquiryModal,
        closeInquiryModal,
        isEventWizardOpen,
        setIsEventWizardOpen,
        events,
        activeEvent,
        setActiveEventId,
        vendors,
        checklist,
        expenses,
        inquiries,
        toggleSaveVendor,
        createNewEvent,
        addChecklistTask,
        toggleTaskCompletion,
        deleteChecklistTask,
        addExpenseItem,
        deleteExpenseItem,
        submitBookingInquiry,
        vendorRespondQuote,
        vendorConfirmInquiry,
        customerAcceptQuote,
        customerDeclineQuote,
        adminApproveVendor,
        adminRejectVendor,
        resetDemoData,
        // Sponsors
        payPalTransactions,
        isPayPalModalOpen,
        payPalTarget,
        openPayPalModal,
        closePayPalModal,
        processPayPalPayment,
        releaseEscrowMilestone,
        refundEscrowTransaction,
        vendorPayPalBalance,
        withdrawVendorPayoutPayPal,
        bryntumSchedule,
        addScheduleItem,
        updateScheduleItem,
        deleteScheduleItem,
        resetBryntumPreset,
        zaps,
        zapierLogs,
        toggleZap,
        testRunZap,
        activeZapTestingId,
        toast,
        showToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
