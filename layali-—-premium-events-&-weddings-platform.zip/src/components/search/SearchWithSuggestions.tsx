import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';
import { Search, X, Sparkles, TrendingUp, ArrowRight } from 'lucide-react';
import { VendorCategory } from '../../types';

interface SearchWithSuggestionsProps {
  value: string;
  onChange: (query: string) => void;
  className?: string;
  placeholder?: string;
}

export const SearchWithSuggestions: React.FC<SearchWithSuggestionsProps> = ({
  value,
  onChange,
  className = '',
  placeholder
}) => {
  const { language, openCategoryPage, setFeedCategoryFilter } = useApp();
  const dict = TRANSLATIONS[language];
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Guided popular searches from Section 9 of Master Build Prompt
  const popularSuggestions = [
    { label: 'Outdoor wedding venues', labelAr: 'قاعات أفراح في الهواء الطلق', cat: 'venues' as VendorCategory },
    { label: 'Belly dancers for events & Zaffah', labelAr: 'راقصات شرقيات وفرق زفة', cat: 'belly_dancers' as VendorCategory },
    { label: 'Architectural lighting & stage FX', labelAr: 'هندسة إضاءة ومسارح كبرى', cat: 'lighting_fx' as VendorCategory },
    { label: 'Cairo wedding photographers', labelAr: 'مصورو أفراح سينمائيون في القاهرة', cat: 'photography' as VendorCategory },
    { label: 'VIP hosting and ushers', labelAr: 'مضيفات كبار الشخصيات والمراسم', cat: 'hosting_ushers' as VendorCategory },
    { label: 'Wedding & event planners', labelAr: 'منظمو حفلات الزفاف والمناسبات', cat: 'wedding_planners' as VendorCategory },
    { label: 'Haute wedding catering & cakes', labelAr: 'بوفيهات عشاء وحلويات فاخرة', cat: 'catering' as VendorCategory },
    { label: 'Live DJs and percussionists', labelAr: 'دي جي وعازفو إيقاع حي', cat: 'dj_sound' as VendorCategory }
  ];

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectSuggestion = (suggestion: typeof popularSuggestions[0]) => {
    const text = language === 'ar' ? suggestion.labelAr : suggestion.label;
    onChange(text);
    if (suggestion.cat) {
      setFeedCategoryFilter(suggestion.cat);
    }
    setIsOpen(false);
  };

  const clearInput = () => {
    onChange('');
    setFeedCategoryFilter('all');
  };

  return (
    <div ref={containerRef} className={`relative ${className}`}>
      <div className="relative flex items-center">
        <Search className="w-4 h-4 text-[#77736C] absolute left-4 rtl:left-auto rtl:right-4 pointer-events-none" />
        
        <input
          type="text"
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            if (!isOpen) setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder || dict.searchPlaceholder}
          className="w-full pl-11 pr-10 rtl:pr-11 rtl:pl-10 py-3 text-sm bg-white border border-[#E5DFD5] rounded-2xl focus:outline-none focus:border-[#B79A66] focus:ring-2 focus:ring-[#B79A66]/20 transition-all shadow-sm"
        />

        {value && (
          <button
            onClick={clearInput}
            className="absolute right-3 rtl:right-auto rtl:left-3 p-1 text-[#77736C] hover:text-[#242320] rounded-full"
            aria-label="Clear search"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Guided Suggestions Dropdown */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-[#FAF8F4] border border-[#E5DFD5] rounded-2xl shadow-xl p-4 z-30 animate-in fade-in zoom-in-95 duration-150">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#E5DFD5]">
            <span className="text-[11px] uppercase tracking-wider font-semibold text-[#77736C] flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-[#B79A66]" />
              <span>{language === 'ar' ? 'عمليات البحث الأكثر طلباً' : 'Popular Searches & Categories'}</span>
            </span>
            <span className="text-[10px] text-[#77736C]">
              {language === 'ar' ? 'مصر · القاهرة الكبرى' : 'Egypt · Greater Cairo'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-60 overflow-y-auto">
            {popularSuggestions.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSelectSuggestion(item)}
                className="text-left rtl:text-right p-2.5 rounded-xl hover:bg-white text-xs text-[#242320] hover:text-[#B79A66] transition-colors flex items-center justify-between group"
              >
                <span className="font-medium truncate">
                  {language === 'ar' ? item.labelAr : item.label}
                </span>
                <ArrowRight className="w-3 h-3 text-[#77736C] group-hover:text-[#B79A66] group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 rtl:rotate-180 transition-all opacity-0 group-hover:opacity-100" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
