import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';
import { Clock, Plus, Save, Sparkles } from 'lucide-react';

interface TimelineItem {
  id: string;
  time: string;
  title: string;
  titleAr: string;
  notes: string;
  notesAr: string;
}

export const TimelineTab: React.FC = () => {
  const { language, activeEvent, showToast } = useApp();
  const dict = TRANSLATIONS[language];

  const [items, setItems] = useState<TimelineItem[]>([
    {
      id: 't-1',
      time: '04:30 PM',
      title: 'Bridal Preparation & First Look Portrait Session',
      titleAr: 'تجهيز العروس وجلسة التصوير التذكارية الأولى',
      notes: 'Karim Tamer photo crew on-site in bridal suite with natural window lighting.',
      notesAr: 'فريق التصوير متواجد في جناح العروس لالتقاط تفاصيل الفستان والطرحة.'
    },
    {
      id: 't-2',
      time: '06:30 PM',
      title: 'Guest Arrival & Sunset Welcome Cocktails',
      titleAr: 'استقبال المعازيم ومشروبات الترحيب عند الغروب',
      notes: 'Palais du Nil waterfront terrace with acoustic harp & violin ensemble.',
      notesAr: 'تراس قصر النيل المطل على النهر مع معزوفات هادئة على آلة الهارب والكمان.'
    },
    {
      id: 't-3',
      time: '08:00 PM',
      title: 'The Grand Royal Zaffah & Majestic Entrance',
      titleAr: 'الزفة الملكية الكبرى والدخول المهيب',
      notes: '25-piece symphonic zaffah with oriental percussion and traditional drummers.',
      notesAr: 'فرقة الزفة السيمفونية المكونة من ٢٥ عازفاً مع إيقاعات الطبول التراثية.'
    },
    {
      id: 't-4',
      time: '09:00 PM',
      title: 'First Dance & Imperial 5-Tier Cake Cutting',
      titleAr: 'الرقصة الأولى ومراسم تقطيع كعكة الزفاف الملكية',
      notes: 'Low-lying dry ice fog effect and indoor cold-fire sparks with customized music.',
      notesAr: 'مؤثرات الدخان البارد والألعاب النارية الداخلية مع الأغنية المختارة.'
    },
    {
      id: 't-5',
      time: '09:45 PM',
      title: 'Haute Gastronomy Dinner Banquet Opening',
      titleAr: 'افتتاح بوفيه العشاء الفاخر ومحطات الطهي الحية',
      notes: 'Le Cirque brigade stations: Angus carving, seafood bar, oriental sweets.',
      notesAr: 'بوفيه فاخر يشمل محطات اللحم الأنجوس والمأكولات البحرية والحلويات الشرقية.'
    },
    {
      id: 't-6',
      time: '11:00 PM',
      title: 'Live Orchestra & Evening Celebration',
      titleAr: 'الفرقة الموسيقية الحية والاحتفال حتى الصباح',
      notes: '8-piece live band performance followed by DJ and late-night savory snacks.',
      notesAr: 'فقرة الفرقة الموسيقية الحية يليها الدي جي والمشروبات المنعشة.'
    }
  ]);

  const [newTime, setNewTime] = useState('11:45 PM');
  const [newTitle, setNewTitle] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newItem: TimelineItem = {
      id: `t-${Date.now()}`,
      time: newTime,
      title: newTitle,
      titleAr: newTitle,
      notes: newNotes,
      notesAr: newNotes
    };

    setItems([...items, newItem]);
    setNewTitle('');
    setNewNotes('');
    setIsAdding(false);
    showToast(language === 'ar' ? 'تمت إضافة الفقرة للجدول الزمني' : 'Timeline milestone added');
  };

  return (
    <div className="space-y-6">
      <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block mb-1">
            {language === 'ar' ? 'الجدول الزمني للحدث' : 'Run of Show & Schedule'}
          </span>
          <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
            {dict.tabTimeline}
          </h3>
          <p className="text-xs text-[#77736C] mt-1">
            {language === 'ar'
              ? `الجدول التنفيذي الدقيق ليوم حفل ${activeEvent.titleAr || activeEvent.title}`
              : `Minute-by-minute itinerary for ${activeEvent.title}`}
          </p>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded flex items-center gap-2 shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'ar' ? 'إضافة فقرة جديدة' : 'Add Milestone'}</span>
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleAddItem} className="p-5 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] space-y-3 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-[#242320] mb-1">
                {language === 'ar' ? 'التوقيت' : 'Time'}
              </label>
              <input
                type="text"
                value={newTime}
                onChange={(e) => setNewTime(e.target.value)}
                placeholder="e.g. 10:30 PM"
                className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold text-[#242320] mb-1">
                {language === 'ar' ? 'عنوان الفقرة' : 'Milestone Title'}
              </label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Midnight Dessert Trolley & Favors"
                className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
              />
            </div>
          </div>
          <div>
            <label className="block font-semibold text-[#242320] mb-1">
              {language === 'ar' ? 'تفاصيل التنسيق' : 'Coordination Notes'}
            </label>
            <textarea
              rows={2}
              value={newNotes}
              onChange={(e) => setNewNotes(e.target.value)}
              placeholder="e.g. Coordinate with Palais du Nil banquet captain"
              className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
            />
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 border border-[#E5DFD5] rounded text-xs text-[#77736C]"
            >
              {language === 'ar' ? 'إلغاء' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#242320] text-white rounded text-xs font-semibold"
            >
              {language === 'ar' ? 'حفظ' : 'Save'}
            </button>
          </div>
        </form>
      )}

      {/* Itinerary Milestones */}
      <div className="bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] p-6 space-y-6">
        <div className="space-y-6 relative before:absolute before:inset-0 before:left-3.5 rtl:before:left-auto rtl:before:right-3.5 before:w-0.5 before:bg-[#E5DFD5]">
          {items.map((item) => (
            <div key={item.id} className="relative flex items-start gap-4">
              <div className="w-7 h-7 rounded-full bg-[#242320] text-[#B79A66] flex items-center justify-center shrink-0 z-10 shadow-xs">
                <Clock className="w-3.5 h-3.5" />
              </div>

              <div className="flex-1 bg-[#FAF8F4] p-4 rounded-lg border border-[#E5DFD5] space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#B79A66] tabular-nums">
                    {item.time}
                  </span>
                  <span className="text-[10px] uppercase tracking-wider text-[#77736C]">
                    {activeEvent.venueName}
                  </span>
                </div>

                <h4 className="font-editorial text-lg font-semibold text-[#242320]">
                  {language === 'ar' ? item.titleAr : item.title}
                </h4>

                <p className="text-xs text-[#77736C] leading-relaxed">
                  {language === 'ar' ? item.notesAr : item.notes}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
