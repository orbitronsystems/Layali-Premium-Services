import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';
import { CheckCircle2, Circle, Plus, Trash2, Calendar, Filter } from 'lucide-react';

export const ChecklistTab: React.FC = () => {
  const { 
    checklist, 
    activeEvent, 
    addChecklistTask, 
    toggleTaskCompletion, 
    deleteChecklistTask, 
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'completed'>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New task form state
  const [title, setTitle] = useState('');
  const [titleAr, setTitleAr] = useState('');
  const [category, setCategory] = useState<'venue' | 'attire' | 'photo' | 'music' | 'decor' | 'logistics'>('venue');
  const [dueDate, setDueDate] = useState('2026-11-30');
  const [notes, setNotes] = useState('');

  // Filter tasks for active event
  const eventTasks = useMemo(() => {
    return checklist.filter((t) => t.eventId === activeEvent.id);
  }, [checklist, activeEvent.id]);

  const filteredTasks = useMemo(() => {
    return eventTasks.filter((t) => {
      if (filterStatus === 'pending' && t.completed) return false;
      if (filterStatus === 'completed' && !t.completed) return false;
      if (filterCategory !== 'all' && t.category !== filterCategory) return false;
      return true;
    });
  }, [eventTasks, filterStatus, filterCategory]);

  const completedCount = eventTasks.filter((t) => t.completed).length;
  const progressPercent = eventTasks.length > 0 ? Math.round((completedCount / eventTasks.length) * 100) : 0;

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    addChecklistTask({
      title: title.trim(),
      titleAr: titleAr.trim() || title.trim(),
      category,
      dueDate,
      notes: notes.trim()
    });

    setTitle('');
    setTitleAr('');
    setNotes('');
    setIsAddModalOpen(false);
  };

  const getCategoryTitle = (cat: string) => {
    switch (cat) {
      case 'venue': return dict.taskCategoryVenue;
      case 'attire': return dict.taskCategoryAttire;
      case 'photo': return dict.taskCategoryPhoto;
      case 'music': return dict.taskCategoryMusic;
      case 'decor': return dict.taskCategoryDecor;
      case 'logistics': return dict.taskCategoryLogistics;
      default: return cat;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Progress & Add Button */}
      <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block mb-1">
            {language === 'ar' ? 'إدارة مراحل التخطيط' : 'Event Milestones'}
          </span>
          <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
            {dict.tabChecklist}
          </h3>
          <p className="text-xs text-[#77736C] mt-1">
            {language === 'ar'
              ? `تم إنجاز ${completedCount} من أصل ${eventTasks.length} مهمة (${progressPercent}%)`
              : `${completedCount} of ${eventTasks.length} tasks completed (${progressPercent}%)`}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Progress ring/bar */}
          <div className="hidden sm:block w-36 bg-[#F1EDE6] h-2 rounded-full overflow-hidden">
            <div
              className="bg-[#2E6B4F] h-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded flex items-center gap-2 shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>{dict.addTask}</span>
          </button>
        </div>
      </div>

      {/* Filter toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] text-xs">
        {/* Status segmented control */}
        <div className="flex items-center p-1 bg-[#FAF8F4] rounded border border-[#E5DFD5]">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1 rounded transition-colors ${
              filterStatus === 'all'
                ? 'bg-[#242320] text-white font-medium'
                : 'text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.taskFilterAll} ({eventTasks.length})
          </button>
          <button
            onClick={() => setFilterStatus('pending')}
            className={`px-3 py-1 rounded transition-colors ${
              filterStatus === 'pending'
                ? 'bg-[#242320] text-white font-medium'
                : 'text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.taskFilterPending} ({eventTasks.length - completedCount})
          </button>
          <button
            onClick={() => setFilterStatus('completed')}
            className={`px-3 py-1 rounded transition-colors ${
              filterStatus === 'completed'
                ? 'bg-[#242320] text-white font-medium'
                : 'text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.taskFilterCompleted} ({completedCount})
          </button>
        </div>

        {/* Category filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-[#77736C]" />
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-[#FAF8F4] border border-[#E5DFD5] rounded px-3 py-1.5 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
          >
            <option value="all">{language === 'ar' ? 'كافة التصنيفات' : 'All Categories'}</option>
            <option value="venue">{dict.taskCategoryVenue}</option>
            <option value="attire">{dict.taskCategoryAttire}</option>
            <option value="photo">{dict.taskCategoryPhoto}</option>
            <option value="music">{dict.taskCategoryMusic}</option>
            <option value="decor">{dict.taskCategoryDecor}</option>
            <option value="logistics">{dict.taskCategoryLogistics}</option>
          </select>
        </div>
      </div>

      {/* Task List */}
      {filteredTasks.length > 0 ? (
        <div className="space-y-2.5">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className={`p-4 rounded-lg border transition-all flex items-start justify-between gap-4 ${
                task.completed
                  ? 'bg-[#FFFFFF]/70 border-[#E5DFD5] opacity-75'
                  : 'bg-[#FFFFFF] border-[#E5DFD5] shadow-xs hover:border-[#B79A66]'
              }`}
            >
              <div className="flex items-start gap-3.5 flex-1">
                <button
                  onClick={() => toggleTaskCompletion(task.id)}
                  aria-label={task.completed ? dict.markIncomplete : dict.markComplete}
                  className="mt-0.5 text-[#B79A66] hover:text-[#2E6B4F] transition-colors"
                >
                  {task.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-[#2E6B4F]" />
                  ) : (
                    <Circle className="w-5 h-5 text-[#77736C] hover:text-[#B79A66]" />
                  )}
                </button>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-[#77736C]">
                    <span className="font-semibold text-[#B79A66]">
                      {getCategoryTitle(task.category)}
                    </span>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-[#77736C]" />
                      {dict.dueOn} {task.dueDate}
                    </span>
                  </div>

                  <h4
                    className={`text-sm font-medium ${
                      task.completed
                        ? 'line-through text-[#77736C]'
                        : 'text-[#242320]'
                    }`}
                  >
                    {language === 'ar' ? task.titleAr : task.title}
                  </h4>

                  {task.notes && (
                    <p className="text-xs text-[#77736C] italic pt-0.5">
                      {task.notes}
                    </p>
                  )}
                </div>
              </div>

              {/* Delete button */}
              <button
                onClick={() => deleteChecklistTask(task.id)}
                className="p-1.5 text-[#77736C] hover:text-[#9E3B3B] transition-colors rounded"
                title="Delete task"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 text-center bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] text-xs text-[#77736C]">
          <p>{dict.noTasks}</p>
        </div>
      )}

      {/* Add Task Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#FAF8F4] w-full max-w-lg rounded-lg shadow-xl border border-[#E5DFD5] p-6 space-y-4">
            <h3 className="font-editorial text-xl font-semibold text-[#242320]">
              {dict.addTask}
            </h3>

            <form onSubmit={handleCreateTask} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#242320] mb-1">
                  {language === 'ar' ? 'عنوان المهمة بالإنجليزية' : 'Task Title (English)'}
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Schedule bridal hair & makeup trial"
                  className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#242320] mb-1">
                  {language === 'ar' ? 'عنوان المهمة بالعربية' : 'Task Title (Arabic)'}
                </label>
                <input
                  type="text"
                  value={titleAr}
                  onChange={(e) => setTitleAr(e.target.value)}
                  placeholder="مثال: حجز موعد تجربة مكياج وتصفيف شعر العروس"
                  className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#242320] mb-1">
                    {dict.filterCategory}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  >
                    <option value="venue">{dict.taskCategoryVenue}</option>
                    <option value="attire">{dict.taskCategoryAttire}</option>
                    <option value="photo">{dict.taskCategoryPhoto}</option>
                    <option value="music">{dict.taskCategoryMusic}</option>
                    <option value="decor">{dict.taskCategoryDecor}</option>
                    <option value="logistics">{dict.taskCategoryLogistics}</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#242320] mb-1">
                    {dict.dueOn}
                  </label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#242320] mb-1">
                  {language === 'ar' ? 'ملاحظات وتفاصيل إضافية' : 'Notes / Instructions'}
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-[#E5DFD5] rounded text-xs text-[#77736C] hover:text-[#242320]"
                >
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#242320] hover:bg-[#B79A66] text-white rounded text-xs font-semibold uppercase tracking-wider transition-colors"
                >
                  {language === 'ar' ? 'إضافة المهمة' : 'Save Task'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
