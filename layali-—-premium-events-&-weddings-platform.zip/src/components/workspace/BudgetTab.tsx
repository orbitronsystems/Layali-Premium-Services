import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, formatEgp } from '../../utils/translations';
import { Plus, Trash2, CheckCircle2, Clock } from 'lucide-react';

export const BudgetTab: React.FC = () => {
  const { 
    expenses, 
    activeEvent, 
    addExpenseItem, 
    deleteExpenseItem, 
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);

  // New expense form
  const [title, setTitle] = useState('');
  const [titleAr, setTitleAr] = useState('');
  const [category, setCategory] = useState<'venue' | 'catering' | 'photography' | 'decor' | 'attire' | 'entertainment' | 'other'>('venue');
  const [amountEgp, setAmountEgp] = useState<number>(50000);
  const [vendorName, setVendorName] = useState('');
  const [paid, setPaid] = useState(false);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  // Filter expenses for current event
  const eventExpenses = useMemo(() => {
    return expenses.filter((e) => e.eventId === activeEvent.id);
  }, [expenses, activeEvent.id]);

  const totalSpent = useMemo(() => {
    return eventExpenses.reduce((sum, item) => sum + item.amountEgp, 0);
  }, [eventExpenses]);

  const remainingBudget = activeEvent.plannedBudgetEgp - totalSpent;
  const utilizationPercent = activeEvent.plannedBudgetEgp > 0
    ? Math.min(100, Math.round((totalSpent / activeEvent.plannedBudgetEgp) * 100))
    : 0;

  // Category breakdown
  const categoryTotals = useMemo(() => {
    const map: Record<string, number> = {
      venue: 0,
      catering: 0,
      photography: 0,
      decor: 0,
      attire: 0,
      entertainment: 0,
      other: 0
    };
    eventExpenses.forEach((exp) => {
      map[exp.category] = (map[exp.category] || 0) + exp.amountEgp;
    });
    return map;
  }, [eventExpenses]);

  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || amountEgp <= 0) return;

    addExpenseItem({
      title: title.trim(),
      titleAr: titleAr.trim() || title.trim(),
      category,
      amountEgp: Number(amountEgp),
      vendorName: vendorName.trim() || undefined,
      paid,
      date
    });

    setTitle('');
    setTitleAr('');
    setVendorName('');
    setAmountEgp(50000);
    setIsAddExpenseOpen(false);
  };

  const getCategoryName = (cat: string) => {
    switch (cat) {
      case 'venue': return language === 'ar' ? 'القاعة والتجهيزات' : 'Venue & Logistics';
      case 'catering': return language === 'ar' ? 'الضيافة والبوفيه' : 'Haute Catering';
      case 'photography': return language === 'ar' ? 'التصوير والسينما' : 'Cinema & Photo';
      case 'decor': return language === 'ar' ? 'الزهور والديكور والكوشة' : 'Floral & Decor';
      case 'attire': return language === 'ar' ? 'الأزياء والبدلات' : 'Attire & Beauty';
      case 'entertainment': return language === 'ar' ? 'الزفة والموسيقى' : 'Music & Zaffah';
      default: return language === 'ar' ? 'بنود أخرى' : 'Miscellaneous';
    }
  };

  return (
    <div className="space-y-6">
      {/* Financial KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Planned Budget */}
        <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-1">
          <span className="text-xs uppercase tracking-widest text-[#77736C] font-semibold block">
            {dict.plannedBudget}
          </span>
          <div className="font-editorial text-3xl font-semibold text-[#242320] tabular-nums">
            {formatEgp(activeEvent.plannedBudgetEgp, language)}
          </div>
          <span className="text-[11px] text-[#77736C] block">
            {language === 'ar' ? 'الميزانية المستهدفة للفعالية' : 'Baseline allocated budget'}
          </span>
        </div>

        {/* Total Committed / Spent */}
        <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-1">
          <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block">
            {dict.recordedExpenses}
          </span>
          <div className="font-editorial text-3xl font-semibold text-[#B79A66] tabular-nums">
            {formatEgp(totalSpent, language)}
          </div>
          <span className="text-[11px] text-[#77736C] block">
            {language === 'ar' ? `${utilizationPercent}% من الميزانية المحددة` : `${utilizationPercent}% of target utilized`}
          </span>
        </div>

        {/* Remaining Budget */}
        <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-1">
          <span className="text-xs uppercase tracking-widest text-[#2E6B4F] font-semibold block">
            {dict.remainingBudget}
          </span>
          <div className={`font-editorial text-3xl font-semibold tabular-nums ${
            remainingBudget < 0 ? 'text-[#9E3B3B]' : 'text-[#2E6B4F]'
          }`}>
            {formatEgp(remainingBudget, language)}
          </div>
          <span className="text-[11px] text-[#77736C] block">
            {remainingBudget < 0
              ? (language === 'ar' ? 'تجاوزت الميزانية المحددة' : 'Exceeding target budget')
              : (language === 'ar' ? 'رصيد متاح للبنود القادمة' : 'Available for upcoming services')}
          </span>
        </div>
      </div>

      {/* Progress Bar & Visual Distribution */}
      <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-4">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-[#242320] uppercase tracking-wider">
            {dict.budgetUtilization} ({utilizationPercent}%)
          </span>
          <span className="text-[#77736C] tabular-nums">
            {formatEgp(totalSpent, language)} / {formatEgp(activeEvent.plannedBudgetEgp, language)}
          </span>
        </div>

        <div className="w-full bg-[#F1EDE6] h-3 rounded-full overflow-hidden flex">
          <div
            className={`h-full transition-all duration-500 ${
              utilizationPercent > 90 ? 'bg-[#9E3B3B]' : 'bg-[#B79A66]'
            }`}
            style={{ width: `${utilizationPercent}%` }}
          />
        </div>

        {/* Category Distribution Pills / Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2 text-xs">
          {Object.entries(categoryTotals).map(([catKey, total]) => {
            if (total === 0) return null;
            return (
              <div key={catKey} className="p-2.5 rounded bg-[#FAF8F4] border border-[#E5DFD5]">
                <span className="text-[10px] text-[#77736C] block truncate">
                  {getCategoryName(catKey)}
                </span>
                <span className="font-semibold text-[#242320] tabular-nums">
                  {formatEgp(total, language)}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Expense Ledger Header & Add Button */}
      <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E5DFD5]">
          <div>
            <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
              {language === 'ar' ? 'سجل المصروفات والعقود' : 'Expense & Contract Ledger'}
            </h3>
            <p className="text-xs text-[#77736C] mt-0.5">
              {language === 'ar'
                ? 'إجمالي العقود والمصروفات المسجلة لهذا الحفل'
                : 'All registered vendor retainers, down payments, and commitments'}
            </p>
          </div>

          <button
            onClick={() => setIsAddExpenseOpen(true)}
            className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded flex items-center gap-2 shadow-xs shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>{dict.addExpense}</span>
          </button>
        </div>

        {/* Ledger Table */}
        {eventExpenses.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left rtl:text-right text-xs">
              <thead>
                <tr className="border-b border-[#E5DFD5] text-[#77736C] uppercase tracking-wider font-semibold">
                  <th className="py-3 px-3">{dict.expenseTitle}</th>
                  <th className="py-3 px-3">{dict.expenseCategory}</th>
                  <th className="py-3 px-3">{dict.expenseVendor}</th>
                  <th className="py-3 px-3">{dict.expenseDate}</th>
                  <th className="py-3 px-3 text-right rtl:text-left">{dict.expenseAmount}</th>
                  <th className="py-3 px-3 text-center">{language === 'ar' ? 'حالة السداد' : 'Status'}</th>
                  <th className="py-3 px-3 text-right rtl:text-left">{dict.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F1EDE6]">
                {eventExpenses.map((exp) => (
                  <tr key={exp.id} className="hover:bg-[#FAF8F4] transition-colors">
                    <td className="py-3 px-3 font-medium text-[#242320]">
                      {language === 'ar' ? exp.titleAr : exp.title}
                    </td>
                    <td className="py-3 px-3 text-[#77736C]">
                      {getCategoryName(exp.category)}
                    </td>
                    <td className="py-3 px-3 text-[#77736C]">
                      {exp.vendorName || '—'}
                    </td>
                    <td className="py-3 px-3 text-[#77736C]">
                      {exp.date}
                    </td>
                    <td className="py-3 px-3 text-right rtl:text-left font-semibold text-[#242320] tabular-nums">
                      {formatEgp(exp.amountEgp, language)}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className={`inline-flex items-center gap-1 text-[11px] font-medium ${
                        exp.paid ? 'text-[#2E6B4F]' : 'text-[#A66E1D]'
                      }`}>
                        {exp.paid ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{dict.expensePaid}</span>
                          </>
                        ) : (
                          <>
                            <Clock className="w-3.5 h-3.5" />
                            <span>{dict.expensePending}</span>
                          </>
                        )}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right rtl:text-left">
                      <button
                        onClick={() => deleteExpenseItem(exp.id)}
                        className="p-1.5 text-[#77736C] hover:text-[#9E3B3B] transition-colors rounded"
                        title="Delete expense"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center text-xs text-[#77736C]">
            {language === 'ar' ? 'لا توجد بنود مصروفات مسجلة بعد.' : 'No expenses recorded yet. Click Record Expense to add your first item.'}
          </div>
        )}
      </div>

      {/* Add Expense Modal */}
      {isAddExpenseOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#FAF8F4] w-full max-w-lg rounded-lg shadow-xl border border-[#E5DFD5] p-6 space-y-4">
            <h3 className="font-editorial text-xl font-semibold text-[#242320]">
              {dict.addExpense}
            </h3>

            <form onSubmit={handleCreateExpense} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#242320] mb-1">
                  {language === 'ar' ? 'بيان المصروف بالإنجليزية' : 'Expense Description (English)'}
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Wedding Kosha & Lighting Package"
                  className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#242320] mb-1">
                  {language === 'ar' ? 'بيان المصروف بالعربية' : 'Expense Description (Arabic)'}
                </label>
                <input
                  type="text"
                  value={titleAr}
                  onChange={(e) => setTitleAr(e.target.value)}
                  placeholder="مثال: دفعة تصميم الكوشة والإضاءة الذكية"
                  className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#242320] mb-1">
                    {dict.expenseCategory}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  >
                    <option value="venue">Venue</option>
                    <option value="catering">Catering</option>
                    <option value="photography">Photography</option>
                    <option value="decor">Floral & Decor</option>
                    <option value="attire">Attire</option>
                    <option value="entertainment">Music & Zaffah</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#242320] mb-1">
                    {dict.expenseAmount}
                  </label>
                  <input
                    type="number"
                    step={1000}
                    required
                    value={amountEgp}
                    onChange={(e) => setAmountEgp(Number(e.target.value))}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66] font-semibold tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#242320] mb-1">
                    {dict.expenseVendor}
                  </label>
                  <input
                    type="text"
                    value={vendorName}
                    onChange={(e) => setVendorName(e.target.value)}
                    placeholder="e.g. Maison des Fleurs"
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#242320] mb-1">
                    {dict.expenseDate}
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  />
                </div>
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={paid}
                    onChange={(e) => setPaid(e.target.checked)}
                    className="accent-[#B79A66] w-4 h-4"
                  />
                  <span className="font-semibold text-[#242320]">
                    {dict.expensePaid}
                  </span>
                </label>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddExpenseOpen(false)}
                  className="px-4 py-2 border border-[#E5DFD5] rounded text-xs text-[#77736C] hover:text-[#242320]"
                >
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#242320] hover:bg-[#B79A66] text-white rounded text-xs font-semibold uppercase tracking-wider transition-colors"
                >
                  {language === 'ar' ? 'حفظ المصروف' : 'Record Expense'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
