import React from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, formatEgp, getInquiryStatusLabel } from '../../utils/translations';
import { HERO_IMAGE } from '../../data/mockData';
import { Check, X, Calendar, Users, DollarSign } from 'lucide-react';

export const InquiriesTab: React.FC = () => {
  const { 
    inquiries, 
    activeEvent, 
    customerAcceptQuote, 
    customerDeclineQuote, 
    language, 
    setCurrentView 
  } = useApp();

  const dict = TRANSLATIONS[language];

  // Inquiries for active event
  const eventInquiries = inquiries.filter((inq) => inq.eventId === activeEvent.id);

  return (
    <div className="space-y-6">
      <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block mb-1">
            {language === 'ar' ? 'تنسيق الحجوزات والتعاقدات' : 'Booking & Quote Coordination'}
          </span>
          <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
            {dict.tabInquiries}
          </h3>
          <p className="text-xs text-[#77736C] mt-1">
            {language === 'ar'
              ? 'متابعة الردود وعروض الأسعار الرسمية الواردة من القاعات ومقدمي الخدمات'
              : 'Monitor submitted requests, inspect vendor quotation proposals, and finalize confirmations.'}
          </p>
        </div>

        <button
          onClick={() => setCurrentView('discovery')}
          className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded shadow-xs shrink-0"
        >
          {language === 'ar' ? 'استكشاف موردين جدد' : 'Explore More Vendors'}
        </button>
      </div>

      {eventInquiries.length > 0 ? (
        <div className="space-y-4">
          {eventInquiries.map((inq) => {
            const statusInfo = getInquiryStatusLabel(inq.status, language);

            return (
              <div
                key={inq.id}
                className="bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] p-6 space-y-5 shadow-xs"
              >
                {/* Header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#F1EDE6]">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider text-[#B79A66] font-semibold block mb-0.5">
                      {inq.vendorCategory} · {dict.inquiryEvent}: {inq.eventName}
                    </span>
                    <h4 className="font-editorial text-xl font-semibold text-[#242320]">
                      {language === 'ar' ? inq.vendorNameAr : inq.vendorName}
                    </h4>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className={`px-3 py-1 rounded text-xs font-medium ${statusInfo.color}`}>
                      {statusInfo.label}
                    </span>
                    <span className="text-xs text-[#77736C]">
                      {inq.createdAt}
                    </span>
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div className="p-3 bg-[#FAF8F4] rounded border border-[#E5DFD5] space-y-1">
                    <span className="text-[#77736C] flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#B79A66]" />
                      {dict.eventDate}
                    </span>
                    <span className="font-semibold text-[#242320] block">
                      {inq.eventDate}
                    </span>
                  </div>

                  <div className="p-3 bg-[#FAF8F4] rounded border border-[#E5DFD5] space-y-1">
                    <span className="text-[#77736C] flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-[#B79A66]" />
                      {dict.inquiryGuestCount}
                    </span>
                    <span className="font-semibold text-[#242320] block">
                      {inq.guestCount} {language === 'ar' ? 'معازيم' : 'Guests'}
                    </span>
                  </div>

                  <div className="p-3 bg-[#FAF8F4] rounded border border-[#E5DFD5] space-y-1">
                    <span className="text-[#77736C] flex items-center gap-1.5">
                      <DollarSign className="w-3.5 h-3.5 text-[#B79A66]" />
                      {dict.inquiryQuotedPrice}
                    </span>
                    <span className="font-semibold text-[#242320] block tabular-nums">
                      {inq.quotedPriceEgp ? formatEgp(inq.quotedPriceEgp, language) : 'Pending Vendor Review'}
                    </span>
                  </div>
                </div>

                {/* Requirements & Notes */}
                <div className="text-xs space-y-3 bg-[#FAF8F4] p-4 rounded border border-[#E5DFD5]">
                  <div>
                    <span className="font-semibold text-[#242320] block mb-1">
                      {dict.inquiryRequirements}:
                    </span>
                    <p className="text-[#77736C] leading-relaxed">
                      {inq.requirements}
                    </p>
                  </div>

                  {inq.vendorNotes && (
                    <div className="pt-2 border-t border-[#E5DFD5]/60">
                      <span className="font-semibold text-[#B79A66] block mb-1">
                        {language === 'ar' ? 'رد المورد وبنود الباقة المقترحة:' : 'Vendor Official Response & Proposal:'}
                      </span>
                      <p className="text-[#242320] leading-relaxed">
                        {inq.vendorNotes}
                      </p>
                      {inq.depositRequiredEgp && (
                        <div className="mt-2 text-[11px] text-[#77736C]">
                          {dict.inquiryDeposit}: <span className="font-semibold text-[#242320] tabular-nums">{formatEgp(inq.depositRequiredEgp, language)}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Actions for customer */}
                {inq.status === 'response_received' && (
                  <div className="flex flex-wrap items-center justify-end gap-3 pt-2 border-t border-[#F1EDE6]">
                    <button
                      onClick={() => customerDeclineQuote(inq.id)}
                      className="px-4 py-2 border border-[#E5DFD5] rounded text-xs text-[#77736C] hover:text-[#9E3B3B] hover:border-[#9E3B3B] transition-colors flex items-center gap-1.5"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>{dict.inquiryDeclineQuote}</span>
                    </button>
                    <button
                      onClick={() => {
                        const targetV = useApp().vendors.find((v) => v.id === inq.vendorId) || {
                          id: inq.vendorId,
                          name: inq.vendorName,
                          nameAr: inq.vendorNameAr,
                          category: inq.vendorCategory,
                          city: 'Cairo',
                          cityAr: 'القاهرة',
                          neighborhood: 'Zamalek',
                          neighborhoodAr: 'الزمالك',
                          phone: inq.customerPhone,
                          email: 'booking@layali.eg',
                          whatsapp: '+20100000000',
                          startingPriceEgp: inq.quotedPriceEgp || 50000,
                          coverImage: HERO_IMAGE,
                          galleryImages: [],
                          description: 'Premier Partner',
                          descriptionAr: 'شريك معتمد',
                          packages: [],
                          reviews: [],
                          rating: 4.9,
                          reviewsCount: 12,
                          status: 'active'
                        };
                        useApp().openPayPalModal({
                          vendor: targetV as any,
                          inquiryId: inq.id,
                          quoteAmountEgp: inq.quotedPriceEgp,
                          depositAmountEgp: inq.depositRequiredEgp
                        });
                      }}
                      className="px-5 py-2 bg-[#FFC439] hover:bg-[#F2BA36] text-[#003087] rounded text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-2 shadow-xs"
                    >
                      <span className="font-extrabold italic text-sm">PP</span>
                      <span>{language === 'ar' ? 'سداد العربون عبر باي بال (ضمان فوري)' : 'Pay Deposit via PayPal (Escrow)'}</span>
                    </button>
                    <button
                      onClick={() => customerAcceptQuote(inq.id)}
                      className="px-4 py-2 bg-[#2E6B4F] hover:bg-[#255740] text-white rounded text-xs font-semibold uppercase tracking-wider transition-colors flex items-center gap-2 shadow-xs"
                    >
                      <Check className="w-4 h-4" />
                      <span>{dict.inquiryAcceptQuote}</span>
                    </button>
                  </div>
                )}

                {inq.status === 'confirmed' && (
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <div className="flex items-center gap-2 text-xs text-[#2E6B4F] font-semibold">
                      <Check className="w-4 h-4" />
                      <span>
                        {language === 'ar'
                          ? 'تم تأكيد الحجز رسمياً وحجز الموعد بالضمان.'
                          : 'Booking confirmed and protected under smart escrow.'}
                      </span>
                    </div>

                    <button
                      onClick={() => setCurrentView('paypal_escrow')}
                      className="px-3 py-1.5 rounded-lg border border-[#003087] text-[#003087] hover:bg-[#003087] hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    >
                      <span className="font-extrabold italic text-xs">PP</span>
                      <span>{language === 'ar' ? 'إدارة دفعات باي بال' : 'Manage PayPal Escrow'}</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-12 text-center bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] text-xs text-[#77736C] space-y-3">
          <p>
            {language === 'ar'
              ? 'لا توجد طلبات عروض أسعار مرسلة لهذا الحدث حتى الآن.'
              : 'No booking inquiries submitted for this event yet.'}
          </p>
          <button
            onClick={() => setCurrentView('discovery')}
            className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#242320] border border-[#242320] rounded hover:bg-[#242320] hover:text-white transition-colors"
          >
            {dict.heroCtaSecondary}
          </button>
        </div>
      )}
    </div>
  );
};
