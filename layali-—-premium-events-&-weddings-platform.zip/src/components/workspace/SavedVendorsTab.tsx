import React from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, formatEgp, getCategoryLabel } from '../../utils/translations';
import { Heart, MapPin, Star, Trash2 } from 'lucide-react';

export const SavedVendorsTab: React.FC = () => {
  const { 
    vendors, 
    activeEvent, 
    toggleSaveVendor, 
    setSelectedVendorId, 
    openInquiryModal, 
    language, 
    setCurrentView 
  } = useApp();

  const dict = TRANSLATIONS[language];

  const savedVendors = vendors.filter((v) =>
    activeEvent.savedVendorIds?.includes(v.id)
  );

  return (
    <div className="space-y-6">
      <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block mb-1">
            {language === 'ar' ? 'فريق عمل الحفل المفضل' : 'Selected Event Artisans'}
          </span>
          <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
            {dict.tabVendors}
          </h3>
          <p className="text-xs text-[#77736C] mt-1">
            {language === 'ar'
              ? `${savedVendors.length} مورد محفوظين في قائمة المفضلة لهذا الحفل`
              : `${savedVendors.length} vendors saved and shortlisted for this celebration`}
          </p>
        </div>

        <button
          onClick={() => setCurrentView('discovery')}
          className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded shadow-xs shrink-0"
        >
          {language === 'ar' ? 'استكشاف المزيد من الموردين' : 'Explore More Vendors'}
        </button>
      </div>

      {savedVendors.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {savedVendors.map((vendor) => (
            <div
              key={vendor.id}
              className="bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] overflow-hidden flex flex-col justify-between group hover:shadow-md transition-shadow"
            >
              <div>
                <div className="relative aspect-[4/3] w-full bg-[#E5DFD5]">
                  <img
                    src={vendor.coverImage}
                    alt={language === 'ar' ? vendor.nameAr : vendor.name}
                    className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Remove button */}
                  <button
                    onClick={() => toggleSaveVendor(vendor.id)}
                    className="absolute top-3 right-3 rtl:right-auto rtl:left-3 p-2 rounded-full bg-[#242320]/80 text-[#B79A66] hover:bg-[#242320] transition-colors"
                    title={dict.saveFavorite}
                  >
                    <Heart className="w-4 h-4 fill-current" />
                  </button>

                  <div className="absolute bottom-3 left-3 rtl:left-auto rtl:right-3 bg-[#242320]/80 backdrop-blur-md text-white text-[11px] px-2.5 py-1 rounded">
                    {dict.startingFrom} {formatEgp(vendor.startingPriceEgp, language)}
                  </div>
                </div>

                <div className="p-5 space-y-2">
                  <div className="flex items-center gap-2 text-xs text-[#77736C]">
                    <span>{getCategoryLabel(vendor.category, language)}</span>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-[#B79A66]" />
                      {language === 'ar' ? vendor.cityAr : vendor.city}
                    </span>
                  </div>

                  <h4
                    onClick={() => setSelectedVendorId(vendor.id)}
                    className="font-editorial text-xl font-semibold text-[#242320] hover:text-[#B79A66] transition-colors cursor-pointer"
                  >
                    {language === 'ar' ? vendor.nameAr : vendor.name}
                  </h4>

                  <div className="pt-2 flex items-center justify-between text-xs border-t border-[#F1EDE6]">
                    <div className="flex items-center gap-1 font-semibold text-[#242320]">
                      <Star className="w-3.5 h-3.5 fill-[#B79A66] text-[#B79A66]" />
                      <span className="tabular-nums">{vendor.rating.toFixed(2)}</span>
                    </div>

                    <button
                      onClick={() => toggleSaveVendor(vendor.id)}
                      className="text-[#9E3B3B] hover:underline flex items-center gap-1 text-[11px]"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>{language === 'ar' ? 'إزالة' : 'Remove'}</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-5 pt-0 grid grid-cols-2 gap-2">
                <button
                  onClick={() => setSelectedVendorId(vendor.id)}
                  className="w-full py-2 text-xs font-medium border border-[#E5DFD5] hover:border-[#242320] rounded text-[#242320] transition-colors"
                >
                  {dict.viewProfile}
                </button>
                <button
                  onClick={() => openInquiryModal(vendor)}
                  className="w-full py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] rounded transition-colors shadow-xs"
                >
                  {dict.requestQuote}
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 text-center bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] text-xs text-[#77736C] space-y-3">
          <p>
            {language === 'ar'
              ? 'لم تقم بحفظ أي موردين في المفضلة لهذا الحفل حتى الآن.'
              : 'You have not saved any vendors for this event yet.'}
          </p>
          <button
            onClick={() => setCurrentView('discovery')}
            className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#242320] border border-[#242320] rounded hover:bg-[#242320] hover:text-white transition-colors"
          >
            {dict.heroCtaSecondary}
          </button>
        </div>
      )}
    </div>
  );
};
