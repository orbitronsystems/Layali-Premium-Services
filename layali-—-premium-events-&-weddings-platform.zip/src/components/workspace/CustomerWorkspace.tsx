import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';
import { EventOverviewTab } from './EventOverviewTab';
import { ChecklistTab } from './ChecklistTab';
import { BudgetTab } from './BudgetTab';
import { SavedVendorsTab } from './SavedVendorsTab';
import { InquiriesTab } from './InquiriesTab';
import { TimelineTab } from './TimelineTab';
import { PayPalEscrowDashboard } from '../sponsors/PayPalEscrowDashboard';
import { BryntumRunOfShow } from '../sponsors/BryntumRunOfShow';
import { ZapierAutomationHub } from '../sponsors/ZapierAutomationHub';
import { Plus, ChevronDown, Calendar, Layers, Lock, Zap, Sparkles } from 'lucide-react';

export const CustomerWorkspace: React.FC = () => {
  const { 
    events, 
    activeEvent, 
    setActiveEventId, 
    setIsEventWizardOpen, 
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<
    'overview' | 'checklist' | 'budget' | 'vendors' | 'inquiries' | 'timeline' | 'paypal_escrow' | 'bryntum_runofshow' | 'zapier_sync'
  >('overview');
  const [eventMenuOpen, setEventMenuOpen] = useState(false);

  return (
    <div className="py-8 bg-[#FAF8F4] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Workspace Top Bar & Event Selector */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E5DFD5]">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] uppercase tracking-widest text-[#B79A66] font-semibold">
                {dict.workspaceTitle}
              </span>
              <span className="text-[#E5DFD5]">·</span>
              <span className="text-xs text-[#77736C]">
                {language === 'ar' ? 'التحكم والتنسيق المالي والمهام' : 'Financial & Task Orchestration'}
              </span>
            </div>

            {/* Event Selector Dropdown */}
            <div className="relative inline-block text-left rtl:text-right">
              <button
                onClick={() => setEventMenuOpen(!eventMenuOpen)}
                className="flex items-center gap-2 font-editorial text-2xl sm:text-3xl font-semibold text-[#242320] hover:text-[#B79A66] transition-colors"
              >
                <span>{language === 'ar' ? activeEvent.titleAr || activeEvent.title : activeEvent.title}</span>
                <ChevronDown className="w-5 h-5 text-[#77736C]" />
              </button>

              {eventMenuOpen && (
                <div className="absolute z-20 mt-2 w-72 rounded-lg bg-[#FFFFFF] shadow-xl border border-[#E5DFD5] py-2">
                  <div className="px-3 py-1.5 text-[10px] uppercase tracking-widest text-[#77736C] font-semibold">
                    {dict.switchEvent}
                  </div>
                  {events.map((ev) => (
                    <button
                      key={ev.id}
                      onClick={() => {
                        setActiveEventId(ev.id);
                        setEventMenuOpen(false);
                      }}
                      className={`w-full text-left rtl:text-right px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                        ev.id === activeEvent.id
                          ? 'bg-[#FAF8F4] font-semibold text-[#B79A66]'
                          : 'text-[#242320] hover:bg-[#FAF8F4]'
                      }`}
                    >
                      <span className="truncate">{language === 'ar' ? ev.titleAr || ev.title : ev.title}</span>
                      <span className="text-[10px] text-[#77736C] shrink-0">{ev.date}</span>
                    </button>
                  ))}
                  <div className="pt-2 border-t border-[#F1EDE6] px-2">
                    <button
                      onClick={() => {
                        setEventMenuOpen(false);
                        setIsEventWizardOpen(true);
                      }}
                      className="w-full py-1.5 text-xs text-[#B79A66] hover:text-[#A38652] font-semibold flex items-center gap-1.5 justify-center"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{dict.createEventBtn}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsEventWizardOpen(true)}
              className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded flex items-center gap-2 shadow-xs shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>{dict.createEventBtn}</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation (Zero-pill segmented buttons) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-[#E5DFD5]">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'overview'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.tabOverview}
          </button>
          <button
            onClick={() => setActiveTab('checklist')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'checklist'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.tabChecklist}
          </button>
          <button
            onClick={() => setActiveTab('budget')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'budget'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.tabBudget}
          </button>
          <button
            onClick={() => setActiveTab('vendors')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'vendors'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.tabVendors}
          </button>
          <button
            onClick={() => setActiveTab('inquiries')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'inquiries'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.tabInquiries}
          </button>
          <button
            onClick={() => setActiveTab('timeline')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'timeline'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.tabTimeline}
          </button>

          {/* Sponsor Integrated Tabs */}
          <button
            onClick={() => setActiveTab('paypal_escrow')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 flex items-center gap-1.5 ${
              activeTab === 'paypal_escrow'
                ? 'border-[#003087] text-[#003087] font-bold'
                : 'border-transparent text-[#003087]/80 hover:text-[#003087]'
            }`}
          >
            <span className="font-extrabold italic text-xs">PP</span>
            <span>{language === 'ar' ? 'ضمان باي بال' : 'PayPal Escrow'}</span>
          </button>

          <button
            onClick={() => setActiveTab('bryntum_runofshow')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 flex items-center gap-1.5 ${
              activeTab === 'bryntum_runofshow'
                ? 'border-[#B79A66] text-[#242320] font-bold'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#B79A66]" />
            <span>{language === 'ar' ? 'جدول برينتوم' : 'Bryntum Run-of-Show'}</span>
          </button>

          <button
            onClick={() => setActiveTab('zapier_sync')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 flex items-center gap-1.5 ${
              activeTab === 'zapier_sync'
                ? 'border-[#FF4F00] text-[#FF4F00] font-bold'
                : 'border-transparent text-[#FF4F00]/80 hover:text-[#FF4F00]'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-[#FF4F00]" />
            <span>{language === 'ar' ? 'أتمتة زابيير' : 'Zapier Sync'}</span>
          </button>
        </div>

        {/* Tab View Output */}
        <div>
          {activeTab === 'overview' && <EventOverviewTab onTabChange={setActiveTab} />}
          {activeTab === 'checklist' && <ChecklistTab />}
          {activeTab === 'budget' && <BudgetTab />}
          {activeTab === 'vendors' && <SavedVendorsTab />}
          {activeTab === 'inquiries' && <InquiriesTab />}
          {activeTab === 'timeline' && <TimelineTab />}
          {activeTab === 'paypal_escrow' && <PayPalEscrowDashboard />}
          {activeTab === 'bryntum_runofshow' && <BryntumRunOfShow />}
          {activeTab === 'zapier_sync' && <ZapierAutomationHub />}
        </div>
      </div>
    </div>
  );
};
