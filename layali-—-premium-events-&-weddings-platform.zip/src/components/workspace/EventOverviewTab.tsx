import React from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, formatEgp, getInquiryStatusLabel } from '../../utils/translations';
import { 
  Calendar, 
  MapPin, 
  Users, 
  CheckCircle2, 
  DollarSign, 
  ArrowRight, 
  Plus, 
  Heart, 
  Clock, 
  Sparkles 
} from 'lucide-react';

interface EventOverviewTabProps {
  onTabChange: (tab: 'checklist' | 'budget' | 'vendors' | 'inquiries' | 'timeline') => void;
}

export const EventOverviewTab: React.FC<EventOverviewTabProps> = ({ onTabChange }) => {
  const { 
    activeEvent, 
    checklist, 
    expenses, 
    inquiries, 
    vendors, 
    language, 
    setCurrentView, 
    toggleTaskCompletion, 
    openInquiryModal, 
    setSelectedVendorId 
  } = useApp();

  const dict = TRANSLATIONS[language];

  // Calculations for active event
  const eventTasks = checklist.filter((t) => t.eventId === activeEvent.id);
  const completedTasks = eventTasks.filter((t) => t.completed).length;
  const progressPercent = eventTasks.length > 0 ? Math.round((completedTasks / eventTasks.length) * 100) : 0;

  const eventExpenses = expenses.filter((e) => e.eventId === activeEvent.id);
  const totalSpent = eventExpenses.reduce((sum, item) => sum + item.amountEgp, 0);
  const remainingBudget = activeEvent.plannedBudgetEgp - totalSpent;

  const eventInquiries = inquiries.filter((i) => i.eventId === activeEvent.id);
  const savedVendors = vendors.filter((v) => activeEvent.savedVendorIds?.includes(v.id));

  // Countdown in days
  const calculateDaysLeft = (targetDate: string) => {
    const diff = new Date(targetDate).getTime() - new Date().getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return days > 0 ? days : 0;
  };

  const daysLeft = calculateDaysLeft(activeEvent.date);

  return (
    <div className="space-y-8">
      {/* Personalized Banner Card */}
      <div className="relative rounded-xl overflow-hidden bg-[#252522] text-white p-6 sm:p-8 border border-[#3A3834] shadow-md">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#B79A66] font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{activeEvent.type.toUpperCase()} · {activeEvent.city}</span>
            </div>

            <h2 className="font-editorial text-2xl sm:text-3xl lg:text-4xl font-semibold text-[#FAF8F4]">
              {language === 'ar' ? activeEvent.titleAr || activeEvent.title : activeEvent.title}
            </h2>

            <div className="flex flex-wrap items-center gap-4 text-xs text-[#B5B0A6] pt-1">
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#B79A66]" />
                {activeEvent.date}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#B79A66]" />
                {activeEvent.venueName}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-[#B79A66]" />
                {activeEvent.guestCount} {language === 'ar' ? 'ضيف' : 'Guests'}
              </span>
            </div>
          </div>

          {/* Countdown pill */}
          <div className="bg-[#1A1A18] border border-[#3A3834] p-4 rounded-lg text-center shrink-0 min-w-[130px]">
            <span className="font-editorial text-3xl sm:text-4xl font-semibold text-[#B79A66] tabular-nums block">
              {daysLeft}
            </span>
            <span className="text-[11px] uppercase tracking-wider text-[#B5B0A6] block mt-0.5">
              {dict.daysRemaining}
            </span>
          </div>
        </div>
      </div>

      {/* KPI Cards Row (Single-Elevation Anti-Slop: hairline borders, zero pill clutter) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Progress */}
        <div 
          onClick={() => onTabChange('checklist')}
          className="p-5 bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] space-y-2 cursor-pointer hover:border-[#B79A66] transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-[#77736C]">
            <span className="uppercase tracking-wider font-semibold">{dict.planningProgress}</span>
            <CheckCircle2 className="w-4 h-4 text-[#2E6B4F]" />
          </div>
          <div className="font-editorial text-2xl font-semibold text-[#242320] tabular-nums">
            {progressPercent}%
          </div>
          <div className="w-full bg-[#F1EDE6] h-1.5 rounded-full overflow-hidden">
            <div className="bg-[#2E6B4F] h-full" style={{ width: `${progressPercent}%` }} />
          </div>
          <span className="text-[11px] text-[#77736C] block">
            {completedTasks} / {eventTasks.length} {language === 'ar' ? 'مهام منجزة' : 'tasks completed'}
          </span>
        </div>

        {/* Planned Budget */}
        <div 
          onClick={() => onTabChange('budget')}
          className="p-5 bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] space-y-2 cursor-pointer hover:border-[#B79A66] transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-[#77736C]">
            <span className="uppercase tracking-wider font-semibold">{dict.plannedBudget}</span>
            <DollarSign className="w-4 h-4 text-[#B79A66]" />
          </div>
          <div className="font-editorial text-2xl font-semibold text-[#242320] tabular-nums">
            {formatEgp(activeEvent.plannedBudgetEgp, language)}
          </div>
          <span className="text-[11px] text-[#77736C] block">
            {language === 'ar' ? 'الميزانية المستهدفة' : 'Allocated target'}
          </span>
        </div>

        {/* Recorded Expenses */}
        <div 
          onClick={() => onTabChange('budget')}
          className="p-5 bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] space-y-2 cursor-pointer hover:border-[#B79A66] transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-[#77736C]">
            <span className="uppercase tracking-wider font-semibold">{dict.recordedExpenses}</span>
            <span className="text-xs font-semibold text-[#B79A66]">
              {Math.round((totalSpent / (activeEvent.plannedBudgetEgp || 1)) * 100)}%
            </span>
          </div>
          <div className="font-editorial text-2xl font-semibold text-[#B79A66] tabular-nums">
            {formatEgp(totalSpent, language)}
          </div>
          <span className="text-[11px] text-[#77736C] block">
            {formatEgp(remainingBudget, language)} {language === 'ar' ? 'متبقي' : 'remaining'}
          </span>
        </div>

        {/* Active Inquiries */}
        <div 
          onClick={() => onTabChange('inquiries')}
          className="p-5 bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] space-y-2 cursor-pointer hover:border-[#B79A66] transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-[#77736C]">
            <span className="uppercase tracking-wider font-semibold">{dict.activeInquiriesCount}</span>
            <Clock className="w-4 h-4 text-[#B79A66]" />
          </div>
          <div className="font-editorial text-2xl font-semibold text-[#242320] tabular-nums">
            {eventInquiries.length}
          </div>
          <span className="text-[11px] text-[#77736C] block">
            {eventInquiries.filter((i) => i.status === 'confirmed').length} {language === 'ar' ? 'حجوزات مؤكدة' : 'confirmed'}
          </span>
        </div>
      </div>

      {/* 2-Column Split: Tasks & Inquiries */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Upcoming Tasks */}
        <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1EDE6]">
            <div>
              <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                {language === 'ar' ? 'المهام القادمة' : 'Upcoming Tasks'}
              </h3>
              <span className="text-[11px] text-[#77736C]">
                {eventTasks.filter((t) => !t.completed).length} {language === 'ar' ? 'مهام بانتظار الإنجاز' : 'pending milestones'}
              </span>
            </div>

            <button
              onClick={() => onTabChange('checklist')}
              className="text-xs font-semibold text-[#B79A66] hover:underline flex items-center gap-1"
            >
              <span>{language === 'ar' ? 'عرض الكل' : 'View all'}</span>
              <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
            </button>
          </div>

          <div className="space-y-2.5">
            {eventTasks.slice(0, 4).map((task) => (
              <div
                key={task.id}
                onClick={() => toggleTaskCompletion(task.id)}
                className="p-3 rounded-lg border border-[#E5DFD5] hover:border-[#B79A66] transition-colors flex items-center justify-between gap-3 text-xs cursor-pointer bg-[#FAF8F4]"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                    task.completed ? 'bg-[#2E6B4F] border-[#2E6B4F] text-white' : 'border-[#B79A66]'
                  }`}>
                    {task.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </div>
                  <span className={task.completed ? 'line-through text-[#77736C]' : 'font-medium text-[#242320]'}>
                    {language === 'ar' ? task.titleAr : task.title}
                  </span>
                </div>
                <span className="text-[11px] text-[#77736C] shrink-0">{task.dueDate}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Booking Requests & RFPs */}
        <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1EDE6]">
            <div>
              <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                {language === 'ar' ? 'طلبات الأسعار والحجوزات' : 'Recent Inquiries & Quotes'}
              </h3>
              <span className="text-[11px] text-[#77736C]">
                {language === 'ar' ? 'الموردين الذين تم التواصل معهم' : 'Coordinated partner suppliers'}
              </span>
            </div>

            <button
              onClick={() => onTabChange('inquiries')}
              className="text-xs font-semibold text-[#B79A66] hover:underline flex items-center gap-1"
            >
              <span>{language === 'ar' ? 'عرض الكل' : 'View all'}</span>
              <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
            </button>
          </div>

          <div className="space-y-2.5">
            {eventInquiries.length > 0 ? (
              eventInquiries.slice(0, 3).map((inq) => {
                const statusInfo = getInquiryStatusLabel(inq.status, language);
                return (
                  <div
                    key={inq.id}
                    onClick={() => onTabChange('inquiries')}
                    className="p-3 rounded-lg border border-[#E5DFD5] hover:border-[#B79A66] transition-colors flex items-center justify-between gap-3 text-xs cursor-pointer bg-[#FAF8F4]"
                  >
                    <div>
                      <h4 className="font-semibold text-[#242320]">
                        {language === 'ar' ? inq.vendorNameAr : inq.vendorName}
                      </h4>
                      <span className="text-[11px] text-[#77736C]">
                        {inq.quotedPriceEgp ? formatEgp(inq.quotedPriceEgp, language) : 'Awaiting quote'}
                      </span>
                    </div>

                    <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${statusInfo.color}`}>
                      {statusInfo.label}
                    </span>
                  </div>
                );
              })
            ) : (
              <p className="text-xs text-[#77736C] italic py-4 text-center">
                {language === 'ar' ? 'لا توجد طلبات أسعار نشطة حالياً.' : 'No active inquiries yet.'}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Saved Vendors Carousel / Strip */}
      <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#F1EDE6]">
          <div>
            <h3 className="font-editorial text-xl font-semibold text-[#242320]">
              {language === 'ar' ? 'الموردون المحفوظون في قائمة المفضلة' : 'Saved Event Artisans'}
            </h3>
            <span className="text-[11px] text-[#77736C]">
              {savedVendors.length} {language === 'ar' ? 'موردين متاحين للطلب المباشر' : 'vendors shortlisted'}
            </span>
          </div>

          <button
            onClick={() => setCurrentView('discovery')}
            className="text-xs font-semibold text-[#B79A66] hover:underline flex items-center gap-1"
          >
            <span>{language === 'ar' ? 'تصفح الدليل' : 'Browse directory'}</span>
            <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
          </button>
        </div>

        {savedVendors.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {savedVendors.slice(0, 4).map((vendor) => (
              <div
                key={vendor.id}
                onClick={() => setSelectedVendorId(vendor.id)}
                className="group cursor-pointer rounded-lg border border-[#E5DFD5] overflow-hidden bg-[#FAF8F4] hover:shadow-sm transition-shadow"
              >
                <div className="aspect-[4/3] w-full bg-[#E5DFD5] overflow-hidden">
                  <img
                    src={vendor.coverImage}
                    alt={vendor.name}
                    className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-3 space-y-1 text-xs">
                  <h4 className="font-editorial text-base font-semibold text-[#242320] truncate">
                    {language === 'ar' ? vendor.nameAr : vendor.name}
                  </h4>
                  <div className="flex items-center justify-between text-[11px] text-[#77736C]">
                    <span>{vendor.city}</span>
                    <span className="font-semibold text-[#B79A66] tabular-nums">
                      {formatEgp(vendor.startingPriceEgp, language)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-[#77736C] py-4 text-center">
            {language === 'ar' ? 'لم تحفظ أي موردين حتى الآن.' : 'No saved vendors in favorites.'}
          </p>
        )}
      </div>
    </div>
  );
};
