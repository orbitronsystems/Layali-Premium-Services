import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, formatEgp, getCategoryLabel } from '../../utils/translations';
import { X, Heart, MapPin, Users, Check, Star } from 'lucide-react';

export const VendorDetailModal: React.FC = () => {
  const { 
    selectedVendor, 
    setSelectedVendorId, 
    language, 
    activeEvent, 
    toggleSaveVendor, 
    openInquiryModal,
    openPayPalModal 
  } = useApp();

  const [activeImageIndex, setActiveImageIndex] = useState(0);

  if (!selectedVendor) return null;

  const dict = TRANSLATIONS[language];
  const isSaved = activeEvent?.savedVendorIds?.includes(selectedVendor.id);
  const images = selectedVendor.galleryImages?.length ? selectedVendor.galleryImages : [selectedVendor.coverImage];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div 
        role="dialog"
        aria-modal="true"
        aria-labelledby="vendor-detail-title"
        className="bg-[#FAF8F4] w-full max-w-4xl rounded-lg shadow-2xl border border-[#E5DFD5] overflow-hidden my-auto max-h-[92vh] flex flex-col"
      >
        {/* Header bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5DFD5] bg-[#FFFFFF]">
          <div className="flex items-center gap-3">
            <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold">
              {getCategoryLabel(selectedVendor.category, language)}
            </span>
            <span className="text-[#E5DFD5]">·</span>
            <span className="text-xs text-[#77736C]">
              {language === 'ar' ? selectedVendor.cityAr : selectedVendor.city}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleSaveVendor(selectedVendor.id)}
              className={`p-2 rounded border transition-colors flex items-center gap-1.5 text-xs ${
                isSaved
                  ? 'border-[#B79A66] bg-[#B79A66]/10 text-[#B79A66]'
                  : 'border-[#E5DFD5] text-[#77736C] hover:text-[#242320]'
              }`}
            >
              <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
              <span className="hidden sm:inline">
                {isSaved ? dict.savedFavorite : dict.saveFavorite}
              </span>
            </button>
            <button
              onClick={() => setSelectedVendorId(null)}
              className="p-2 text-[#77736C] hover:text-[#242320] transition-colors rounded"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-6 space-y-8 flex-1">
          {/* Main Gallery */}
          <div className="space-y-3">
            <div className="aspect-[16/9] w-full bg-[#E5DFD5] rounded overflow-hidden relative shadow-inner">
              <img
                src={images[activeImageIndex] || selectedVendor.coverImage}
                alt={language === 'ar' ? selectedVendor.nameAr : selectedVendor.name}
                className="w-full h-full object-cover transition-opacity duration-300"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-3 left-3 rtl:left-auto rtl:right-3 bg-[#242320]/80 backdrop-blur-md text-white text-xs px-3 py-1.5 rounded">
                {formatEgp(selectedVendor.startingPriceEgp, language)} · {dict.startingFrom}
              </div>
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-20 h-14 rounded overflow-hidden shrink-0 border-2 transition-all ${
                      activeImageIndex === idx ? 'border-[#B79A66]' : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={img}
                      alt="Thumbnail"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Title & Location details */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
              <h2 id="vendor-detail-title" className="font-editorial text-2xl sm:text-3xl font-semibold text-[#242320]">
                {language === 'ar' ? selectedVendor.nameAr : selectedVendor.name}
              </h2>
              <div className="flex items-center gap-1 text-sm font-semibold text-[#242320]">
                <Star className="w-4 h-4 fill-[#B79A66] text-[#B79A66]" />
                <span className="tabular-nums">{selectedVendor.rating.toFixed(2)}</span>
                <span className="text-xs text-[#77736C]">({selectedVendor.reviewsCount} {dict.reviews})</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs text-[#77736C]">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#B79A66]" />
                {language === 'ar' ? selectedVendor.neighborhoodAr : selectedVendor.neighborhood}
              </span>
              {selectedVendor.capacity && (
                <>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-[#B79A66]" />
                    {selectedVendor.capacity}
                  </span>
                </>
              )}
            </div>

            <p className="text-sm text-[#77736C] leading-relaxed pt-2">
              {language === 'ar' ? selectedVendor.descriptionAr : selectedVendor.description}
            </p>
          </div>

          {/* Packages section */}
          {selectedVendor.packages && selectedVendor.packages.length > 0 && (
            <div className="space-y-4 pt-4 border-t border-[#E5DFD5]">
              <h3 className="text-sm uppercase tracking-widest font-semibold text-[#242320]">
                {language === 'ar' ? 'الباقات والخدمات المتوفرة' : 'Available Packages & Inclusions'}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {selectedVendor.packages.map((pkg) => (
                  <div key={pkg.id} className="p-5 rounded border border-[#E5DFD5] bg-[#FFFFFF] flex flex-col justify-between space-y-4">
                    <div>
                      <div className="flex items-baseline justify-between gap-2 mb-2">
                        <h4 className="font-editorial text-lg font-semibold text-[#242320]">
                          {language === 'ar' ? pkg.nameAr : pkg.name}
                        </h4>
                        <span className="text-sm font-semibold text-[#B79A66] tabular-nums">
                          {formatEgp(pkg.priceEgp, language)}
                        </span>
                      </div>
                      <p className="text-xs text-[#77736C] leading-relaxed mb-3">
                        {language === 'ar' ? pkg.descriptionAr : pkg.description}
                      </p>
                      
                      <ul className="space-y-1.5 text-xs text-[#242320]">
                        {(language === 'ar' ? pkg.featuresAr : pkg.features).map((feat, fIdx) => (
                          <li key={fIdx} className="flex items-center gap-2">
                            <Check className="w-3.5 h-3.5 text-[#2E6B4F] shrink-0" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedVendorId(null);
                        openInquiryModal(selectedVendor);
                      }}
                      className="w-full py-2 text-xs font-semibold uppercase tracking-wider text-[#242320] border border-[#242320] hover:bg-[#242320] hover:text-white transition-colors rounded"
                    >
                      {dict.requestQuote}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Verified Egyptian Reviews (clearly identified as demo data) */}
          <div className="space-y-3 pt-4 border-t border-[#E5DFD5]">
            <div className="flex items-baseline justify-between">
              <h3 className="text-sm uppercase tracking-widest font-semibold text-[#242320]">
                {language === 'ar' ? 'تجارب العملاء' : 'Client Testimonials'}
              </h3>
              <span className="text-[11px] text-[#77736C]">
                {dict.sampleReviewNote}
              </span>
            </div>

            {selectedVendor.reviews && selectedVendor.reviews.length > 0 ? (
              <div className="space-y-3">
                {selectedVendor.reviews.map((rev) => (
                  <div key={rev.id} className="p-4 rounded border border-[#E5DFD5] bg-[#FFFFFF] space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-[#242320]">
                        {language === 'ar' ? rev.authorAr : rev.author}
                      </span>
                      <span className="text-[#77736C]">{rev.date}</span>
                    </div>
                    <div className="flex items-center gap-1 text-[#B79A66]">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-current" />
                      ))}
                    </div>
                    <p className="text-xs text-[#77736C] italic leading-relaxed">
                      "{language === 'ar' ? rev.commentAr : rev.comment}"
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[#77736C] italic">
                {language === 'ar'
                  ? 'لا توجد تقييمات منشورة لهذا المورد في بيانات العرض التوضيحي.'
                  : 'No reviews registered for this vendor in demo data.'}
              </p>
            )}
          </div>
        </div>

        {/* Footer sticky bar with primary action */}
        <div className="px-6 py-4 bg-[#FFFFFF] border-t border-[#E5DFD5] flex items-center justify-between gap-4">
          <div>
            <span className="text-xs text-[#77736C] block">{dict.startingFrom}</span>
            <span className="text-lg font-semibold text-[#242320] tabular-nums">
              {formatEgp(selectedVendor.startingPriceEgp, language)}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => toggleSaveVendor(selectedVendor.id)}
              className="px-3.5 py-2 text-xs font-medium border border-[#E5DFD5] rounded hover:border-[#242320] transition-colors"
            >
              {isSaved ? dict.savedFavorite : dict.saveFavorite}
            </button>
            <button
              onClick={() => {
                const vendorToBook = selectedVendor;
                setSelectedVendorId(null);
                openPayPalModal({
                  vendor: vendorToBook,
                  quoteAmountEgp: vendorToBook.startingPriceEgp,
                  depositAmountEgp: Math.round(vendorToBook.startingPriceEgp * 0.20)
                });
              }}
              className="px-4 py-2 bg-[#FFC439] hover:bg-[#F2BA36] text-[#003087] rounded text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <span className="font-extrabold italic text-sm">PP</span>
              <span>{language === 'ar' ? 'حجز الموعد بعربون باي بال' : 'Book with PayPal Deposit'}</span>
            </button>
            <button
              onClick={() => {
                setSelectedVendorId(null);
                openInquiryModal(selectedVendor);
              }}
              className="px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded shadow-sm"
            >
              {dict.requestQuote}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
