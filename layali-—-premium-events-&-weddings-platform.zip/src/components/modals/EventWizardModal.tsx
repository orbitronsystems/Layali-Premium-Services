import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, formatEgp } from '../../utils/translations';
import { EventType } from '../../types';
import { X, ArrowRight, ArrowLeft, Check, Sparkles } from 'lucide-react';

export const EventWizardModal: React.FC = () => {
  const { isEventWizardOpen, setIsEventWizardOpen, createNewEvent, language } = useApp();
  const dict = TRANSLATIONS[language];

  const [step, setStep] = useState(1);
  const [eventType, setEventType] = useState<EventType>('wedding');
  const [title, setTitle] = useState('');
  const [titleAr, setTitleAr] = useState('');
  const [coupleNames, setCoupleNames] = useState('');
  const [date, setDate] = useState('2027-05-15');
  const [city, setCity] = useState('New Cairo');
  const [venueName, setVenueName] = useState('Grand Nile Ballroom');
  const [plannedBudgetEgp, setPlannedBudgetEgp] = useState<number>(850000);
  const [guestCount, setGuestCount] = useState<number>(300);

  if (!isEventWizardOpen) return null;

  const eventTypesList: { id: EventType; label: string; labelAr: string; desc: string; descAr: string }[] = [
    {
      id: 'wedding',
      label: 'Luxury Wedding',
      labelAr: 'حفل زفاف فاخر',
      desc: 'Complete ceremonial banquet, zaffah, scenography & dining',
      descAr: 'حفل زفاف متكامل مع زفة ملكية وتنسيق كوشة ووليمة عشاء'
    },
    {
      id: 'engagement',
      label: 'Engagement Celebration',
      labelAr: 'حفل خطوبة راقٍ',
      desc: 'Sunset cocktail soirée or intimate garden banquet',
      descAr: 'سهرة خطوبة عند الغروب أو احتفال أنيق في حديقة خاصة'
    },
    {
      id: 'cultural_celebration',
      label: 'Katb Ketab / Nikah',
      labelAr: 'عقد قران / كتب كتاب',
      desc: 'Sacred ceremony, historic mosque, or palace pavilion',
      descAr: 'مراسم كتب الكتاب في مسجد تاريخي أو قصر عريق'
    },
    {
      id: 'private_party',
      label: 'Private Gala & Anniversary',
      labelAr: 'حفل خاص / سهرة سنوية',
      desc: 'Milestone celebrations and private family galas',
      descAr: 'احتفالات اليوبيل والفعاليات العائلية والخاصة'
    }
  ];

  const citiesList = [
    { en: 'Cairo', ar: 'القاهرة' },
    { en: 'New Cairo', ar: 'القاهرة الجديدة' },
    { en: 'Sheikh Zayed', ar: 'الشيخ زايد' },
    { en: 'Giza', ar: 'الجيزة' },
    { en: 'Alexandria', ar: 'الإسكندرية' }
  ];

  const handleNext = () => {
    if (step === 2 && !title) {
      const generatedTitle = coupleNames ? `${coupleNames}'s Celebration` : 'Grand Celebration';
      const generatedTitleAr = coupleNames ? `حفل ${coupleNames}` : 'حفل فاخر';
      setTitle(generatedTitle);
      setTitleAr(generatedTitleAr);
    }
    setStep((prev) => Math.min(5, prev + 1));
  };

  const handlePrev = () => {
    setStep((prev) => Math.max(1, prev - 1));
  };

  const handleFinish = () => {
    const finalCityObj = citiesList.find((c) => c.en === city) || citiesList[0];
    createNewEvent({
      title: title || 'New Celebration',
      titleAr: titleAr || 'احتفال جديد',
      type: eventType,
      date,
      city,
      cityAr: finalCityObj.ar,
      venueName: venueName || 'Palais du Nil',
      plannedBudgetEgp: Number(plannedBudgetEgp),
      guestCount: Number(guestCount)
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div 
        role="dialog"
        aria-modal="true"
        aria-labelledby="wizard-title"
        className="bg-[#FAF8F4] w-full max-w-2xl rounded-lg shadow-2xl border border-[#E5DFD5] overflow-hidden my-auto max-h-[92vh] flex flex-col"
      >
        {/* Wizard Header with Progress */}
        <div className="px-6 py-4 border-b border-[#E5DFD5] bg-[#FFFFFF]">
          <div className="flex items-center justify-between mb-3">
            <div>
              <span className="text-[11px] uppercase tracking-widest text-[#B79A66] font-semibold">
                {language === 'ar' ? `الخطوة ${step} من ٥` : `Step ${step} of 5`}
              </span>
              <h2 id="wizard-title" className="font-editorial text-xl font-semibold text-[#242320]">
                {dict.wizardTitle}
              </h2>
            </div>
            <button
              onClick={() => setIsEventWizardOpen(false)}
              className="p-2 text-[#77736C] hover:text-[#242320] transition-colors rounded"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stepper bar */}
          <div className="grid grid-cols-5 gap-1.5 h-1.5 bg-[#F1EDE6] rounded-full overflow-hidden">
            {[1, 2, 3, 4, 5].map((s) => (
              <div
                key={s}
                className={`h-full transition-all duration-300 ${
                  s <= step ? 'bg-[#B79A66]' : 'bg-transparent'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Wizard Step Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* STEP 1: Event Type */}
          {step === 1 && (
            <div className="space-y-4 animate-fade-in">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-[#242320]">
                {dict.wizardStep1}
              </h3>
              <p className="text-xs text-[#77736C]">
                {language === 'ar'
                  ? 'اختر نوع الاحتفال لتخصيص بنود التخطيط والمهام المناسبة لمناسبتك.'
                  : 'Select the nature of your event to calibrate appropriate timeline milestones and vendors.'}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                {eventTypesList.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setEventType(item.id)}
                    className={`p-4 text-left rtl:text-right rounded border transition-all ${
                      eventType === item.id
                        ? 'border-[#B79A66] bg-[#FFFFFF] shadow-sm'
                        : 'border-[#E5DFD5] bg-[#FFFFFF]/60 hover:bg-[#FFFFFF]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-semibold text-sm text-[#242320]">
                        {language === 'ar' ? item.labelAr : item.label}
                      </span>
                      {eventType === item.id && (
                        <Check className="w-4 h-4 text-[#B79A66]" />
                      )}
                    </div>
                    <p className="text-xs text-[#77736C] leading-relaxed">
                      {language === 'ar' ? item.descAr : item.desc}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: Name & Details */}
          {step === 2 && (
            <div className="space-y-4 animate-fade-in">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-[#242320]">
                {dict.wizardStep2}
              </h3>
              <p className="text-xs text-[#77736C]">
                {language === 'ar'
                  ? 'أدخل أسماء العروسين أو أصحاب الحفل واسم الفعالية المفضل.'
                  : 'Specify the couple or host names to personalize your planning ledger and invitations.'}
              </p>

              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-[#242320] mb-1">
                    {language === 'ar' ? 'أسماء العروسين أو صاحب الدعوة' : 'Couple / Host Names'}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Youssef & Malak"
                    value={coupleNames}
                    onChange={(e) => {
                      setCoupleNames(e.target.value);
                      if (!title) {
                        setTitle(`${e.target.value}'s Wedding Celebration`);
                        setTitleAr(`حفل زفاف ${e.target.value}`);
                      }
                    }}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#242320] mb-1">
                    {language === 'ar' ? 'عنوان الفعالية بالإنجليزية' : 'Event Workspace Title (English)'}
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Youssef & Malak's Grand Nile Wedding"
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#242320] mb-1">
                    {language === 'ar' ? 'عنوان الفعالية بالعربية' : 'Event Workspace Title (Arabic)'}
                  </label>
                  <input
                    type="text"
                    value={titleAr}
                    onChange={(e) => setTitleAr(e.target.value)}
                    placeholder="مثال: حفل زفاف يوسف وملاك الملكي"
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Date & Location */}
          {step === 3 && (
            <div className="space-y-4 animate-fade-in">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-[#242320]">
                {dict.wizardStep3}
              </h3>
              <p className="text-xs text-[#77736C]">
                {language === 'ar'
                  ? 'حدد التاريخ المتوقع والمنطقة داخل جمهورية مصر العربية.'
                  : 'Choose target celebration date and geographic region across Egypt.'}
              </p>

              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-[#242320] mb-1">
                    {dict.eventDate}
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#242320] mb-1">
                    {dict.filterCity}
                  </label>
                  <select
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  >
                    {citiesList.map((c) => (
                      <option key={c.en} value={c.en}>
                        {language === 'ar' ? c.ar : c.en}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#242320] mb-1">
                    {language === 'ar' ? 'القاعة أو المكان المفضل (اختياري)' : 'Target Venue or Area'}
                  </label>
                  <input
                    type="text"
                    value={venueName}
                    onChange={(e) => setVenueName(e.target.value)}
                    placeholder="e.g. Palais du Nil Grand Ballroom or New Cairo Estate"
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: Budget & Guests */}
          {step === 4 && (
            <div className="space-y-4 animate-fade-in">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-[#242320]">
                {dict.wizardStep4}
              </h3>
              <p className="text-xs text-[#77736C]">
                {language === 'ar'
                  ? 'أدخل الميزانية المستهدفة بالجنيه المصري وعدد الضيوف المتوقع.'
                  : 'Define your target budget allocation in EGP and expected guest attendance.'}
              </p>

              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-[#242320] mb-1">
                    {dict.plannedBudget} ({language === 'ar' ? 'جنيه مصري' : 'EGP'})
                  </label>
                  <input
                    type="number"
                    step={10000}
                    value={plannedBudgetEgp}
                    onChange={(e) => setPlannedBudgetEgp(Number(e.target.value))}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66] tabular-nums font-semibold"
                  />
                  <span className="text-xs text-[#B79A66] mt-1 block">
                    {formatEgp(plannedBudgetEgp, language)}
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#242320] mb-1">
                    {dict.guestCountInput}
                  </label>
                  <input
                    type="number"
                    min={20}
                    max={2000}
                    value={guestCount}
                    onChange={(e) => setGuestCount(Number(e.target.value))}
                    className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66] tabular-nums"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: Review & Launch */}
          {step === 5 && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#B79A66]" />
                <h3 className="text-sm font-semibold uppercase tracking-wider text-[#242320]">
                  {dict.wizardStep5}
                </h3>
              </div>
              <p className="text-xs text-[#77736C]">
                {language === 'ar'
                  ? 'راجع تفاصيل الحدث لبدء تجهيز مساحة التخطيط والميزانية وقائمة المهام التفاعلية.'
                  : 'Review summary before generating your personalized event workspace.'}
              </p>

              <div className="p-4 bg-[#FFFFFF] border border-[#E5DFD5] rounded space-y-3 text-xs">
                <div className="flex justify-between py-1 border-b border-[#F1EDE6]">
                  <span className="text-[#77736C]">{language === 'ar' ? 'نوع الحدث' : 'Event Type'}</span>
                  <span className="font-semibold text-[#242320] uppercase">{eventType}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#F1EDE6]">
                  <span className="text-[#77736C]">{language === 'ar' ? 'اسم الحدث' : 'Title'}</span>
                  <span className="font-semibold text-[#242320]">{language === 'ar' ? titleAr || title : title}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#F1EDE6]">
                  <span className="text-[#77736C]">{dict.eventDate}</span>
                  <span className="font-semibold text-[#242320]">{date}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#F1EDE6]">
                  <span className="text-[#77736C]">{dict.filterCity}</span>
                  <span className="font-semibold text-[#242320]">{city} · {venueName}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#F1EDE6]">
                  <span className="text-[#77736C]">{dict.plannedBudget}</span>
                  <span className="font-semibold text-[#B79A66]">{formatEgp(plannedBudgetEgp, language)}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-[#77736C]">{dict.guestCountInput}</span>
                  <span className="font-semibold text-[#242320]">{guestCount} {language === 'ar' ? 'ضيف' : 'Guests'}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Wizard Controls */}
        <div className="px-6 py-4 bg-[#FFFFFF] border-t border-[#E5DFD5] flex items-center justify-between">
          {step > 1 ? (
            <button
              onClick={handlePrev}
              className="px-4 py-2 text-xs font-semibold text-[#77736C] hover:text-[#242320] flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5 rtl:rotate-180" />
              <span>{dict.prevStep}</span>
            </button>
          ) : (
            <div />
          )}

          {step < 5 ? (
            <button
              onClick={handleNext}
              className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded flex items-center gap-2 shadow-sm"
            >
              <span>{dict.nextStep}</span>
              <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
            </button>
          ) : (
            <button
              onClick={handleFinish}
              className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#2E6B4F] hover:bg-[#255740] transition-colors rounded flex items-center gap-2 shadow-sm"
            >
              <Check className="w-4 h-4" />
              <span>{dict.createEventSubmit}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
