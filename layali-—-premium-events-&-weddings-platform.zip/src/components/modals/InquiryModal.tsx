import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, formatEgp } from '../../utils/translations';
import { X, Send, ShieldAlert } from 'lucide-react';

export const InquiryModal: React.FC = () => {
  const { 
    inquiryTargetVendor, 
    closeInquiryModal, 
    events, 
    activeEvent, 
    submitBookingInquiry, 
    language 
  } = useApp();

  const [selectedEventId, setSelectedEventId] = useState(activeEvent?.id || (events[0]?.id || ''));
  const [customerName, setCustomerName] = useState('Nour El-Din');
  const [customerEmail, setCustomerEmail] = useState('nour.eldin@example.eg');
  const [customerPhone, setCustomerPhone] = useState('+20 102 889 1234');
  const [eventDate, setEventDate] = useState(activeEvent?.date || '2026-12-18');
  const [guestCount, setGuestCount] = useState<number>(activeEvent?.guestCount || 350);
  const [requirements, setRequirements] = useState(
    'We are planning an evening wedding celebration and would like to request availability and a customized quotation for our date.'
  );

  if (!inquiryTargetVendor) return null;

  const dict = TRANSLATIONS[language];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail || !customerPhone) return;

    submitBookingInquiry({
      eventId: selectedEventId,
      vendorId: inquiryTargetVendor.id,
      customerName,
      customerEmail,
      customerPhone,
      eventDate,
      guestCount: Number(guestCount),
      requirements
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div 
        role="dialog"
        aria-modal="true"
        aria-labelledby="inquiry-modal-title"
        className="bg-[#FAF8F4] w-full max-w-2xl rounded-lg shadow-2xl border border-[#E5DFD5] overflow-hidden my-auto max-h-[92vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5DFD5] bg-[#FFFFFF]">
          <div>
            <h2 id="inquiry-modal-title" className="font-editorial text-xl font-semibold text-[#242320]">
              {dict.requestQuoteTitle}
            </h2>
            <p className="text-xs text-[#77736C]">
              {language === 'ar' ? inquiryTargetVendor.nameAr : inquiryTargetVendor.name} · {formatEgp(inquiryTargetVendor.startingPriceEgp, language)} {dict.startingFrom}
            </p>
          </div>
          <button
            onClick={closeInquiryModal}
            className="p-2 text-[#77736C] hover:text-[#242320] transition-colors rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-5 flex-1">
          {/* Target Event Picker */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#242320] mb-1.5">
              {dict.selectEventForInquiry}
            </label>
            <select
              value={selectedEventId}
              onChange={(e) => setSelectedEventId(e.target.value)}
              className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
            >
              {events.map((ev) => (
                <option key={ev.id} value={ev.id}>
                  {language === 'ar' ? ev.titleAr : ev.title} ({ev.date})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#242320] mb-1">
                {dict.yourName}
              </label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#242320] mb-1">
                {dict.yourPhone}
              </label>
              <input
                type="text"
                required
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#242320] mb-1">
              {dict.yourEmail}
            </label>
            <input
              type="email"
              required
              value={customerEmail}
              onChange={(e) => setCustomerEmail(e.target.value)}
              className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#242320] mb-1">
                {dict.eventDate}
              </label>
              <input
                type="date"
                required
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
                className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#242320] mb-1">
                {dict.guestCountInput}
              </label>
              <input
                type="number"
                min={10}
                max={2000}
                value={guestCount}
                onChange={(e) => setGuestCount(Number(e.target.value))}
                className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#242320] mb-1">
              {dict.specialRequirements}
            </label>
            <textarea
              rows={3}
              value={requirements}
              onChange={(e) => setRequirements(e.target.value)}
              className="w-full bg-[#FFFFFF] border border-[#E5DFD5] rounded px-3 py-2 text-sm text-[#242320] focus:outline-none focus:border-[#B79A66]"
            />
          </div>

          {/* Demo disclaimer banner */}
          <div className="p-3 bg-[#FAF8F4] border border-[#E5DFD5] rounded text-xs text-[#77736C] flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-[#B79A66] shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              {dict.inquiryDisclaimer}
            </p>
          </div>

          {/* Submit Action */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={closeInquiryModal}
              className="px-4 py-2 text-xs font-medium border border-[#E5DFD5] rounded hover:border-[#242320] transition-colors"
            >
              {language === 'ar' ? 'إلغاء' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded flex items-center gap-2 shadow-sm"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{dict.submitInquiryBtn}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
