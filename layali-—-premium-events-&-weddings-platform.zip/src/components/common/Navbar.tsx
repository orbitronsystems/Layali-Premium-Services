import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';
import { TAXONOMY_GROUPS } from '../../data/mockData';
import { Menu, X, ChevronDown, Sparkles, FolderHeart, Calendar, Compass, Grid } from 'lucide-react';
import { VendorCategory } from '../../types';

export const Navbar: React.FC = () => {
  const { 
    language, 
    currentView, 
    setCurrentView, 
    setIsEventWizardOpen, 
    role,
    feedViewMode,
    setFeedViewMode,
    setFeedCategoryFilter,
    likedPinIds,
    openCategoryPage,
    setIsOnboardingModalOpen
  } = useApp();
  const dict = TRANSLATIONS[language];
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [categoriesDropdownOpen, setCategoriesDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const totalSaved = likedPinIds.length;

  // Close categories dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setCategoriesDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleNav = (view: any) => {
    setCurrentView(view);
    setMobileMenuOpen(false);
    setCategoriesDropdownOpen(false);
  };

  const handleSelectCategory = (catId: VendorCategory) => {
    openCategoryPage(catId);
    setCategoriesDropdownOpen(false);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F4]/95 backdrop-blur-md border-b border-[#E5DFD5]">
      {/* Top Bar Contract (3 zones separated by gap-8) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand title, single line */}
        <button
          onClick={() => handleNav('home')}
          className="text-left rtl:text-right group flex items-baseline gap-2 whitespace-nowrap shrink-0"
        >
          <span className="font-editorial text-2xl sm:text-3xl tracking-[0.2em] font-semibold text-[#242320] group-hover:text-[#B79A66] transition-colors">
            {dict.brand}
          </span>
          <span className="text-[10px] tracking-widest text-[#77736C] uppercase font-sans hidden sm:inline">
            Cairo · Egypt
          </span>
        </button>

        {/* Zone 2: 4-5 single-line nav links */}
        <nav className="hidden md:flex items-center gap-6 lg:gap-7 text-sm font-medium text-[#77736C]">
          {/* 1. Discover */}
          <button
            onClick={() => {
              setFeedCategoryFilter('all');
              setFeedViewMode('pins');
              handleNav('home');
            }}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-[#242320] ${
              currentView === 'home' && feedViewMode === 'pins' ? 'text-[#242320] font-semibold' : ''
            }`}
          >
            {dict.navDiscover}
          </button>

          {/* 2. Categories Dropdown */}
          <div ref={dropdownRef} className="relative">
            <button
              onClick={() => setCategoriesDropdownOpen(!categoriesDropdownOpen)}
              className={`transition-colors whitespace-nowrap shrink-0 hover:text-[#242320] flex items-center gap-1.5 ${
                currentView === 'category' || categoriesDropdownOpen ? 'text-[#242320] font-semibold' : ''
              }`}
            >
              <span>{language === 'ar' ? 'التصنيفات والموردين' : 'Categories & Vendors'}</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${categoriesDropdownOpen ? 'rotate-180 text-[#B79A66]' : ''}`} />
            </button>

            {/* Categories Mega Menu */}
            {categoriesDropdownOpen && (
              <div className="absolute top-full left-0 rtl:left-auto rtl:right-0 mt-3 w-80 sm:w-96 bg-[#FAF8F4] border border-[#E5DFD5] rounded-2xl shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#E5DFD5]">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#B79A66] flex items-center gap-1.5">
                    <Grid className="w-3.5 h-3.5" />
                    <span>{language === 'ar' ? 'الأقسام المعتمدة في مصر' : 'Curated Vendor Specialties'}</span>
                  </span>
                </div>

                <div className="max-h-80 overflow-y-auto space-y-3 pr-1">
                  {TAXONOMY_GROUPS.map((group) => (
                    <div key={group.id} className="space-y-1">
                      <p className="text-[11px] font-bold uppercase tracking-wider text-[#77736C]">
                        {language === 'ar' ? group.titleAr : group.title}
                      </p>
                      <div className="grid grid-cols-1 gap-1 pl-2 rtl:pl-0 rtl:pr-2">
                        {group.categories.map((c) => (
                          <button
                            key={c.id}
                            onClick={() => handleSelectCategory(c.id)}
                            className="text-left rtl:text-right py-1 px-2 rounded-lg text-xs font-medium text-[#242320] hover:bg-white hover:text-[#B79A66] transition-colors truncate block w-full"
                          >
                            {language === 'ar' ? c.nameAr : c.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 3. Tailor Feed */}
          <button
            onClick={() => setIsOnboardingModalOpen(true)}
            className="transition-colors whitespace-nowrap shrink-0 hover:text-[#B79A66] flex items-center gap-1 text-[#77736C]"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#B79A66]" />
            <span>{language === 'ar' ? 'تخصيص' : 'Tailor Feed'}</span>
          </button>

          {/* 4. Saved Moodboards / Collections */}
          <button
            onClick={() => handleNav('collections')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-[#242320] flex items-center gap-1.5 ${
              currentView === 'collections' ? 'text-[#242320] font-semibold' : ''
            }`}
          >
            <FolderHeart className="w-4 h-4 text-[#B79A66]" />
            <span>{dict.navMoodboard}</span>
            {totalSaved > 0 && (
              <span className="w-4 h-4 rounded-full bg-[#B79A66] text-[#242320] text-[10px] font-bold flex items-center justify-center">
                {totalSaved}
              </span>
            )}
          </button>

          {/* 5. Workspace */}
          <button
            onClick={() => handleNav('workspace')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-[#242320] ${
              currentView === 'workspace' ? 'text-[#242320] font-semibold' : ''
            }`}
          >
            {dict.navWorkspace}
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => {
              if (role === 'customer') {
                setIsEventWizardOpen(true);
              } else {
                setCurrentView('workspace');
              }
            }}
            className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded-xl whitespace-nowrap shrink-0 shadow-sm"
          >
            {role === 'customer' ? dict.navStartPlanning : dict.navWorkspace}
          </button>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#242320] hover:text-[#B79A66]"
            aria-label="Toggle navigation"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[#E5DFD5] bg-[#FAF8F4] px-4 pt-3 pb-5 space-y-3">
          <button
            onClick={() => handleNav('home')}
            className="block w-full text-left rtl:text-right py-2 text-sm font-medium text-[#242320]"
          >
            {dict.navDiscover}
          </button>

          <button
            onClick={() => setIsOnboardingModalOpen(true)}
            className="block w-full text-left rtl:text-right py-2 text-sm font-medium text-[#B79A66]"
          >
            ✨ {language === 'ar' ? 'تخصيص الخلاصة لحدثك' : 'Tailor My Event Feed'}
          </button>

          <button
            onClick={() => handleNav('collections')}
            className="block w-full text-left rtl:text-right py-2 text-sm font-medium text-[#242320]"
          >
            {dict.navMoodboard} ({totalSaved})
          </button>

          <button
            onClick={() => handleNav('workspace')}
            className="block w-full text-left rtl:text-right py-2 text-sm font-medium text-[#242320]"
          >
            {dict.navWorkspace}
          </button>

          {/* Sponsor Quick Links */}
          <div className="pt-2 pb-1 border-t border-[#E5DFD5] space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#B79A66] px-1">
              Interactive Sponsors
            </span>
            <button
              onClick={() => handleNav('paypal_escrow')}
              className="block w-full text-left rtl:text-right py-1.5 px-2 rounded-lg text-xs font-semibold text-[#003087] hover:bg-blue-50"
            >
              💳 PayPal Smart Escrow & Payouts
            </button>
            <button
              onClick={() => handleNav('bryntum_timeline')}
              className="block w-full text-left rtl:text-right py-1.5 px-2 rounded-lg text-xs font-semibold text-[#B79A66] hover:bg-amber-50"
            >
              📅 Bryntum Day-of Run-of-Show
            </button>
            <button
              onClick={() => handleNav('zapier_automations')}
              className="block w-full text-left rtl:text-right py-1.5 px-2 rounded-lg text-xs font-semibold text-[#FF4F00] hover:bg-orange-50"
            >
              ⚡ Zapier Multi-Channel Automation
            </button>
          </div>

          <div className="pt-2 border-t border-[#E5DFD5]">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsEventWizardOpen(true);
              }}
              className="w-full py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#242320] text-white rounded-xl"
            >
              {dict.navStartPlanning}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
