import React from 'react';
import { useApp } from '../../context/AppContext';
import { CheckCircle2 } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toast } = useApp();

  if (!toast) return null;

  return (
    <div className="fixed bottom-6 right-6 rtl:right-auto rtl:left-6 z-50 animate-bounce-subtle pointer-events-none">
      <div className="bg-[#242320] text-[#FAF8F4] border border-[#B79A66]/40 px-4 py-3 rounded-lg shadow-xl flex items-center gap-3 text-xs max-w-md">
        <CheckCircle2 className="w-4 h-4 text-[#B79A66] shrink-0" />
        <span className="leading-snug">{toast.message}</span>
      </div>
    </div>
  );
};
