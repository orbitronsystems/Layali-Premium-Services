import React from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';

export const Footer: React.FC = () => {
  const { language, setCurrentView, setIsEventWizardOpen } = useApp();
  const dict = TRANSLATIONS[language];

  return (
    <footer className="bg-[#252522] text-[#F1EDE6] border-t border-[#3A3834] pt-16 pb-12 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-[#3A3834]">
          {/* Col 1: Wordmark & Narrative */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-baseline gap-2">
              <span className="font-editorial text-3xl tracking-[0.2em] font-semibold text-[#FAF8F4]">
                {dict.brand}
              </span>
              <span className="text-xs text-[#B79A66] tracking-wider uppercase font-sans">
                {dict.brandTag}
              </span>
            </div>
            <p className="text-sm text-[#A8A49C] max-w-md leading-relaxed">
              {dict.heroSubtitle}
            </p>
            <div className="flex items-center gap-4 text-xs text-[#77736C]">
              <span>Cairo</span>
              <span>·</span>
              <span>New Cairo</span>
              <span>·</span>
              <span>Sheikh Zayed</span>
              <span>·</span>
              <span>Giza</span>
              <span>·</span>
              <span>Alexandria</span>
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div>
            <h4 className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold mb-4">
              {language === 'ar' ? 'الاستكشاف' : 'Platform'}
            </h4>
            <ul className="space-y-2.5 text-sm text-[#A8A49C]">
              <li>
                <button
                  onClick={() => setCurrentView('discovery')}
                  className="hover:text-[#FAF8F4] transition-colors"
                >
                  {dict.navVenues}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('discovery')}
                  className="hover:text-[#FAF8F4] transition-colors"
                >
                  {dict.navServices}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('workspace')}
                  className="hover:text-[#FAF8F4] transition-colors"
                >
                  {dict.navWorkspace}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setIsEventWizardOpen(true)}
                  className="hover:text-[#FAF8F4] transition-colors"
                >
                  {dict.createEventBtn}
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Orbitron Systems & Guarantee */}
          <div>
            <h4 className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold mb-4">
              {language === 'ar' ? 'عن المنصة' : 'Orbitron Architecture'}
            </h4>
            <p className="text-xs text-[#8E8A82] leading-relaxed mb-3">
              {language === 'ar'
                ? 'تم تصميم منصة ليالي خصيصاً لأرقى مناسبات السوق المصري بمواصفات تقنية وتصميمية معيارية.'
                : 'Designed specifically for the luxury Egyptian wedding market by Orbitron Systems engineering.'}
            </p>
            <div className="text-xs text-[#B79A66]">
              {language === 'ar' ? 'العملة المعتمدة: الجنيه المصري (ج.م)' : 'Supported Currency: Egyptian Pound (EGP)'}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#77736C]">
          <p>
            © {new Date().getFullYear()} {dict.brand} · Orbitron Systems. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <span>Cairo, Egypt</span>
            <span>·</span>
            <span>Client Evaluation Prototype</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
