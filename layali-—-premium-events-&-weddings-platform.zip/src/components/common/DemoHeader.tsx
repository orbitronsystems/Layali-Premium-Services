import React from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import { TRANSLATIONS } from '../../utils/translations';
import { Globe, RotateCcw, ShieldCheck, Store, User } from 'lucide-react';

export const DemoHeader: React.FC = () => {
  const { role, setRole, language, setLanguage, resetDemoData } = useApp();
  const dict = TRANSLATIONS[language];

  const handleRoleChange = (newRole: UserRole) => {
    setRole(newRole);
  };

  return (
    <aside aria-label="Demo Bar" className="bg-[#252522] text-[#F1EDE6] text-xs border-b border-[#3A3834] px-4 sm:px-6 py-2">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-[10px] tracking-widest uppercase font-semibold text-[#B79A66]">
            {dict.demoBadge}
          </span>
          <span className="text-[#8E8A82] hidden md:inline">·</span>
          <span className="text-[#B5B0A6] hidden md:inline">
            {dict.demoNotice}
          </span>
        </div>

        <div className="flex items-center flex-wrap gap-2 sm:gap-4">
          {/* Role switcher segmented buttons */}
          <div className="flex items-center bg-[#1A1A18] rounded border border-[#3A3834] p-0.5">
            <button
              onClick={() => handleRoleChange('customer')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                role === 'customer'
                  ? 'bg-[#B79A66] text-[#242320] font-medium'
                  : 'text-[#B5B0A6] hover:text-[#FAF8F4]'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>{language === 'ar' ? 'العميل' : 'Customer'}</span>
            </button>
            <button
              onClick={() => handleRoleChange('vendor')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                role === 'vendor'
                  ? 'bg-[#B79A66] text-[#242320] font-medium'
                  : 'text-[#B5B0A6] hover:text-[#FAF8F4]'
              }`}
            >
              <Store className="w-3.5 h-3.5" />
              <span>{language === 'ar' ? 'المورد (قصر النيل)' : 'Vendor Portal'}</span>
            </button>
            <button
              onClick={() => handleRoleChange('admin')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                role === 'admin'
                  ? 'bg-[#B79A66] text-[#242320] font-medium'
                  : 'text-[#B5B0A6] hover:text-[#FAF8F4]'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{language === 'ar' ? 'الإدارة' : 'Admin'}</span>
            </button>
          </div>

          {/* Language Switcher */}
          <div className="flex items-center border border-[#3A3834] rounded px-1.5 py-0.5 bg-[#1A1A18]">
            <Globe className="w-3.5 h-3.5 text-[#B79A66] mr-1 ml-1" />
            <button
              onClick={() => setLanguage('en')}
              className={`px-1.5 py-0.5 rounded text-[11px] transition-colors ${
                language === 'en'
                  ? 'text-[#B79A66] font-semibold'
                  : 'text-[#8E8A82] hover:text-[#FAF8F4]'
              }`}
            >
              EN
            </button>
            <span className="text-[#3A3834]">|</span>
            <button
              onClick={() => setLanguage('ar')}
              className={`px-1.5 py-0.5 rounded text-[11px] transition-colors ${
                language === 'ar'
                  ? 'text-[#B79A66] font-semibold'
                  : 'text-[#8E8A82] hover:text-[#FAF8F4]'
              }`}
            >
              العربية
            </button>
          </div>

          {/* Reset Demo State button */}
          <button
            onClick={resetDemoData}
            title={dict.resetData}
            className="flex items-center gap-1 text-[#8E8A82] hover:text-[#FAF8F4] px-2 py-1 rounded transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            <span className="hidden sm:inline">{language === 'ar' ? 'إعادة ضبط' : 'Reset'}</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
