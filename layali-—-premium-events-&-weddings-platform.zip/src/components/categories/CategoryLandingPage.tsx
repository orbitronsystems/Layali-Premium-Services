import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { VendorCategory, PinItem, Vendor } from '../../types';
import { TRANSLATIONS, formatEgp, getCategoryLabel } from '../../utils/translations';
import { TAXONOMY_GROUPS } from '../../data/mockData';
import { 
  ArrowLeft, 
  Sparkles, 
  Phone, 
  MessageCircle, 
  Mail, 
  MapPin, 
  Star, 
  CheckCircle2, 
  Heart, 
  ArrowRight,
  ShieldCheck,
  FolderPlus
} from 'lucide-react';

export const CategoryLandingPage: React.FC = () => {
  const { 
    activeCategoryPage, 
    setCurrentView, 
    pins, 
    vendors, 
    likedPinIds, 
    toggleLikePin, 
    setSelectedPinId, 
    setSelectedVendorId, 
    openInquiryModal,
    openSaveToCollectionModal,
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];

  // Fallback to venues if somehow null
  const currentCategory: VendorCategory = activeCategoryPage || 'venues';

  // Find parent taxonomy group
  const parentGroup = useMemo(() => {
    return TAXONOMY_GROUPS.find((group) =>
      group.categories.some((c) => c.id === currentCategory)
    );
  }, [currentCategory]);

  // Category vendors
  const categoryVendors = useMemo(() => {
    return vendors.filter((v) => v.status === 'active' && v.category === currentCategory);
  }, [vendors, currentCategory]);

  // Category pins
  const categoryPins = useMemo(() => {
    return pins.filter((p) => p.vendorCategory === currentCategory);
  }, [pins, currentCategory]);

  const catTitle = getCategoryLabel(currentCategory, language);

  return (
    <section className="py-8 bg-[#FAF8F4] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Breadcrumb & Editorial Header */}
        <div className="space-y-4 pb-6 border-b border-[#E5DFD5]">
          <button
            onClick={() => setCurrentView('home')}
            className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#77736C] hover:text-[#242320] transition-colors"
          >
            <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
            <span>{language === 'ar' ? 'العودة لجميع التصنيفات' : 'Back to Visual Discovery'}</span>
          </button>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              {parentGroup && (
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-[#B79A66]" />
                  <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold">
                    {language === 'ar' ? parentGroup.titleAr : parentGroup.title}
                  </span>
                </div>
              )}
              <h1 className="font-editorial text-3xl sm:text-5xl font-semibold text-[#242320]">
                {catTitle}
              </h1>
              <p className="text-sm text-[#77736C] max-w-2xl mt-2 leading-relaxed">
                {parentGroup 
                  ? (language === 'ar' ? parentGroup.descriptionAr : parentGroup.description)
                  : (language === 'ar' ? 'استكشف أرقى الموردين المعتمدين ومعارض أعمالهم في مصر.' : 'Browse certified Egyptian vendors and visual portfolio albums.')}
              </p>
            </div>

            {/* Quick stats badge */}
            <div className="flex items-center gap-4 text-xs font-semibold uppercase tracking-wider text-[#77736C] bg-white px-4 py-2.5 rounded-xl border border-[#E5DFD5] shrink-0">
              <span>{categoryVendors.length} {language === 'ar' ? 'مورد معتمد' : 'Verified Vendors'}</span>
              <span>·</span>
              <span>{categoryPins.length} {language === 'ar' ? 'عمل بصري' : 'Visual Works'}</span>
            </div>
          </div>
        </div>

        {/* SECTION 1: VERIFIED VENDORS DIRECTORY IN THIS CATEGORY */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-editorial text-2xl font-semibold text-[#242320]">
                {language === 'ar' ? `الموردون المعتمدون في ${catTitle}` : `Verified Vendors in ${catTitle}`}
              </h2>
              <p className="text-xs text-[#77736C] mt-0.5">
                {language === 'ar'
                  ? 'تواصل مباشرة عبر الهاتف أو الواتساب، أو اطلب عرض سعر رسمي.'
                  : 'Contact directly via phone dial, WhatsApp chat, or request an official quotation.'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categoryVendors.map((vendor) => (
              <div
                key={vendor.id}
                onClick={() => setSelectedVendorId(vendor.id)}
                className="bg-white rounded-2xl overflow-hidden border border-[#E5DFD5] hover:border-[#B79A66]/60 hover:shadow-xl transition-all duration-300 group cursor-pointer flex flex-col justify-between"
              >
                <div>
                  {/* Vendor Cover Image */}
                  <div className="relative h-48 bg-[#F1EDE6] overflow-hidden">
                    <img
                      src={vendor.coverImage}
                      alt={language === 'ar' ? vendor.nameAr : vendor.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 left-3 rtl:left-auto rtl:right-3 px-2.5 py-1 bg-white/90 backdrop-blur-md rounded-full text-[11px] font-semibold text-[#242320] flex items-center gap-1 shadow-sm">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#B79A66]" />
                      <span>{language === 'ar' ? 'معتمد' : 'Verified'}</span>
                    </div>

                    <div className="absolute bottom-3 right-3 rtl:right-auto rtl:left-3 px-2.5 py-1 bg-black/60 backdrop-blur-md rounded-full text-[11px] font-semibold text-white flex items-center gap-1">
                      <Star className="w-3 h-3 text-[#B79A66] fill-[#B79A66]" />
                      <span>{vendor.rating.toFixed(1)}</span>
                    </div>
                  </div>

                  {/* Vendor Details */}
                  <div className="p-5 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-editorial text-xl font-semibold text-[#242320] group-hover:text-[#B79A66] transition-colors">
                          {language === 'ar' ? vendor.nameAr : vendor.name}
                        </h3>
                        <p className="text-xs text-[#77736C] flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-[#B79A66]" />
                          <span>{vendor.neighborhood}, {vendor.city}</span>
                        </p>
                      </div>
                      <div className="text-right rtl:text-left">
                        <span className="text-[10px] text-[#77736C] uppercase block">{dict.startingFrom}</span>
                        <span className="text-sm font-bold text-[#242320]">{formatEgp(vendor.startingPriceEgp, language)}</span>
                      </div>
                    </div>

                    <p className="text-xs text-[#77736C] line-clamp-2 leading-relaxed">
                      {language === 'ar' ? vendor.descriptionAr : vendor.description}
                    </p>
                  </div>
                </div>

                {/* Direct Action Buttons (Phone, WhatsApp, Quote) */}
                <div className="p-4 bg-[#FAF8F4] border-t border-[#E5DFD5] flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {/* Dial Phone Button */}
                    <a
                      href={`tel:${vendor.phone}`}
                      onClick={(e) => e.stopPropagation()}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white border border-[#E5DFD5] text-[#242320] hover:border-[#242320] flex items-center gap-1.5 transition-colors"
                      title={dict.callVendor}
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">{vendor.phone}</span>
                    </a>

                    {/* WhatsApp Button */}
                    <a
                      href={`https://wa.me/${vendor.whatsapp}?text=${encodeURIComponent(`Hello ${vendor.name}, I found your profile on Layali and would like to inquire about availability and pricing.`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#25D366] text-white hover:bg-[#1EBE5D] flex items-center gap-1.5 transition-colors shadow-sm"
                      title={dict.whatsappVendor}
                    >
                      <MessageCircle className="w-3.5 h-3.5 fill-current" />
                      <span>WhatsApp</span>
                    </a>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      openInquiryModal(vendor);
                    }}
                    className="px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider bg-[#242320] text-white hover:bg-[#B79A66] rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    {dict.requestQuote}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SECTION 2: VISUAL INSPIRATION ALBUMS FOR THIS CATEGORY */}
        <div className="space-y-6 pt-6 border-t border-[#E5DFD5]">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-editorial text-2xl font-semibold text-[#242320]">
                {language === 'ar' ? `معرض الأفكار والأعمال في ${catTitle}` : `Inspiration & Portfolio Gallery: ${catTitle}`}
              </h2>
              <p className="text-xs text-[#77736C] mt-0.5">
                {language === 'ar'
                  ? 'اضغط على أي صورة لعرض تفاصيل المورد وحفظها في لوحاتك المفضلة.'
                  : 'Click on any visual to inspect vendor details, save to boards, or call directly.'}
              </p>
            </div>
          </div>

          <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-4 space-y-4">
            {categoryPins.map((pin) => {
              const isLiked = likedPinIds.includes(pin.id);

              return (
                <div
                  key={pin.id}
                  onClick={() => setSelectedPinId(pin.id)}
                  className="break-inside-avoid bg-white rounded-2xl overflow-hidden border border-[#E5DFD5] group cursor-pointer hover:shadow-lg transition-all relative"
                >
                  <div className="relative overflow-hidden bg-[#E5DFD5]">
                    <img
                      src={pin.imageUrl}
                      alt={language === 'ar' ? pin.titleAr : pin.title}
                      className="w-full h-auto object-cover group-hover:scale-102 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />

                    {/* Overlay Action Buttons */}
                    <div className="absolute top-3 right-3 rtl:right-auto rtl:left-3 flex items-center gap-1.5 z-10">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          openSaveToCollectionModal(pin);
                        }}
                        className="p-2 rounded-full bg-black/50 hover:bg-[#B79A66] text-white backdrop-blur-md transition-all shadow-md"
                        title={dict.saveToBoard}
                      >
                        <FolderPlus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleLikePin(pin.id);
                        }}
                        className={`p-2 rounded-full backdrop-blur-md transition-all shadow-md ${
                          isLiked
                            ? 'bg-[#B79A66] text-[#242320]'
                            : 'bg-black/50 text-white hover:bg-black/80'
                        }`}
                        title={isLiked ? dict.savedFavorite : dict.saveFavorite}
                      >
                        <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-current' : ''}`} />
                      </button>
                    </div>

                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                      <span className="text-white text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
                        <span>{language === 'ar' ? 'معاينة المورد' : 'View Vendor'}</span>
                        <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
                      </span>
                    </div>
                  </div>

                  <div className="p-4 space-y-2">
                    <p className="text-sm font-semibold text-[#242320] leading-snug group-hover:text-[#B79A66] transition-colors">
                      {language === 'ar' ? pin.titleAr : pin.title}
                    </p>
                    <div className="pt-2 border-t border-[#F1EDE6] flex items-center justify-between text-xs text-[#77736C]">
                      <span className="font-medium text-[#242320] truncate">
                        {language === 'ar' ? pin.vendorNameAr : pin.vendorName}
                      </span>
                      <span>{pin.vendorCity}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
