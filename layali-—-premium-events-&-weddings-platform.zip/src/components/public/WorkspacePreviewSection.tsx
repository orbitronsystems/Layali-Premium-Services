import React from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';
import { CheckCircle2, DollarSign, CalendarCheck2, ShieldCheck, ArrowRight } from 'lucide-react';

export const WorkspacePreviewSection: React.FC = () => {
  const { language, setCurrentView, setIsEventWizardOpen } = useApp();
  const dict = TRANSLATIONS[language];

  return (
    <section className="py-20 bg-[#F1EDE6] border-y border-[#E5DFD5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-5 space-y-6">
            <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block">
              {language === 'ar' ? 'الميزة التنافسية الحصرية' : 'The Connected Advantage'}
            </span>
            <h2 className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#242320] leading-tight">
              {language === 'ar'
                ? 'استكشاف وتخطيط متكامل في بيئة واحدة'
                : 'Discovery and Practical Planning. Seamlessly Unified.'}
            </h2>
            <p className="text-sm text-[#77736C] leading-relaxed">
              {language === 'ar'
                ? 'لا مزيد من الجداول المبعثرة والرسائل الضائعة. تربط منصة ليالي بين استكشاف القاعات والموردين في مصر وبين أدوات إدارة الميزانية، وتتبع المهام، وإرسال عروض الأسعار في مساحة عمل واحدة تفاعلية.'
                : 'Move beyond scattered spreadsheets and lost messages. Layali fuses luxury vendor discovery with intelligent EGP budget allocation, category checklists, and direct booking inquiry management in one coherent client workspace.'}
            </p>

            <div className="space-y-3.5 pt-2 text-xs">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-[#2E6B4F] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-[#242320] block">
                    {language === 'ar' ? 'تحديث فوري لالتزامات الميزانية' : 'Automated Financial Ledger'}
                  </span>
                  <span className="text-[#77736C]">
                    {language === 'ar' ? 'إعادة حساب تلقائية للمصروفات والمبالغ المتبقية بالجنيه المصري' : 'Live balance calculations when booking quotes are accepted or expenses added.'}
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CalendarCheck2 className="w-4 h-4 text-[#B79A66] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-[#242320] block">
                    {language === 'ar' ? 'قوائم مهام مخصصة لتقاليد الزفاف المصري' : 'Egyptian Wedding Milestones'}
                  </span>
                  <span className="text-[#77736C]">
                    {language === 'ar' ? 'متابعة مراحل حجز القاعة، اختيار الكوشة، بروفات الفستان، وتنسيق الزفة' : 'Structured categories covering ballroom deposits, Kosha design, couture fittings, and zaffah orchestration.'}
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <DollarSign className="w-4 h-4 text-[#B79A66] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-[#242320] block">
                    {language === 'ar' ? 'تتبع طلبات عروض الأسعار مباشرة' : 'Inquiry & Quotation Tracking'}
                  </span>
                  <span className="text-[#77736C]">
                    {language === 'ar' ? 'تواصل مع إدارات القاعات والموردين واستقبل عروض الأسعار الرسمية' : 'Manage inquiries from draft to vendor response and confirmed reservation.'}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-4 flex items-center gap-4">
              <button
                onClick={() => setCurrentView('workspace')}
                className="px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded shadow-sm flex items-center gap-2"
              >
                <span>{language === 'ar' ? 'فتح مساحة التخطيط' : 'Launch Event Workspace'}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </button>
            </div>
          </div>

          {/* Right Visual Mockup Card */}
          <div className="lg:col-span-7">
            <div className="bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] shadow-lg p-6 space-y-6">
              {/* Header inside mockup */}
              <div className="flex items-center justify-between pb-4 border-b border-[#F1EDE6]">
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#B79A66] font-semibold">
                    {language === 'ar' ? 'الحدث النشط' : 'Active Workspace'}
                  </span>
                  <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                    Nour & Tarek's Grand Nile Wedding
                  </h3>
                </div>
                <div className="text-right rtl:text-left text-xs">
                  <span className="font-semibold text-[#2E6B4F] block">Dec 18, 2026</span>
                  <span className="text-[#77736C]">Zamalek, Cairo</span>
                </div>
              </div>

              {/* Sample Metrics Strip */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-[#FAF8F4] rounded border border-[#E5DFD5]">
                  <span className="text-[11px] text-[#77736C] block">{dict.plannedBudget}</span>
                  <span className="font-semibold text-sm text-[#242320] tabular-nums">1,250,000 EGP</span>
                </div>
                <div className="p-3 bg-[#FAF8F4] rounded border border-[#E5DFD5]">
                  <span className="text-[11px] text-[#77736C] block">{dict.recordedExpenses}</span>
                  <span className="font-semibold text-sm text-[#B79A66] tabular-nums">705,000 EGP</span>
                </div>
                <div className="p-3 bg-[#FAF8F4] rounded border border-[#E5DFD5]">
                  <span className="text-[11px] text-[#77736C] block">{dict.remainingBudget}</span>
                  <span className="font-semibold text-sm text-[#2E6B4F] tabular-nums">545,000 EGP</span>
                </div>
              </div>

              {/* Mini task rows */}
              <div className="space-y-2">
                <span className="text-[11px] uppercase tracking-wider text-[#77736C] font-semibold block">
                  {language === 'ar' ? 'أحدث المهام قيد المتابعة' : 'Recent Planning Milestones'}
                </span>

                <div className="p-2.5 rounded bg-[#FAF8F4] border border-[#E5DFD5] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#2E6B4F]" />
                    <span className="line-through text-[#77736C]">
                      Palais du Nil — Nile Ballroom rental contract finalized
                    </span>
                  </div>
                  <span className="text-[10px] text-[#2E6B4F] font-medium">Done</span>
                </div>

                <div className="p-2.5 rounded bg-[#FFFFFF] border border-[#E5DFD5] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded border border-[#B79A66]" />
                    <span className="text-[#242320] font-medium">
                      Confirm 25-piece Symphonic Zaffah playlist & entrance cue
                    </span>
                  </div>
                  <span className="text-[10px] text-[#B79A66] font-medium">Due Nov 28</span>
                </div>
              </div>

              {/* Inquiry preview badge */}
              <div className="p-3 rounded bg-amber-50/60 border border-amber-200/60 flex items-center justify-between text-xs">
                <span className="text-amber-900 font-medium">
                  {language === 'ar' ? 'عرض سعر جديد تم استلامه من ميزون دي فلور للزهور' : 'Quotation received from Maison des Fleurs Scenography'}
                </span>
                <span className="font-semibold text-[#242320] tabular-nums">185,000 EGP</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
