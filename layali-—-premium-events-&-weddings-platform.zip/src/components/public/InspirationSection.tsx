import React from 'react';
import { useApp } from '../../context/AppContext';
import { TABLE_IMAGE, VENUE_IMAGE, BRIDAL_IMAGE } from '../../data/mockData';

export const InspirationSection: React.FC = () => {
  const { language, setCurrentView } = useApp();

  return (
    <section className="py-20 bg-[#FAF8F4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-3">
          <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block">
            {language === 'ar' ? 'إلهام وفنون التصميم' : 'Editorial Inspiration'}
          </span>
          <h2 className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#242320]">
            {language === 'ar' ? 'أناقة لا تنضب. تفاصيل خالدة.' : 'Timeless Aesthetics & Artistry'}
          </h2>
          <p className="text-sm text-[#77736C] leading-relaxed">
            {language === 'ar'
              ? 'مختارات بصرية تعكس الرقي والأصالة المصرية، من ثريات القصور العريقة وتنسيقات الزهور النادرة إلى تفاصيل الطرحة المطرزة يدوياً.'
              : 'Curated visual stories capturing modern Egyptian celebrations — from candlelit Nile palatial ballrooms to bespoke Arabic calligraphy stationery.'}
          </p>
        </div>

        {/* 3-Card Curated Editorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Card 1: Palatial Architecture */}
          <div 
            onClick={() => setCurrentView('discovery')}
            className="group cursor-pointer space-y-4"
          >
            <div className="aspect-[4/3] rounded-lg overflow-hidden bg-[#E5DFD5] border border-[#E5DFD5]">
              <img
                src={VENUE_IMAGE}
                alt="Palatial Ballroom Architecture"
                className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <span className="text-[11px] uppercase tracking-widest text-[#B79A66] font-semibold block mb-1">
                {language === 'ar' ? 'العمارة والتراث' : 'Grand Architecture'}
              </span>
              <h3 className="font-editorial text-xl font-semibold text-[#242320] group-hover:text-[#B79A66] transition-colors">
                {language === 'ar' ? 'قصور النيل والقاعات الملكية' : 'Nile Waterfront Palaces & Historic Ballrooms'}
              </h3>
              <p className="text-xs text-[#77736C] mt-1 leading-relaxed">
                {language === 'ar'
                  ? 'مساحات فسيحة تستوعب أرقى حفلات الزفاف مع إطلالات ساحرة على نيل القاهرة.'
                  : 'Imperial ceiling heights, crystal chandeliers, and majestic settings for iconic Egyptian galas.'}
              </p>
            </div>
          </div>

          {/* Card 2: Tablescape & Floral Art */}
          <div 
            onClick={() => setCurrentView('discovery')}
            className="group cursor-pointer space-y-4"
          >
            <div className="aspect-[4/3] rounded-lg overflow-hidden bg-[#E5DFD5] border border-[#E5DFD5]">
              <img
                src={TABLE_IMAGE}
                alt="Fine Botanical Tablescapes"
                className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <span className="text-[11px] uppercase tracking-widest text-[#B79A66] font-semibold block mb-1">
                {language === 'ar' ? 'فنون التنسيق' : 'Botanical Scenography'}
              </span>
              <h3 className="font-editorial text-xl font-semibold text-[#242320] group-hover:text-[#B79A66] transition-colors">
                {language === 'ar' ? 'طاولات الولائم والشموع الكلاسيكية' : 'Candlelit Banquet Tables & Organic Florals'}
              </h3>
              <p className="text-xs text-[#77736C] mt-1 leading-relaxed">
                {language === 'ar'
                  ? 'شموع نحاسية عتيقة، أدوات مائدة ذهبية، وممرات زهور بأزهار الحدائق الإنجليزية.'
                  : 'Champagne gold accents, textured linens, and imported garden roses curated for intimate warmth.'}
              </p>
            </div>
          </div>

          {/* Card 3: Bridal Flatlay & Stationery */}
          <div 
            onClick={() => setCurrentView('discovery')}
            className="group cursor-pointer space-y-4"
          >
            <div className="aspect-[4/3] rounded-lg overflow-hidden bg-[#E5DFD5] border border-[#E5DFD5]">
              <img
                src={BRIDAL_IMAGE}
                alt="Bridal Details & Calligraphy"
                className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <span className="text-[11px] uppercase tracking-widest text-[#B79A66] font-semibold block mb-1">
                {language === 'ar' ? 'تفاصيل العروس' : 'Bridal & Stationery'}
              </span>
              <h3 className="font-editorial text-xl font-semibold text-[#242320] group-hover:text-[#B79A66] transition-colors">
                {language === 'ar' ? 'الخط العربي واللؤلؤ والمجوهرات' : 'Arabic Calligraphy & Heirloom Jewels'}
              </h3>
              <p className="text-xs text-[#77736C] mt-1 leading-relaxed">
                {language === 'ar'
                  ? 'بطاقات دعوة مصنعة يدوياً بأختام الشمع وتطريزات فساتين الزفاف الراقية.'
                  : 'Custom wax seal invitations, heirloom natural pearls, and delicate silk ribbons.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
