import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';
import { HERO_IMAGE } from '../../data/mockData';
import { VendorCategory } from '../../types';
import { Search, MapPin, Sparkles, ArrowRight } from 'lucide-react';

interface HeroSectionProps {
  onSearchChange: (search: string, category: string, city: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onSearchChange }) => {
  const { language, setIsEventWizardOpen, setCurrentView } = useApp();
  const dict = TRANSLATIONS[language];

  const [query, setQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [selectedCity, setSelectedCity] = useState<string>('all');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchChange(query, selectedCat, selectedCity);
    setCurrentView('discovery');
    // scroll down smoothly to discovery section
    const el = document.getElementById('discovery-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const categories: { id: VendorCategory | 'all'; label: string }[] = [
    { id: 'all', label: dict.categoryAll },
    { id: 'lighting_fx', label: dict.catLighting },
    { id: 'venues', label: dict.catVenues },
    { id: 'wedding_planners', label: dict.catPlanners },
    { id: 'belly_dancers', label: dict.catBellyDancers },
    { id: 'hosting_ushers', label: dict.catHosting },
    { id: 'event_management', label: dict.catEventManagement },
    { id: 'photography', label: dict.catPhoto },
    { id: 'floral_decor', label: dict.catFloral },
    { id: 'catering', label: dict.catCatering }
  ];

  const cities = [
    { id: 'all', label: dict.cityAll },
    { id: 'Cairo', label: language === 'ar' ? 'القاهرة' : 'Cairo' },
    { id: 'New Cairo', label: language === 'ar' ? 'القاهرة الجديدة' : 'New Cairo' },
    { id: 'Sheikh Zayed', label: language === 'ar' ? 'الشيخ زايد' : 'Sheikh Zayed' },
    { id: 'Giza', label: language === 'ar' ? 'الجيزة' : 'Giza' },
    { id: 'Alexandria', label: language === 'ar' ? 'الإسكندرية' : 'Alexandria' }
  ];

  return (
    <section className="relative overflow-hidden bg-[#FAF8F4] pt-8 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Hero 2-column or Banner */}
        <div className="relative rounded-2xl overflow-hidden border border-[#E5DFD5] bg-[#252522] min-h-[540px] flex flex-col justify-end p-6 sm:p-12 lg:p-16 text-white shadow-xl">
          {/* Background High-Fidelity Editorial Image */}
          <img
            src={HERO_IMAGE}
            alt="Luxury Egyptian Wedding Celebration"
            className="absolute inset-0 w-full h-full object-cover object-center brightness-90 transform scale-100 transition-transform duration-1000"
            referrerPolicy="no-referrer"
          />

          {/* Measured Scrim for WCAG AA readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#252522] via-[#252522]/65 to-black/30" />

          {/* Hero Content */}
          <div className="relative z-10 max-w-3xl space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-black/40 backdrop-blur-md rounded border border-white/15 text-[11px] uppercase tracking-widest text-[#FAF8F4]">
              <Sparkles className="w-3.5 h-3.5 text-[#B79A66]" />
              <span>{dict.heroPretitle}</span>
            </div>

            <h1 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#FAF8F4] leading-[1.1] text-balance">
              {dict.heroTitle}
            </h1>

            <p className="text-base sm:text-lg text-[#F1EDE6]/90 font-light leading-relaxed max-w-2xl">
              {dict.heroSubtitle}
            </p>

            {/* Actions */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={() => setIsEventWizardOpen(true)}
                className="px-7 py-3 text-xs font-semibold uppercase tracking-wider text-[#242320] bg-[#B79A66] hover:bg-[#A38652] transition-colors rounded shadow-lg flex items-center gap-2 shrink-0"
              >
                <span>{dict.heroCtaPrimary}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </button>

              <button
                onClick={() => {
                  setCurrentView('discovery');
                  const el = document.getElementById('discovery-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/25 transition-colors rounded shrink-0"
              >
                {dict.heroCtaSecondary}
              </button>
            </div>
          </div>
        </div>

        {/* 4-Item Proof/Capability Strip below Hero */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4 py-4 px-6 bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] shadow-xs text-xs">
          <div className="space-y-1">
            <span className="text-[11px] uppercase tracking-widest text-[#77736C] block">
              {language === 'ar' ? 'قصور وفنادق تاريخية' : 'Venues & Palaces'}
            </span>
            <span className="font-semibold text-sm text-[#242320]">
              Zamalek · New Cairo · Zayed
            </span>
          </div>
          <div className="space-y-1">
            <span className="text-[11px] uppercase tracking-widest text-[#77736C] block">
              {language === 'ar' ? 'إدارة الميزانية بالجنيه' : 'Budget Control'}
            </span>
            <span className="font-semibold text-sm text-[#242320]">
              Real-time EGP Ledger
            </span>
          </div>
          <div className="space-y-1">
            <span className="text-[11px] uppercase tracking-widest text-[#77736C] block">
              {language === 'ar' ? 'طلبات عروض الأسعار' : 'Booking RFPs'}
            </span>
            <span className="font-semibold text-sm text-[#242320]">
              Unified Inquiries Workflow
            </span>
          </div>
          <div className="space-y-1">
            <span className="text-[11px] uppercase tracking-widest text-[#77736C] block">
              {language === 'ar' ? 'اللغات المعتمدة' : 'Bilingual Support'}
            </span>
            <span className="font-semibold text-sm text-[#242320]">
              English & Arabic (RTL)
            </span>
          </div>
        </div>

        {/* Interactive Search Bar */}
        <div className="mt-6 p-4 sm:p-5 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] shadow-sm">
          <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
            {/* Query */}
            <div className="sm:col-span-5 relative">
              <Search className="absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#77736C]" />
              <input
                type="text"
                placeholder={dict.searchPlaceholder}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-9 pr-3 rtl:pl-3 rtl:pr-9 py-2.5 text-xs bg-[#FAF8F4] border border-[#E5DFD5] rounded text-[#242320] focus:outline-none focus:border-[#B79A66]"
              />
            </div>

            {/* Category Select */}
            <div className="sm:col-span-3">
              <select
                value={selectedCat}
                onChange={(e) => setSelectedCat(e.target.value)}
                className="w-full px-3 py-2.5 text-xs bg-[#FAF8F4] border border-[#E5DFD5] rounded text-[#242320] focus:outline-none focus:border-[#B79A66]"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Location Select */}
            <div className="sm:col-span-2 relative">
              <MapPin className="absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#77736C]" />
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full pl-8 pr-2 rtl:pl-2 rtl:pr-8 py-2.5 text-xs bg-[#FAF8F4] border border-[#E5DFD5] rounded text-[#242320] focus:outline-none focus:border-[#B79A66]"
              >
                {cities.map((cityItem) => (
                  <option key={cityItem.id} value={cityItem.id}>
                    {cityItem.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Submit */}
            <div className="sm:col-span-2">
              <button
                type="submit"
                className="w-full py-2.5 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] transition-colors rounded-xl flex items-center justify-center gap-1.5 shadow-xs"
              >
                <span>{dict.searchButton}</span>
              </button>
            </div>
          </form>

          {/* Popular Event-Type Shortcuts (Section 5 of Master Build Prompt) */}
          <div className="mt-3 pt-3 border-t border-[#F1EDE6] flex items-center gap-2 overflow-x-auto scrollbar-none text-xs">
            <span className="text-[11px] uppercase tracking-wider font-semibold text-[#77736C] shrink-0">
              {language === 'ar' ? 'مناسبات شائعة:' : 'Popular Celebrations:'}
            </span>
            {[
              { label: 'Weddings', labelAr: 'حفلات الزفاف', type: 'wedding' },
              { label: 'Birthdays & Private', labelAr: 'أعياد الميلاد', type: 'birthday' },
              { label: 'Corporate Galas', labelAr: 'فعاليات الشركات', type: 'corporate_gala' },
              { label: 'Engagements', labelAr: 'حفلات الخطوبة', type: 'engagement' },
              { label: 'Graduations', labelAr: 'حفلات التخرج', type: 'graduation' },
            ].map((shortcut, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  onSearchChange(shortcut.label, 'all', 'all');
                  const el = document.getElementById('discovery-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-3 py-1 rounded-full bg-[#FAF8F4] hover:bg-[#242320] hover:text-white border border-[#E5DFD5] text-[#77736C] transition-colors whitespace-nowrap shrink-0 text-[11px] font-medium"
              >
                {language === 'ar' ? shortcut.labelAr : shortcut.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
