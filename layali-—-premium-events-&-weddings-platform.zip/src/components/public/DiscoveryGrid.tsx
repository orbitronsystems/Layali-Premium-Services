import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { VendorCategory, Vendor } from '../../types';
import { TRANSLATIONS, formatEgp, getCategoryLabel } from '../../utils/translations';
import { Heart, MapPin, Star, Filter, RotateCcw } from 'lucide-react';

interface DiscoveryGridProps {
  initialSearch?: string;
  initialCategory?: string;
  initialCity?: string;
}

export const DiscoveryGrid: React.FC<DiscoveryGridProps> = ({
  initialSearch = '',
  initialCategory = 'all',
  initialCity = 'all'
}) => {
  const { 
    vendors, 
    language, 
    setSelectedVendorId, 
    openInquiryModal, 
    activeEvent, 
    toggleSaveVendor 
  } = useApp();

  const dict = TRANSLATIONS[language];

  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [selectedCity, setSelectedCity] = useState<string>(initialCity);
  const [maxBudget, setMaxBudget] = useState<number>(600000);
  const [sortBy, setSortBy] = useState<'featured' | 'price_asc' | 'price_desc' | 'rating'>('featured');

  const categories: { id: VendorCategory | 'all'; label: string }[] = [
    { id: 'all', label: dict.categoryAll },
    { id: 'lighting_fx', label: dict.catLighting },
    { id: 'venues', label: dict.catVenues },
    { id: 'wedding_planners', label: dict.catPlanners },
    { id: 'belly_dancers', label: dict.catBellyDancers },
    { id: 'hosting_ushers', label: dict.catHosting },
    { id: 'event_management', label: dict.catEventManagement },
    { id: 'photography', label: dict.catPhoto },
    { id: 'floral_decor', label: dict.catFloral },
    { id: 'catering', label: dict.catCatering }
  ];

  const cities = [
    { id: 'all', label: dict.cityAll },
    { id: 'Cairo', label: language === 'ar' ? 'القاهرة' : 'Cairo' },
    { id: 'New Cairo', label: language === 'ar' ? 'القاهرة الجديدة' : 'New Cairo' },
    { id: 'Sheikh Zayed', label: language === 'ar' ? 'الشيخ زايد' : 'Sheikh Zayed' },
    { id: 'Giza', label: language === 'ar' ? 'الجيزة' : 'Giza' },
    { id: 'Alexandria', label: language === 'ar' ? 'الإسكندرية' : 'Alexandria' }
  ];

  // Filter & Sort active vendors (exclude rejected or draft if any)
  const filteredVendors = useMemo(() => {
    return vendors
      .filter((v) => v.status === 'active')
      .filter((v) => {
        // Category filter
        if (selectedCategory !== 'all' && v.category !== selectedCategory) return false;
        // City filter
        if (selectedCity !== 'all' && v.city !== selectedCity) return false;
        // Budget filter
        if (v.startingPriceEgp > maxBudget) return false;
        // Query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = v.name.toLowerCase().includes(q) || v.nameAr.includes(q);
          const matchDesc = v.description.toLowerCase().includes(q) || v.descriptionAr.includes(q);
          const matchNeigh = v.neighborhood.toLowerCase().includes(q) || v.neighborhoodAr.includes(q);
          if (!matchName && !matchDesc && !matchNeigh) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'featured') {
          return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
        }
        if (sortBy === 'price_asc') {
          return a.startingPriceEgp - b.startingPriceEgp;
        }
        if (sortBy === 'price_desc') {
          return b.startingPriceEgp - a.startingPriceEgp;
        }
        if (sortBy === 'rating') {
          return b.rating - a.rating;
        }
        return 0;
      });
  }, [vendors, selectedCategory, selectedCity, maxBudget, searchQuery, sortBy]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedCity('all');
    setMaxBudget(600000);
    setSortBy('featured');
  };

  return (
    <section id="discovery-section" className="py-12 bg-[#FAF8F4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-[#E5DFD5]">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block mb-1">
              {language === 'ar' ? 'دليل الخدمات والقاعات' : 'Curated Directory'}
            </span>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#242320]">
              {language === 'ar' ? 'اكتشف أفضل مقدمي الخدمات في مصر' : 'Discover Distinguished Event Artisans'}
            </h2>
          </div>

          <div className="flex items-center gap-3 text-xs text-[#77736C]">
            <span className="tabular-nums font-semibold text-[#242320]">
              {filteredVendors.length}
            </span>
            <span>{dict.resultsCount}</span>
          </div>
        </div>

        {/* Category Filter Tabs (Zero pill anti-slop: clean segmented control) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 scrollbar-none mb-6">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-2 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 border ${
                selectedCategory === cat.id
                  ? 'bg-[#242320] text-white border-[#242320]'
                  : 'bg-[#FFFFFF] text-[#77736C] border-[#E5DFD5] hover:border-[#242320] hover:text-[#242320]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Secondary Filter Toolbar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] mb-8 text-xs">
          {/* Location filter */}
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#77736C] mb-1">
              {dict.filterCity}
            </label>
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="w-full bg-[#FAF8F4] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
            >
              {cities.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>

          {/* Budget filter slider */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-[11px] font-semibold uppercase tracking-wider text-[#77736C]">
                {dict.filterBudget}
              </label>
              <span className="font-semibold text-[#B79A66] tabular-nums">
                {formatEgp(maxBudget, language)}
              </span>
            </div>
            <input
              type="range"
              min={30000}
              max={600000}
              step={20000}
              value={maxBudget}
              onChange={(e) => setMaxBudget(Number(e.target.value))}
              className="w-full accent-[#B79A66] cursor-pointer"
            />
          </div>

          {/* Sort By */}
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#77736C] mb-1">
              {dict.sortBy}
            </label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full bg-[#FAF8F4] border border-[#E5DFD5] rounded px-3 py-2 text-xs text-[#242320] focus:outline-none focus:border-[#B79A66]"
            >
              <option value="featured">{dict.sortFeatured}</option>
              <option value="price_asc">{dict.sortPriceAsc}</option>
              <option value="price_desc">{dict.sortPriceDesc}</option>
              <option value="rating">{dict.sortRating}</option>
            </select>
          </div>

          {/* Clear Filters */}
          <div className="flex items-end">
            <button
              onClick={handleResetFilters}
              className="w-full py-2 px-3 border border-[#E5DFD5] rounded text-xs text-[#77736C] hover:text-[#242320] hover:border-[#242320] flex items-center justify-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{dict.clearFilters}</span>
            </button>
          </div>
        </div>

        {/* Vendor Grid */}
        {filteredVendors.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredVendors.map((vendor) => {
              const isSaved = activeEvent?.savedVendorIds?.includes(vendor.id);
              return (
                <div
                  key={vendor.id}
                  className="bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] overflow-hidden group hover:shadow-md transition-shadow flex flex-col justify-between"
                >
                  {/* Card Image */}
                  <div>
                    <div className="relative aspect-[4/3] w-full bg-[#E5DFD5] overflow-hidden">
                      <img
                        src={vendor.coverImage}
                        alt={language === 'ar' ? vendor.nameAr : vendor.name}
                        className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Heart Save Button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleSaveVendor(vendor.id);
                        }}
                        aria-label={isSaved ? dict.savedFavorite : dict.saveFavorite}
                        className={`absolute top-3 right-3 rtl:right-auto rtl:left-3 p-2 rounded-full backdrop-blur-md transition-colors ${
                          isSaved
                            ? 'bg-[#242320] text-[#B79A66]'
                            : 'bg-white/80 text-[#242320] hover:bg-white'
                        }`}
                      >
                        <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                      </button>

                      {/* Quiet Starting Price Overlay */}
                      <div className="absolute bottom-3 left-3 rtl:left-auto rtl:right-3 bg-[#242320]/80 backdrop-blur-md text-white text-[11px] px-2.5 py-1 rounded">
                        {dict.startingFrom} {formatEgp(vendor.startingPriceEgp, language)}
                      </div>
                    </div>

                    {/* Card Content (Zero-Pill discipline: unboxed metadata with separators) */}
                    <div className="p-5 space-y-2.5">
                      <div className="flex items-center gap-2 text-xs text-[#77736C]">
                        <span>{getCategoryLabel(vendor.category, language)}</span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-[#B79A66]" />
                          {language === 'ar' ? vendor.cityAr : vendor.city}
                        </span>
                      </div>

                      <h3
                        onClick={() => setSelectedVendorId(vendor.id)}
                        className="font-editorial text-xl font-semibold text-[#242320] hover:text-[#B79A66] transition-colors cursor-pointer line-clamp-1"
                      >
                        {language === 'ar' ? vendor.nameAr : vendor.name}
                      </h3>

                      <p className="text-xs text-[#77736C] line-clamp-2 leading-relaxed">
                        {language === 'ar' ? vendor.descriptionAr : vendor.description}
                      </p>

                      <div className="pt-2 flex items-center justify-between text-xs border-t border-[#F1EDE6]">
                        <div className="flex items-center gap-1 font-semibold text-[#242320]">
                          <Star className="w-3.5 h-3.5 fill-[#B79A66] text-[#B79A66]" />
                          <span className="tabular-nums">{vendor.rating.toFixed(2)}</span>
                          <span className="text-[11px] text-[#77736C]">({vendor.reviewsCount})</span>
                        </div>

                        {vendor.capacity && (
                          <span className="text-[11px] text-[#77736C]">
                            {vendor.capacity}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Card Actions */}
                  <div className="p-5 pt-0 grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setSelectedVendorId(vendor.id)}
                      className="w-full py-2 text-xs font-medium border border-[#E5DFD5] hover:border-[#242320] rounded text-[#242320] transition-colors"
                    >
                      {dict.viewProfile}
                    </button>
                    <button
                      onClick={() => openInquiryModal(vendor)}
                      className="w-full py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] rounded transition-colors shadow-xs"
                    >
                      {dict.requestQuote}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-12 text-center bg-[#FFFFFF] rounded-lg border border-[#E5DFD5] space-y-3">
            <Filter className="w-8 h-8 text-[#77736C] mx-auto" />
            <p className="text-sm text-[#77736C]">{dict.emptyResults}</p>
            <button
              onClick={handleResetFilters}
              className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#242320] border border-[#242320] rounded hover:bg-[#242320] hover:text-white transition-colors"
            >
              {dict.clearFilters}
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
