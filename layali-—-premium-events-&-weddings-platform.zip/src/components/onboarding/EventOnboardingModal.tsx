import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { EventType, VendorCategory, OnboardingPreferences } from '../../types';
import { TRANSLATIONS } from '../../utils/translations';
import { 
  X, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  Check, 
  MapPin, 
  Calendar, 
  DollarSign, 
  Crown,
  Heart
} from 'lucide-react';

export const EventOnboardingModal: React.FC = () => {
  const { 
    isOnboardingModalOpen, 
    setIsOnboardingModalOpen, 
    saveOnboardingPreferences, 
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form selections
  const [selectedEventType, setSelectedEventType] = useState<EventType>('wedding');
  const [selectedCategories, setSelectedCategories] = useState<VendorCategory[]>([
    'venues', 
    'lighting_fx', 
    'belly_dancers', 
    'photography'
  ]);
  const [selectedCity, setSelectedCity] = useState<string>('New Cairo');
  const [selectedBudget, setSelectedBudget] = useState<string>('300k - 700k EGP');

  if (!isOnboardingModalOpen) return null;

  const eventTypes: { id: EventType; label: string; labelAr: string; desc: string; descAr: string }[] = [
    { 
      id: 'wedding', 
      label: 'Wedding Reception', 
      labelAr: 'حفل زفاف', 
      desc: 'Palaces, Nile ballrooms, Kosha staging & Zaffah', 
      descAr: 'قصور، قاعات النيل، كوشة الزفاف والزفة' 
    },
    { 
      id: 'engagement', 
      label: 'Engagement Party', 
      labelAr: 'حفل خطوبة', 
      desc: 'Intimate garden villas and chic hotel terraces', 
      descAr: 'فلل الحدائق وتراسات الفنادق الراقية' 
    },
    { 
      id: 'birthday', 
      label: 'Birthday & Private Party', 
      labelAr: 'عيد ميلاد أو حفلة خاصة', 
      desc: 'Themed décor, balloon art, and live DJ sets', 
      descAr: 'ديكورات مميزة، بالونات، ودي جي حي' 
    },
    { 
      id: 'corporate_gala', 
      label: 'Corporate Gala / Launch', 
      labelAr: 'مؤتمر أو حفل سنوي للشركات', 
      desc: 'High-end production, staging, LED, and VIP ushers', 
      descAr: 'إنتاج هندسي ضخم، شاشات ومضيفات مراسم' 
    },
    { 
      id: 'anniversary', 
      label: 'Anniversary Celebration', 
      labelAr: 'ذكرى سنوية خاصة', 
      desc: 'Romantic dining, candlelit styling, and music', 
      descAr: 'عشاء رومانسي، إضاءة الشموع وموسيقى حية' 
    }
  ];

  const categoriesList: { id: VendorCategory; label: string; labelAr: string }[] = [
    { id: 'venues', label: 'Venues & Palaces', labelAr: 'قاعات وقصور الأفراح' },
    { id: 'lighting_fx', label: 'Lighting & Stage FX', labelAr: 'هندسة الإضاءة والمؤثرات' },
    { id: 'belly_dancers', label: 'Belly Dancers & Zaffah', labelAr: 'الراقصات الشرقيات وفرق الزفة' },
    { id: 'wedding_planners', label: 'Wedding Planners', labelAr: 'منظمو حفلات الزفاف' },
    { id: 'hosting_ushers', label: 'VIP Hostesses & Ushers', labelAr: 'مضيفات كبار الشخصيات' },
    { id: 'event_management', label: 'Event Management', labelAr: 'إدارة الفعاليات الكبرى' },
    { id: 'photography', label: 'Fine-Art Photography', labelAr: 'التصوير الفوتوغرافي والسينمائي' },
    { id: 'floral_decor', label: 'Floral & Kosha Staging', labelAr: 'تصميم الكوشة والزهور' },
    { id: 'catering', label: 'Haute Catering & Cakes', labelAr: 'البوفيه المفتوح والحلويات' },
    { id: 'dj_sound', label: 'DJs & Live Performers', labelAr: 'الدي جي والعازفون الحيون' }
  ];

  const citiesList = [
    { id: 'New Cairo', label: 'New Cairo & 5th Settlement', labelAr: 'القاهرة الجديدة والتجمع الخامس' },
    { id: 'Sheikh Zayed', label: 'Sheikh Zayed & 6th of October', labelAr: 'الشيخ زايد و٦ أكتوبر' },
    { id: 'Cairo', label: 'Central Cairo & Zamalek (Nile-side)', labelAr: 'وسط القاهرة والزمالك (على النيل)' },
    { id: 'Giza', label: 'Giza & Pyramids Plateau', labelAr: 'الجيزة ومنطقة الأهرامات' },
    { id: 'Alexandria', label: 'Alexandria & North Coast', labelAr: 'الإسكندرية والساحل الشمالي' }
  ];

  const budgetsList = [
    { id: '< 100k EGP', label: 'Under 100,000 EGP', labelAr: 'أقل من ١٠٠,٠٠٠ ج.م' },
    { id: '100k - 300k EGP', label: '100,000 – 300,000 EGP', labelAr: '١٠٠,٠٠٠ – ٣٠٠,٠٠٠ ج.م' },
    { id: '300k - 700k EGP', label: '300,000 – 700,000 EGP', labelAr: '٣٠٠,٠٠٠ – ٧٠٠,٠٠٠ ج.م' },
    { id: '700k+ EGP', label: '700,000+ EGP (Luxury / Royal)', labelAr: '٧٠٠,٠٠٠+ ج.م (فاخر / ملكي)' }
  ];

  const toggleCategory = (catId: VendorCategory) => {
    setSelectedCategories((prev) =>
      prev.includes(catId) ? prev.filter((c) => c !== catId) : [...prev, catId]
    );
  };

  const handleFinish = () => {
    const prefs: OnboardingPreferences = {
      eventType: selectedEventType,
      categories: selectedCategories,
      city: selectedCity,
      budgetRange: selectedBudget,
      isActive: true
    };
    saveOnboardingPreferences(prefs);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div 
        className="bg-[#FAF8F4] w-full max-w-2xl rounded-3xl shadow-2xl border border-[#E5DFD5] overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Top Header */}
        <div className="p-6 border-b border-[#E5DFD5] bg-white flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4 text-[#B79A66]" />
              <span className="text-[11px] uppercase tracking-widest text-[#B79A66] font-semibold">
                {language === 'ar' ? 'تخصيص الخلاصة لحدثك' : 'Tailor Your Visual Feed'}
              </span>
            </div>
            <h2 className="font-editorial text-2xl font-semibold text-[#242320]">
              {dict.onboardingTitle}
            </h2>
          </div>
          <button
            onClick={() => setIsOnboardingModalOpen(false)}
            className="p-2 text-[#77736C] hover:text-[#242320] rounded-full hover:bg-[#FAF8F4]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Dots */}
        <div className="px-6 py-3 bg-[#F5F1EA] border-b border-[#E5DFD5] flex items-center justify-between">
          <div className="flex items-center gap-2">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  s === step
                    ? 'w-8 bg-[#B79A66]'
                    : s < step
                    ? 'w-4 bg-[#242320]'
                    : 'w-4 bg-[#D1C9BE]'
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-[#77736C] font-semibold uppercase tracking-wider">
            {language === 'ar' ? `خطوة ${step} من ٤` : `Step ${step} of 4`}
          </span>
        </div>

        {/* Body based on Step */}
        <div className="p-6 sm:p-8 max-h-[60vh] overflow-y-auto">
          {/* STEP 1: EVENT TYPE */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                  {dict.onboardingStep1Question}
                </h3>
                <p className="text-xs text-[#77736C] mt-1">
                  {language === 'ar'
                    ? 'سنقوم بترشيح الأفكار والموردين المتخصصين في هذا النوع من الاحتفالات.'
                    : 'We will calibrate your visual feed with ideas and specialists in this celebration style.'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                {eventTypes.map((et) => {
                  const isSelected = selectedEventType === et.id;
                  return (
                    <button
                      key={et.id}
                      onClick={() => setSelectedEventType(et.id)}
                      className={`p-4 rounded-2xl border text-left rtl:text-right transition-all flex flex-col justify-between ${
                        isSelected
                          ? 'bg-white border-[#B79A66] ring-2 ring-[#B79A66]/30 shadow-md'
                          : 'bg-white/60 border-[#E5DFD5] hover:border-[#242320] hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-sm text-[#242320]">
                          {language === 'ar' ? et.labelAr : et.label}
                        </span>
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-[#B79A66] text-[#242320] flex items-center justify-center shrink-0">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </div>
                        )}
                      </div>
                      <span className="text-xs text-[#77736C]">
                        {language === 'ar' ? et.descAr : et.desc}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 2: CATEGORY INTERESTS */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                  {dict.onboardingStep2Question}
                </h3>
                <p className="text-xs text-[#77736C] mt-1">
                  {language === 'ar'
                    ? 'اختر التخصصات التي تبحث عنها كأولوية (يمكنك اختيار أكثر من تخصص).'
                    : 'Select the specialties you are actively prioritizing (multiple allowed).'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                {categoriesList.map((cat) => {
                  const isChecked = selectedCategories.includes(cat.id);
                  return (
                    <button
                      key={cat.id}
                      onClick={() => toggleCategory(cat.id)}
                      className={`p-3.5 rounded-xl border text-left rtl:text-right transition-all flex items-center justify-between ${
                        isChecked
                          ? 'bg-white border-[#B79A66] ring-1 ring-[#B79A66]/40 shadow-sm'
                          : 'bg-white/60 border-[#E5DFD5] hover:border-[#242320]'
                      }`}
                    >
                      <span className="text-sm font-medium text-[#242320]">
                        {language === 'ar' ? cat.labelAr : cat.label}
                      </span>
                      <div
                        className={`w-5 h-5 rounded border flex items-center justify-center shrink-0 ${
                          isChecked
                            ? 'bg-[#242320] border-[#242320] text-white'
                            : 'border-[#D1C9BE] bg-white'
                        }`}
                      >
                        {isChecked && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 3: EGYPTIAN CITY / LOCATION */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                  {dict.onboardingStep3Question}
                </h3>
                <p className="text-xs text-[#77736C] mt-1">
                  {language === 'ar'
                    ? 'نحن نركز حالياً على أرقى المواقع في مصر والقاهرة الكبرى.'
                    : 'We currently cover prime event destinations across Greater Cairo and Egypt.'}
                </p>
              </div>

              <div className="space-y-2.5 pt-2">
                {citiesList.map((city) => {
                  const isSelected = selectedCity === city.id;
                  return (
                    <button
                      key={city.id}
                      onClick={() => setSelectedCity(city.id)}
                      className={`w-full p-4 rounded-xl border text-left rtl:text-right transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-white border-[#B79A66] ring-2 ring-[#B79A66]/30 shadow-sm'
                          : 'bg-white/60 border-[#E5DFD5] hover:border-[#242320]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <MapPin className={`w-4 h-4 ${isSelected ? 'text-[#B79A66]' : 'text-[#77736C]'}`} />
                        <span className="text-sm font-semibold text-[#242320]">
                          {language === 'ar' ? city.labelAr : city.label}
                        </span>
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-[#B79A66] text-[#242320] flex items-center justify-center shrink-0">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 4: BUDGET RANGE */}
          {step === 4 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                  {dict.onboardingStep4Question}
                </h3>
                <p className="text-xs text-[#77736C] mt-1">
                  {language === 'ar'
                    ? 'يساعدنا تقدير ميزانيتك على إبراز الموردين الذين يتناسبون مع متطلباتك.'
                    : 'Your estimated budget helps us highlight vendors that align with your requirements.'}
                </p>
              </div>

              <div className="space-y-2.5 pt-2">
                {budgetsList.map((bg) => {
                  const isSelected = selectedBudget === bg.id;
                  return (
                    <button
                      key={bg.id}
                      onClick={() => setSelectedBudget(bg.id)}
                      className={`w-full p-4 rounded-xl border text-left rtl:text-right transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-white border-[#B79A66] ring-2 ring-[#B79A66]/30 shadow-sm'
                          : 'bg-white/60 border-[#E5DFD5] hover:border-[#242320]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <DollarSign className={`w-4 h-4 ${isSelected ? 'text-[#B79A66]' : 'text-[#77736C]'}`} />
                        <span className="text-sm font-semibold text-[#242320]">
                          {language === 'ar' ? bg.labelAr : bg.label}
                        </span>
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-[#B79A66] text-[#242320] flex items-center justify-center shrink-0">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-6 bg-white border-t border-[#E5DFD5] flex items-center justify-between gap-4">
          {step > 1 ? (
            <button
              onClick={() => setStep((s) => (s - 1) as any)}
              className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#77736C] hover:text-[#242320] flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
              <span>{dict.onboardingBack}</span>
            </button>
          ) : (
            <button
              onClick={() => setIsOnboardingModalOpen(false)}
              className="text-xs text-[#77736C] hover:text-[#242320] transition-colors"
            >
              {dict.onboardingSkip}
            </button>
          )}

          {step < 4 ? (
            <button
              onClick={() => setStep((s) => (s + 1) as any)}
              className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#242320] text-white hover:bg-[#B79A66] rounded-xl flex items-center gap-2 transition-colors shadow-sm"
            >
              <span>{dict.onboardingNext}</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180" />
            </button>
          ) : (
            <button
              onClick={handleFinish}
              className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#B79A66] text-[#242320] hover:bg-[#242320] hover:text-white rounded-xl flex items-center gap-2 transition-colors shadow-md font-bold"
            >
              <Sparkles className="w-4 h-4" />
              <span>{dict.onboardingFinish}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
