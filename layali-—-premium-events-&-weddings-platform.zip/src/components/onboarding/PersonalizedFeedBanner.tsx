import React from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, getCategoryLabel } from '../../utils/translations';
import { Sparkles, SlidersHorizontal, RotateCcw, MapPin } from 'lucide-react';

export const PersonalizedFeedBanner: React.FC = () => {
  const { 
    onboarding, 
    clearOnboardingPreferences, 
    setIsOnboardingModalOpen, 
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];

  if (!onboarding || !onboarding.isActive) return null;

  const eventLabel = language === 'ar'
    ? (onboarding.eventType === 'wedding' ? 'حفل الزفاف' : onboarding.eventType === 'engagement' ? 'حفل الخطوبة' : 'حفلتك الخاصة')
    : (onboarding.eventType === 'wedding' ? 'Wedding Celebration' : onboarding.eventType === 'engagement' ? 'Engagement' : 'Special Event');

  return (
    <div className="bg-[#FAF8F4] border border-[#B79A66]/30 rounded-2xl p-4 sm:p-5 shadow-sm mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 animate-in fade-in">
      <div className="flex items-start sm:items-center gap-3.5">
        <div className="w-10 h-10 rounded-xl bg-[#B79A66]/15 border border-[#B79A66]/30 flex items-center justify-center shrink-0 text-[#B79A66]">
          <Sparkles className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#B79A66]">
              {language === 'ar' ? 'خلاصة مخصصة لحدثك' : 'Tailored Event Feed'}
            </span>
            <span className="text-xs text-[#77736C]">·</span>
            <span className="text-xs text-[#77736C] flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {onboarding.city}
            </span>
          </div>
          <p className="text-sm font-medium text-[#242320] mt-0.5">
            {dict.tailoredFeedActive} <strong className="font-semibold text-[#242320]">{eventLabel}</strong>
            {onboarding.categories.length > 0 && (
              <span className="text-[#77736C] font-normal">
                {' '}({onboarding.categories.slice(0, 3).map((c) => getCategoryLabel(c, language)).join(', ')}
                {onboarding.categories.length > 3 ? '...' : ''})
              </span>
            )}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0 self-end md:self-auto">
        <button
          onClick={() => setIsOnboardingModalOpen(true)}
          className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-white border border-[#E5DFD5] text-[#242320] hover:border-[#B79A66] hover:text-[#B79A66] transition-colors flex items-center gap-1.5"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>{dict.changePreferences}</span>
        </button>
        <button
          onClick={clearOnboardingPreferences}
          className="px-3.5 py-1.5 text-xs font-semibold rounded-lg text-[#77736C] hover:text-[#242320] transition-colors flex items-center gap-1.5"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{dict.resetTailoredFeed}</span>
        </button>
      </div>
    </div>
  );
};
