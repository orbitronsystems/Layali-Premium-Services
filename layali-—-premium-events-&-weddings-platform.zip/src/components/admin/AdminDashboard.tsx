import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, formatEgp, getCategoryLabel } from '../../utils/translations';
import { 
  ShieldCheck, 
  Users, 
  Calendar, 
  Store, 
  Clock, 
  TrendingUp, 
  Check, 
  X, 
  Filter, 
  Search,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { 
    vendors, 
    inquiries, 
    events, 
    adminApproveVendor, 
    adminRejectVendor, 
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];
  const [activeAdminTab, setActiveAdminTab] = useState<'kpi' | 'vendors' | 'inquiries' | 'categories'>('kpi');
  const [vendorSearch, setVendorSearch] = useState('');

  // Pending vendors queue
  const pendingVendors = vendors.filter((v) => v.status === 'pending_approval');
  const approvedVendors = vendors.filter((v) => v.status === 'active');

  const filteredApprovedVendors = approvedVendors.filter((v) => {
    if (!vendorSearch.trim()) return true;
    const q = vendorSearch.toLowerCase();
    return v.name.toLowerCase().includes(q) || v.nameAr.includes(q) || v.city.toLowerCase().includes(q);
  });

  return (
    <div className="py-8 bg-[#FAF8F4] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Admin Header */}
        <div className="p-6 bg-[#252522] text-white rounded-xl border border-[#3A3834] flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-md">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#B79A66] font-semibold">
              <ShieldCheck className="w-4 h-4" />
              <span>{dict.adminPortalTitle}</span>
            </div>
            <h2 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#FAF8F4]">
              {language === 'ar' ? 'التحكم التشغيلي ومراقبة السوق' : 'Platform Oversight & Operations'}
            </h2>
            <p className="text-xs text-[#B5B0A6]">
              {dict.adminSubtitle} · {language === 'ar' ? 'بيانات توضيحية للتقييم' : 'Demonstration Operations Mode'}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="px-3 py-1 bg-[#1A1A18] text-[#B79A66] border border-[#3A3834] rounded text-xs font-semibold uppercase tracking-wider">
              {language === 'ar' ? 'السوق المصري' : 'Egyptian Market'}
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-[#E5DFD5]">
          <button
            onClick={() => setActiveAdminTab('kpi')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeAdminTab === 'kpi'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {language === 'ar' ? 'مؤشرات الأداء العامة' : 'KPI Overview & Metrics'}
          </button>
          <button
            onClick={() => setActiveAdminTab('vendors')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeAdminTab === 'vendors'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.pendingVendorsTitle} ({pendingVendors.length})
          </button>
          <button
            onClick={() => setActiveAdminTab('inquiries')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeAdminTab === 'inquiries'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {dict.allInquiriesTitle} ({inquiries.length})
          </button>
          <button
            onClick={() => setActiveAdminTab('categories')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border-b-2 ${
              activeAdminTab === 'categories'
                ? 'border-[#B79A66] text-[#242320]'
                : 'border-transparent text-[#77736C] hover:text-[#242320]'
            }`}
          >
            {language === 'ar' ? 'التصنيفات والمحافظات' : 'Categories & Regions'}
          </button>
        </div>

        {/* TAB 1: KPI OVERVIEW */}
        {activeAdminTab === 'kpi' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-1">
                <span className="text-xs uppercase tracking-widest text-[#77736C] font-semibold block">
                  {dict.kpiTotalEvents}
                </span>
                <div className="font-editorial text-3xl font-semibold text-[#242320] tabular-nums">
                  142
                </div>
                <span className="text-[11px] text-[#2E6B4F]">
                  +18% {language === 'ar' ? 'هذا الشهر' : 'vs last month'}
                </span>
              </div>

              <div className="p-5 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-1">
                <span className="text-xs uppercase tracking-widest text-[#77736C] font-semibold block">
                  {dict.kpiActiveCustomers}
                </span>
                <div className="font-editorial text-3xl font-semibold text-[#242320] tabular-nums">
                  320
                </div>
                <span className="text-[11px] text-[#77736C]">
                  {language === 'ar' ? 'مستخدمين مسجلين' : 'Active Egyptian couples'}
                </span>
              </div>

              <div className="p-5 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-1">
                <span className="text-xs uppercase tracking-widest text-[#77736C] font-semibold block">
                  {dict.kpiRegisteredVendors}
                </span>
                <div className="font-editorial text-3xl font-semibold text-[#242320] tabular-nums">
                  {approvedVendors.length + 76}
                </div>
                <span className="text-[11px] text-[#B79A66]">
                  {pendingVendors.length} {language === 'ar' ? 'بانتظار المراجعة' : 'awaiting verification'}
                </span>
              </div>

              <div className="p-5 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-1">
                <span className="text-xs uppercase tracking-widest text-[#77736C] font-semibold block">
                  {dict.kpiGrossVolume}
                </span>
                <div className="font-editorial text-3xl font-semibold text-[#B79A66] tabular-nums">
                  48.5M EGP
                </div>
                <span className="text-[11px] text-[#2E6B4F]">
                  {language === 'ar' ? 'حجم التعاقدات في مصر' : 'Estimated pipeline GMV'}
                </span>
              </div>
            </div>

            {/* Verification Alert Banner */}
            {pendingVendors.length > 0 && (
              <div className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-lg flex items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-2 text-amber-900">
                  <AlertCircle className="w-4 h-4 text-[#A66E1D] shrink-0" />
                  <span>
                    {language === 'ar'
                      ? `يوجد ${pendingVendors.length} طلب اعتماد مورد جديد يتطلب التدقيق والاعتماد.`
                      : `There are ${pendingVendors.length} pending vendor partner applications awaiting approval.`}
                  </span>
                </div>
                <button
                  onClick={() => setActiveAdminTab('vendors')}
                  className="px-3 py-1.5 bg-[#242320] text-white rounded text-xs font-semibold hover:bg-[#B79A66] transition-colors shrink-0"
                >
                  {language === 'ar' ? 'مراجعة الطلبات' : 'Review Queue'}
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: VENDORS APPROVAL QUEUE & DIRECTORY */}
        {activeAdminTab === 'vendors' && (
          <div className="space-y-6">
            {/* Pending Approvals Section */}
            <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#F1EDE6]">
                <div>
                  <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
                    {dict.pendingVendorsTitle}
                  </h3>
                  <span className="text-xs text-[#77736C]">
                    {language === 'ar' ? 'مراجعة التراخيص والسجل التجاري ومعايير الجودة الفاخرة' : 'Audit commercial registrations, portfolio quality, and luxury compliance'}
                  </span>
                </div>
                <span className="px-2.5 py-0.5 rounded text-xs bg-amber-50 text-amber-900 font-medium">
                  {pendingVendors.length} Pending
                </span>
              </div>

              {pendingVendors.length > 0 ? (
                <div className="space-y-3">
                  {pendingVendors.map((pv) => (
                    <div
                      key={pv.id}
                      className="p-4 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-sm text-[#242320]">
                            {language === 'ar' ? pv.nameAr : pv.name}
                          </h4>
                          <span className="text-[#77736C]">·</span>
                          <span className="text-[#B79A66] font-medium">
                            {getCategoryLabel(pv.category, language)}
                          </span>
                        </div>
                        <p className="text-[#77736C]">
                          {pv.neighborhood} · {pv.city} · {formatEgp(pv.startingPriceEgp, language)}
                        </p>
                        <p className="text-[#77736C] italic pt-1">
                          {language === 'ar' ? pv.descriptionAr : pv.description}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => adminRejectVendor(pv.id)}
                          className="px-3 py-1.5 border border-[#E5DFD5] hover:border-[#9E3B3B] text-[#9E3B3B] rounded font-medium flex items-center gap-1 transition-colors"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>{dict.rejectVendor}</span>
                        </button>
                        <button
                          onClick={() => adminApproveVendor(pv.id)}
                          className="px-4 py-1.5 bg-[#2E6B4F] hover:bg-[#255740] text-white rounded font-medium flex items-center gap-1 shadow-xs transition-colors"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>{dict.approveVendor}</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-6 text-center text-xs text-[#2E6B4F] flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {language === 'ar' ? 'تمت مراجعة واعتماد كافة طلبات الموردين.' : 'All vendor onboarding applications processed and approved.'}
                  </span>
                </div>
              )}
            </div>

            {/* Active Partners Directory */}
            <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1EDE6]">
                <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                  {language === 'ar' ? 'شبكة الموردين المعتمدين النشطين' : 'Active Verified Vendor Partners'}
                </h3>
                
                <div className="relative w-full sm:w-64">
                  <Search className="absolute left-2.5 rtl:left-auto rtl:right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#77736C]" />
                  <input
                    type="text"
                    placeholder="Search verified partners..."
                    value={vendorSearch}
                    onChange={(e) => setVendorSearch(e.target.value)}
                    className="w-full pl-8 pr-2 rtl:pl-2 rtl:pr-8 py-1.5 text-xs bg-[#FAF8F4] border border-[#E5DFD5] rounded text-[#242320] focus:outline-none"
                  />
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left rtl:text-right text-xs">
                  <thead>
                    <tr className="border-b border-[#E5DFD5] text-[#77736C] uppercase tracking-wider font-semibold">
                      <th className="py-2.5 px-3">Vendor Partner</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3">Location</th>
                      <th className="py-2.5 px-3">Starting Rate</th>
                      <th className="py-2.5 px-3">Rating</th>
                      <th className="py-2.5 px-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F1EDE6]">
                    {filteredApprovedVendors.map((v) => (
                      <tr key={v.id} className="hover:bg-[#FAF8F4] transition-colors">
                        <td className="py-2.5 px-3 font-semibold text-[#242320]">
                          {v.name}
                        </td>
                        <td className="py-2.5 px-3 text-[#77736C]">
                          {getCategoryLabel(v.category, language)}
                        </td>
                        <td className="py-2.5 px-3 text-[#77736C]">
                          {v.city} · {v.neighborhood}
                        </td>
                        <td className="py-2.5 px-3 font-semibold text-[#242320] tabular-nums">
                          {formatEgp(v.startingPriceEgp, language)}
                        </td>
                        <td className="py-2.5 px-3 tabular-nums">
                          ★ {v.rating > 0 ? v.rating.toFixed(2) : '5.00'}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="text-[10px] uppercase font-semibold text-[#2E6B4F] bg-emerald-50 px-2 py-0.5 rounded">
                            Verified
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: GLOBAL INQUIRIES LEDGER */}
        {activeAdminTab === 'inquiries' && (
          <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-4">
            <div className="pb-3 border-b border-[#F1EDE6]">
              <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
                {dict.allInquiriesTitle}
              </h3>
              <span className="text-xs text-[#77736C]">
                {language === 'ar' ? 'سجل تتبع كافة طلبات الحجز والأسعار المتبادلة بين العملاء والموردين' : 'Full real-time audit ledger of all inquiries, quotations, and booking transitions'}
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left rtl:text-right text-xs">
                <thead>
                  <tr className="border-b border-[#E5DFD5] text-[#77736C] uppercase tracking-wider font-semibold">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3">Vendor</th>
                    <th className="py-2.5 px-3">Event Date</th>
                    <th className="py-2.5 px-3">Guests</th>
                    <th className="py-2.5 px-3">Quoted Amount</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F1EDE6]">
                  {inquiries.map((inq) => (
                    <tr key={inq.id} className="hover:bg-[#FAF8F4] transition-colors">
                      <td className="py-2.5 px-3 text-[#77736C]">{inq.createdAt}</td>
                      <td className="py-2.5 px-3 font-medium text-[#242320]">{inq.customerName}</td>
                      <td className="py-2.5 px-3 text-[#242320]">{inq.vendorName}</td>
                      <td className="py-2.5 px-3 text-[#77736C]">{inq.eventDate}</td>
                      <td className="py-2.5 px-3 text-[#77736C]">{inq.guestCount}</td>
                      <td className="py-2.5 px-3 font-semibold text-[#242320] tabular-nums">
                        {inq.quotedPriceEgp ? formatEgp(inq.quotedPriceEgp, language) : 'Pending'}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${
                          inq.status === 'confirmed'
                            ? 'bg-emerald-50 text-[#2E6B4F]'
                            : inq.status === 'response_received'
                            ? 'bg-blue-50 text-blue-900'
                            : 'bg-amber-50 text-amber-900'
                        }`}>
                          {inq.status.replace('_', ' ').toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: CATEGORIES & REGIONS */}
        {activeAdminTab === 'categories' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-4">
              <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                {language === 'ar' ? 'التصنيفات المعتمدة' : 'Managed Service Categories'}
              </h3>
              <div className="space-y-2 text-xs">
                {[
                  { en: 'Venues & Historical Palaces', ar: 'القاعات والقصور التاريخية', count: '14 Active' },
                  { en: 'Fine Art Photography & Cinema', ar: 'التصوير السينمائي والفوتوغرافي', count: '18 Active' },
                  { en: 'Floral Scenography & Kosha', ar: 'الزهور وتصميم الكوشة', count: '12 Active' },
                  { en: 'Haute Gastronomy & Catering', ar: 'الضيافة والبوفيه الفاخر', count: '9 Active' },
                  { en: 'Bridal Couture & Groom Suits', ar: 'أزياء العرائس والبدلات', count: '15 Active' },
                  { en: 'Symphonic Zaffah & Live Music', ar: 'الزفة السيمفونية والفرق الحية', count: '8 Active' },
                  { en: 'Full Wedding Planning & Architecture', ar: 'تنسيق وإدارة الفعاليات', count: '8 Active' }
                ].map((item, idx) => (
                  <div key={idx} className="p-3 rounded bg-[#FAF8F4] border border-[#E5DFD5] flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-[#242320] block">
                        {language === 'ar' ? item.ar : item.en}
                      </span>
                    </div>
                    <span className="text-[11px] text-[#77736C]">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-6 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] space-y-4">
              <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                {language === 'ar' ? 'نطاق التغطية الجغرافية بمصر' : 'Active Egyptian Geographic Hubs'}
              </h3>
              <div className="space-y-2 text-xs">
                {[
                  { en: 'Cairo (Zamalek, Garden City, Heliopolis)', ar: 'القاهرة (الزمالك، جاردن سيتي، مصر الجديدة)', count: '42 Vendors' },
                  { en: 'New Cairo & Fifth Settlement', ar: 'القاهرة الجديدة والتجمع الخامس', count: '28 Vendors' },
                  { en: 'Sheikh Zayed & 6th of October', ar: 'الشيخ زايد والسادس من أكتوبر', count: '22 Vendors' },
                  { en: 'Giza & Pyramids Plateau Area', ar: 'الجيزة ومنطقة هضبة الأهرامات', count: '14 Vendors' },
                  { en: 'Alexandria & Mediterranean Coast', ar: 'الإسكندرية والساحل الشمالي', count: '16 Vendors' }
                ].map((item, idx) => (
                  <div key={idx} className="p-3 rounded bg-[#FAF8F4] border border-[#E5DFD5] flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-[#242320] block">
                        {language === 'ar' ? item.ar : item.en}
                      </span>
                    </div>
                    <span className="text-[11px] text-[#B79A66] font-semibold">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
