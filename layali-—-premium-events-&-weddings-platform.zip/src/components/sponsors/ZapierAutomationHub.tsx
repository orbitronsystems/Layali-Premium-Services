import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ZapierExecutionLog, ZapierZap } from '../../types';
import { 
  Zap, 
  ArrowRight, 
  Play, 
  CheckCircle2, 
  Clock, 
  Code2, 
  ExternalLink, 
  Sparkles, 
  ToggleLeft, 
  ToggleRight, 
  Activity, 
  Copy, 
  Check,
  Send,
  Calendar,
  MessageSquare,
  Folder,
  Hash,
  TrendingUp,
  Mail,
  CreditCard
} from 'lucide-react';

export const ZapierAutomationHub: React.FC = () => {
  const { 
    zaps, 
    zapierLogs, 
    toggleZap, 
    testRunZap, 
    activeZapTestingId, 
    language,
    showToast 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'workflows' | 'logs' | 'webhook_docs'>('workflows');
  const [inspectLog, setInspectLog] = useState<ZapierExecutionLog | null>(null);
  const [copiedWebhook, setCopiedWebhook] = useState(false);

  const getStepIcon = (iconName: string) => {
    switch (iconName) {
      case 'CreditCard': return <CreditCard className="w-4 h-4 text-[#003087]" />;
      case 'MessageSquare': return <MessageSquare className="w-4 h-4 text-[#25D366]" />;
      case 'Calendar': return <Calendar className="w-4 h-4 text-[#4285F4]" />;
      case 'Folder': return <Folder className="w-4 h-4 text-[#FBBC05]" />;
      case 'Send': return <Send className="w-4 h-4 text-[#B79A66]" />;
      case 'Hash': return <Hash className="w-4 h-4 text-[#4A154B]" />;
      case 'TrendingUp': return <TrendingUp className="w-4 h-4 text-[#FF7A59]" />;
      case 'Mail': return <Mail className="w-4 h-4 text-[#EA4335]" />;
      case 'Clock': return <Clock className="w-4 h-4 text-[#B79A66]" />;
      default: return <Zap className="w-4 h-4 text-[#FF4F00]" />;
    }
  };

  const handleCopyWebhook = () => {
    navigator.clipboard.writeText('https://hooks.zapier.com/hooks/catch/94a60da0/layali_events/');
    setCopiedWebhook(true);
    showToast(language === 'ar' ? 'تم نسخ رابط الويب هوك الخاص بزابيير' : 'Zapier Webhook Catch URL copied to clipboard');
    setTimeout(() => setCopiedWebhook(false), 2000);
  };

  return (
    <div className="py-8 bg-[#FAF8F4] min-h-screen space-y-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">

        {/* Header with Zapier Orange Theme */}
        <div className="p-6 sm:p-8 bg-gradient-to-r from-[#FF4F00] via-[#E04600] to-[#C93E00] rounded-2xl text-white shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-white text-[#FF4F00] flex items-center justify-center font-black text-lg shadow-sm">
                  _
                </div>
                <span className="text-xs uppercase font-extrabold tracking-widest px-2.5 py-0.5 rounded bg-white/20 text-white">
                  Zapier Automation Platform
                </span>
                <span className="text-xs text-white/70">·</span>
                <span className="text-xs text-white/90">Interactive Workflow Integration</span>
              </div>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold tracking-tight">
                {language === 'ar' ? 'منصة الربط والأتمتة الذكية مع زابيير' : 'Zapier Multi-Channel Automation Hub'}
              </h2>
              <p className="text-xs sm:text-sm text-white/90 max-w-2xl leading-relaxed">
                {language === 'ar'
                  ? 'ربط مباشر بين دفعات باي بال وجدول برينتوم مع واتساب وتويليو وتقويم جوجل وسلاك ونظام إدارة علاقات العملاء هاب سبوت.'
                  : 'Automating multi-step workflows connecting PayPal escrow payments, Bryntum schedules, WhatsApp notifications, Google Calendar, and HubSpot CRM.'}
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={handleCopyWebhook}
                className="px-4 py-2.5 bg-white text-[#FF4F00] font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center gap-1.5 hover:bg-white/90"
              >
                {copiedWebhook ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{language === 'ar' ? 'نسخ رابط الويب هوك' : 'Copy Catch Webhook'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 border-b border-[#E5DFD5] pb-2">
          <button
            onClick={() => setActiveTab('workflows')}
            className={`px-4 py-2.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'workflows'
                ? 'bg-[#FF4F00] text-white'
                : 'text-[#77736C] hover:text-[#242320]'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>{language === 'ar' ? 'المسارات النشطة (3 Zaps)' : 'Active Zaps (3)'}</span>
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`px-4 py-2.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'logs'
                ? 'bg-[#FF4F00] text-white'
                : 'text-[#77736C] hover:text-[#242320]'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>{language === 'ar' ? 'سجل تشغيل الويب هوك' : 'Webhook Execution Logs'}</span>
            <span className="px-1.5 py-0.5 rounded-full bg-white/20 text-[10px] font-bold">
              {zapierLogs.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('webhook_docs')}
            className={`px-4 py-2.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'webhook_docs'
                ? 'bg-[#FF4F00] text-white'
                : 'text-[#77736C] hover:text-[#242320]'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>{language === 'ar' ? 'مواصفات الـ Payload' : 'Payload Schema & Docs'}</span>
          </button>
        </div>

        {/* 1. Workflows Tab */}
        {activeTab === 'workflows' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-6">
              {zaps.map((zap) => {
                const isTesting = activeZapTestingId === zap.id;

                return (
                  <div
                    key={zap.id}
                    className="p-6 bg-white rounded-2xl border border-[#E5DFD5] shadow-xs space-y-6 hover:border-[#FF4F00] transition-colors"
                  >
                    {/* Zap Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#F1EDE6]">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded bg-[#FFF3ED] text-[#FF4F00] text-[10px] font-bold uppercase tracking-wider border border-[#FF4F00]/20 flex items-center gap-1">
                            <Zap className="w-3 h-3" />
                            Multi-Step Zap
                          </span>
                          <span className="text-xs text-[#77736C]">·</span>
                          <span className="text-xs text-[#77736C]">
                            {zap.totalRuns} {language === 'ar' ? 'مرات تنفيذ ناجحة' : 'Successful executions'}
                          </span>
                          {zap.lastRun && (
                            <>
                              <span className="text-xs text-[#77736C]">·</span>
                              <span className="text-xs text-[#2E6B4F] font-medium">{zap.lastRun}</span>
                            </>
                          )}
                        </div>
                        <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
                          {language === 'ar' ? zap.titleAr : zap.title}
                        </h3>
                        <p className="text-xs text-[#77736C] max-w-2xl leading-relaxed">
                          {language === 'ar' ? zap.descriptionAr : zap.description}
                        </p>
                      </div>

                      {/* Zap Toggle & Run Button */}
                      <div className="flex items-center gap-3 shrink-0">
                        <button
                          type="button"
                          onClick={() => toggleZap(zap.id)}
                          className="flex items-center gap-1 text-xs font-semibold text-[#77736C] hover:text-[#242320]"
                        >
                          {zap.enabled ? (
                            <ToggleRight className="w-7 h-7 text-[#FF4F00]" />
                          ) : (
                            <ToggleLeft className="w-7 h-7 text-stone-400" />
                          )}
                          <span className={zap.enabled ? 'text-[#FF4F00] font-bold' : 'text-stone-500'}>
                            {zap.enabled ? 'Active' : 'Paused'}
                          </span>
                        </button>

                        <button
                          type="button"
                          disabled={isTesting || !zap.enabled}
                          onClick={() => testRunZap(zap.id)}
                          className="px-4 py-2.5 bg-[#FF4F00] hover:bg-[#E04600] disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                        >
                          {isTesting ? (
                            <>
                              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                              <span>{language === 'ar' ? 'جاري الإرسال...' : 'Triggering...'}</span>
                            </>
                          ) : (
                            <>
                              <Play className="w-3.5 h-3.5" />
                              <span>{language === 'ar' ? 'اختبار المسار فوراً' : '⚡ Test Zap'}</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Step-by-Step Flow Visualizer */}
                    <div className="space-y-2">
                      <span className="text-[11px] uppercase tracking-wider font-semibold text-[#77736C]">
                        {language === 'ar' ? 'مراحل الأتمتة المتتابعة:' : 'Workflow Pipeline Execution:'}
                      </span>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                        {zap.steps.map((step, idx) => (
                          <div
                            key={step.id}
                            className="p-3.5 rounded-xl border border-[#E5DFD5] bg-[#FAF8F4] space-y-2 relative"
                          >
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="font-bold text-[#FF4F00]">
                                Step {idx + 1}
                              </span>
                              <div className="p-1 rounded bg-white shadow-2xs">
                                {getStepIcon(step.icon)}
                              </div>
                            </div>
                            <span className="text-xs font-semibold text-[#242320] block">
                              {step.appName}
                            </span>
                            <p className="text-[11px] text-[#77736C] leading-snug">
                              {language === 'ar' ? step.actionAr : step.action}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Sample Payload Accordion */}
                    <div className="p-4 bg-[#1E1E1E] rounded-xl text-stone-200 text-xs font-mono overflow-x-auto space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-stone-400 pb-1 border-b border-stone-800">
                        <span className="flex items-center gap-1.5 text-[#FF4F00] font-bold">
                          <Code2 className="w-3.5 h-3.5" />
                          Live Webhook Dispatch Payload (JSON)
                        </span>
                        <span className="text-stone-400">Trigger: {zap.triggerEvent}</span>
                      </div>
                      <pre className="text-[11px] leading-relaxed pt-2">
                        {JSON.stringify(zap.samplePayload, null, 2)}
                      </pre>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. Webhook Execution Logs Tab */}
        {activeTab === 'logs' && (
          <div className="bg-white rounded-2xl border border-[#E5DFD5] shadow-xs p-6 space-y-5">
            <div className="flex items-center justify-between pb-4 border-b border-[#F1EDE6]">
              <div>
                <span className="text-xs uppercase tracking-widest text-[#FF4F00] font-semibold block mb-0.5">
                  Live Dispatch Auditing
                </span>
                <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
                  Webhook Execution History
                </h3>
              </div>
              <span className="text-xs text-[#2E6B4F] font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" />
                100% Delivery Success Rate
              </span>
            </div>

            <div className="divide-y divide-[#E5DFD5]">
              {zapierLogs.map((log) => (
                <div key={log.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#E8F5E9] text-[#2E6B4F]">
                        200 OK
                      </span>
                      <span className="font-semibold text-xs text-[#242320]">
                        {log.zapTitle}
                      </span>
                    </div>
                    <p className="text-xs text-[#77736C]">
                      {log.triggerSummary}
                    </p>
                    <span className="text-[11px] text-[#77736C] font-mono block">
                      {log.timestamp}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => setInspectLog(log)}
                    className="px-3 py-1.5 rounded-lg border border-[#E5DFD5] hover:border-[#FF4F00] text-xs text-[#242320] font-medium transition-colors flex items-center gap-1.5 self-start sm:self-center shrink-0"
                  >
                    <Code2 className="w-3.5 h-3.5 text-[#FF4F00]" />
                    <span>Inspect Payload</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 3. Payload Schema & Docs Tab */}
        {activeTab === 'webhook_docs' && (
          <div className="bg-white rounded-2xl border border-[#E5DFD5] shadow-xs p-6 space-y-6 text-xs text-[#242320]">
            <div>
              <span className="text-xs uppercase tracking-widest text-[#FF4F00] font-semibold block mb-0.5">
                Developer Integration Guide
              </span>
              <h3 className="font-editorial text-2xl font-semibold">
                Zapier Webhook Specifications
              </h3>
              <p className="text-xs text-[#77736C] mt-1 leading-relaxed">
                Configure your Zapier Catch Hook to receive real-time webhooks from Layali whenever payments, quotes, or schedule changes take place.
              </p>
            </div>

            <div className="p-4 bg-[#FAF8F4] rounded-xl border border-[#E5DFD5] space-y-3">
              <span className="font-semibold text-xs block text-[#242320]">Catch Hook Endpoint:</span>
              <div className="flex items-center gap-2">
                <code className="p-2.5 bg-white border border-[#E5DFD5] rounded-lg font-mono text-xs text-[#FF4F00] flex-1">
                  https://hooks.zapier.com/hooks/catch/94a60da0/layali_events/
                </code>
                <button
                  onClick={handleCopyWebhook}
                  className="px-4 py-2.5 bg-[#242320] text-white rounded-lg font-semibold text-xs uppercase"
                >
                  {copiedWebhook ? 'Copied' : 'Copy'}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Supported Event Trigger Topics:</h4>
              <ul className="list-disc pl-5 space-y-1 text-[#77736C]">
                <li><code className="text-[#003087] font-mono">paypal.escrow.milestone_paid</code>: Dispatched when PayPal captures a milestone deposit.</li>
                <li><code className="text-[#B79A66] font-mono">layali.inquiry.created</code>: Dispatched when a client requests an official quote.</li>
                <li><code className="text-[#2E6B4F] font-mono">bryntum.timeline.finalized</code>: Dispatched when the master run-of-show is published.</li>
              </ul>
            </div>
          </div>
        )}

        {/* Modal: Inspect Log Payload */}
        {inspectLog && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-[#E5DFD5] p-6 space-y-4 text-xs text-[#242320]">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5DFD5]">
                <div className="flex items-center gap-2">
                  <Code2 className="w-5 h-5 text-[#FF4F00]" />
                  <span className="font-editorial text-lg font-semibold">
                    Zapier Webhook Payload Inspector
                  </span>
                </div>
                <button
                  onClick={() => setInspectLog(null)}
                  className="p-1 rounded-lg text-[#77736C] hover:text-[#242320]"
                >
                  ✕
                </button>
              </div>

              <div className="text-[11px] text-[#77736C]">
                <p><strong>Zap:</strong> {inspectLog.zapTitle}</p>
                <p><strong>Dispatched:</strong> {inspectLog.timestamp}</p>
                <p><strong>Status:</strong> <span className="text-[#2E6B4F] font-bold">200 OK DELIVERED</span></p>
              </div>

              <div className="p-4 bg-[#1E1E1E] text-stone-200 rounded-xl font-mono text-[11px] overflow-x-auto max-h-72">
                <pre>{inspectLog.payloadJson}</pre>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setInspectLog(null)}
                  className="w-full py-2.5 bg-[#242320] text-white rounded-xl font-semibold uppercase tracking-wider text-xs"
                >
                  Close Inspector
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
