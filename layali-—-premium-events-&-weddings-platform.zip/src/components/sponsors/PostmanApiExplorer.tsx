import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Send, 
  Copy, 
  Check, 
  Download, 
  Key, 
  Layers, 
  Terminal, 
  Globe, 
  ShieldCheck, 
  Sparkles, 
  ChevronRight,
  Eye,
  EyeOff,
  Code2
} from 'lucide-react';

interface RequestEndpoint {
  id: string;
  name: string;
  nameAr: string;
  method: 'POST' | 'GET';
  url: string;
  authType: 'Basic Auth' | 'Bearer Token';
  grantType?: string;
  description: string;
  descriptionAr: string;
  defaultBody?: string;
}

const ENDPOINTS: RequestEndpoint[] = [
  {
    id: 'oauth_token',
    name: '1. Get OAuth 2.0 Access Token',
    nameAr: '١. توليد رمز الدخول OAuth 2.0',
    method: 'POST',
    url: 'https://api-m.sandbox.paypal.com/v1/oauth2/token',
    authType: 'Basic Auth',
    grantType: 'client_credentials',
    description: 'Exchange Client ID and Secret for a 9-hour bearer token using Basic Auth & x-www-form-urlencoded.',
    descriptionAr: 'تبادل معرف العميل والمفتاح السري للحصول على رمز تفويض صالح لمدة 9 ساعات باستخدام Basic Auth.'
  },
  {
    id: 'create_order',
    name: '2. Create Escrow Order (v2)',
    nameAr: '٢. إنشاء طلب حجز بالضمان المالي (v2)',
    method: 'POST',
    url: 'https://api-m.sandbox.paypal.com/v2/checkout/orders',
    authType: 'Bearer Token',
    description: 'Initialize a transaction holding 20% down payment deposit for vendor booking.',
    descriptionAr: 'بدء معاملة وحجز 20% دفعة مقدمة لحجز المورد في الضمان المالي.',
    defaultBody: JSON.stringify({
      intent: 'CAPTURE',
      purchase_units: [
        {
          reference_id: 'LAYALI-CONTRACT-7821',
          description: 'Grand Ballroom Venue Reservation - 50% Milestone 1',
          amount: {
            currency_code: 'USD',
            value: '1520.00'
          }
        }
      ]
    }, null, 2)
  },
  {
    id: 'capture_order',
    name: '3. Capture Order Payment',
    nameAr: '٣. تأكيد وقبض الدفعة المحتجزة',
    method: 'POST',
    url: 'https://api-m.sandbox.paypal.com/v2/checkout/orders/5O190127TN364715T/capture',
    authType: 'Bearer Token',
    description: 'Capture funds into marketplace escrow once client signs digital contract.',
    descriptionAr: 'خصم الأموال وإيداعها في حساب الضمان بعد توقيع العقد الرقمي.',
    defaultBody: '{}'
  },
  {
    id: 'payouts',
    name: '4. Instant Vendor Payout',
    nameAr: '٤. تحويل فوري لحساب المورد',
    method: 'POST',
    url: 'https://api-m.sandbox.paypal.com/v1/payments/payouts',
    authType: 'Bearer Token',
    description: 'Disburse released milestone funds directly to vendor PayPal wallet (orbitronsystems@gmail.com).',
    descriptionAr: 'صرف مستحقات المورد مباشرة إلى حسابه في باي بال عند تسليم المرحلة.',
    defaultBody: JSON.stringify({
      sender_batch_header: {
        sender_batch_id: 'Batch_Milestone_Completion_94a6',
        email_subject: 'You received a payout from Layali Events!'
      },
      items: [
        {
          recipient_type: 'EMAIL',
          amount: {
            value: '760.00',
            currency: 'USD'
          },
          note: 'Milestone 2 - Sound & Light Rigging Completed',
          receiver: 'orbitronsystems@gmail.com'
        }
      ]
    }, null, 2)
  }
];

export const PostmanApiExplorer: React.FC = () => {
  const { language, showToast } = useApp();
  const [selectedEndpointId, setSelectedEndpointId] = useState<string>('oauth_token');
  const [activeTab, setActiveTab] = useState<'auth' | 'body' | 'headers' | 'curl'>('auth');
  const [isLoading, setIsLoading] = useState(false);
  const [responseStatus, setResponseStatus] = useState<number | null>(200);
  const [responseTime, setResponseTime] = useState<number>(242);
  const [showSecret, setShowSecret] = useState(false);
  const [copiedToken, setCopiedToken] = useState(false);

  // Form Fields
  const [clientId, setClientId] = useState('AeA1Qz8M9xK7_LayaliEgyptDemoClientId');
  const [clientSecret, setClientSecret] = useState('EDz90Yx4wK9p_LayaliSandboxSecretKey');
  const [bearerToken, setBearerToken] = useState('A21AAI_k9fG8J2Lm7Qp3Rt5Vx8Wz1Ny4B6C9d0EfG_LayaliToken');

  const selectedEndpoint = ENDPOINTS.find((e) => e.id === selectedEndpointId) || ENDPOINTS[0];

  const handleSend = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setResponseStatus(200);
      setResponseTime(Math.floor(Math.random() * 80) + 180);
      showToast(language === 'ar' ? 'تم استلام الاستجابة بنجاح 200 OK' : 'Postman Request Executed: 200 OK received');
    }, 450);
  };

  const getCurlSnippet = () => {
    if (selectedEndpoint.id === 'oauth_token') {
      return `curl -v -X POST "${selectedEndpoint.url}" \\
  -H "Accept: application/json" \\
  -H "Accept-Language: en_US" \\
  -H "Content-Type: application/x-www-form-urlencoded" \\
  -u "${clientId}:${clientSecret}" \\
  -d "grant_type=client_credentials"`;
    }
    return `curl -v -X POST "${selectedEndpoint.url}" \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer ${bearerToken}" \\
  -d '${selectedEndpoint.defaultBody || "{}"}'`;
  };

  const getMockResponse = () => {
    if (selectedEndpoint.id === 'oauth_token') {
      return {
        scope: "https://uri.paypal.com/services/invoicing https://uri.paypal.com/services/disputes/read-buyer https://uri.paypal.com/services/payments/realtimepayment https://uri.paypal.com/services/payments/payment/authcapture openid",
        access_token: bearerToken,
        token_type: "Bearer",
        app_id: "APP-80W284485P519543T",
        expires_in: 32400,
        supported_auth_methods: ["client_credentials"],
        nonce: "2026-11-05T17:34:21Z_orbitron_layali"
      };
    }
    if (selectedEndpoint.id === 'create_order') {
      return {
        id: "5O190127TN364715T",
        status: "CREATED",
        intent: "CAPTURE",
        purchase_units: [
          {
            reference_id: "LAYALI-CONTRACT-7821",
            amount: {
              currency_code: "USD",
              value: "1520.00"
            },
            payee: {
              email_address: "merchant-escrow@layali.events",
              merchant_id: "W9Y8Z7X6C5V4B"
            }
          }
        ],
        links: [
          {
            href: "https://www.sandbox.paypal.com/checkoutnow?token=5O190127TN364715T",
            rel: "approve",
            method: "GET"
          },
          {
            href: "https://api-m.sandbox.paypal.com/v2/checkout/orders/5O190127TN364715T",
            rel: "self",
            method: "GET"
          },
          {
            href: "https://api-m.sandbox.paypal.com/v2/checkout/orders/5O190127TN364715T/capture",
            rel: "capture",
            method: "POST"
          }
        ]
      };
    }
    if (selectedEndpoint.id === 'capture_order') {
      return {
        id: "5O190127TN364715T",
        status: "COMPLETED",
        payment_source: {
          paypal: {
            email_address: "client-wedding@gmail.com",
            account_id: "CLIENT98213",
            name: {
              given_name: "Sherif",
              surname: "El-Ghazali"
            }
          }
        },
        purchase_units: [
          {
            reference_id: "LAYALI-CONTRACT-7821",
            payments: {
              captures: [
                {
                  id: "3C679366HH252546W",
                  status: "COMPLETED",
                  amount: {
                    currency_code: "USD",
                    value: "1520.00"
                  },
                  final_capture: true,
                  seller_protection: {
                    status: "ELIGIBLE"
                  }
                }
              ]
            }
          }
        ]
      };
    }
    return {
      batch_header: {
        payout_batch_id: "PAYOUT_94A6_789123",
        batch_status: "SUCCESS",
        time_created: "2026-11-05T17:35:00Z",
        sender_batch_header: {
          sender_batch_id: "Batch_Milestone_Completion_94a6",
          email_subject: "You received a payout from Layali Events!"
        },
        amount: {
          currency: "USD",
          value: "760.00"
        }
      }
    };
  };

  const handleCopyToken = () => {
    navigator.clipboard.writeText(bearerToken);
    setCopiedToken(true);
    showToast(language === 'ar' ? 'تم نسخ رمز التفويض (Access Token)' : 'Bearer Access Token copied to clipboard');
    setTimeout(() => setCopiedToken(false), 2000);
  };

  const handleDownloadPostmanCollection = () => {
    const postmanJson = {
      info: {
        name: "Layali Events - PayPal Sandbox Suite (Postman Sponsor)",
        description: "Official Postman Collection for Layali Events Marketplace integrating PayPal Sandbox OAuth, Orders v2, and Payouts.",
        schema: "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
      },
      item: ENDPOINTS.map((endpoint) => ({
        name: endpoint.name,
        request: {
          method: endpoint.method,
          header: [
            { key: "Content-Type", value: endpoint.authType === 'Basic Auth' ? "application/x-www-form-urlencoded" : "application/json" },
            { key: "Accept", value: "application/json" }
          ],
          auth: endpoint.authType === 'Basic Auth' ? {
            type: "basic",
            basic: [
              { key: "username", value: "{{paypal_client_id}}" },
              { key: "password", value: "{{paypal_client_secret}}" }
            ]
          } : {
            type: "bearer",
            bearer: [
              { key: "token", value: "{{paypal_access_token}}" }
            ]
          },
          body: endpoint.authType === 'Basic Auth' ? {
            mode: "urlencoded",
            urlencoded: [
              { key: "grant_type", value: "client_credentials" }
            ]
          } : {
            mode: "raw",
            raw: endpoint.defaultBody || "{}"
          },
          url: {
            raw: endpoint.url,
            protocol: "https",
            host: ["api-m", "sandbox", "paypal", "com"],
            path: endpoint.url.replace("https://api-m.sandbox.paypal.com/", "").split("/")
          }
        }
      }))
    };

    const blob = new Blob([JSON.stringify(postmanJson, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Layali_PayPal_Postman_Collection.json';
    a.click();
    URL.revokeObjectURL(url);
    showToast(language === 'ar' ? 'تم تنزيل مجموعة بوستمان (Postman Collection JSON)' : 'Postman Collection JSON downloaded successfully');
  };

  return (
    <div className="py-8 bg-[#FAF8F4] min-h-screen space-y-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">

        {/* Header with Postman Orange & PayPal Blue Palette */}
        <div className="p-6 sm:p-8 bg-gradient-to-r from-[#FF6C37] via-[#E85B2A] to-[#242320] rounded-2xl text-white shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-white text-[#FF6C37] flex items-center justify-center font-black text-sm shadow-sm">
                  PM
                </div>
                <span className="text-xs uppercase font-extrabold tracking-widest px-2.5 py-0.5 rounded bg-white/20 text-white">
                  Postman API Explorer
                </span>
                <span className="text-xs text-white/70">·</span>
                <span className="text-xs text-white/90">PayPal Sandbox Endpoint Runner</span>
              </div>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold tracking-tight">
                {language === 'ar' ? 'منصة بوستمان لاختبار وتوثيق واجهات باي بال' : 'Postman API Console & PayPal Sandbox Tester'}
              </h2>
              <p className="text-xs sm:text-sm text-white/90 max-w-2xl leading-relaxed">
                {language === 'ar'
                  ? 'اختبار مباشر ومحاكاة فورية لطلب OAuth2 وتوليد رمز التفويض وإنشاء طلبات الضمان المالي والسحب الفوري للموردين.'
                  : 'Test the live OAuth 2.0 client credentials token flow, Orders v2 creation, and instant payout execution matching the exact Postman desktop workspace.'}
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={handleDownloadPostmanCollection}
                className="px-4 py-3 bg-white hover:bg-stone-100 text-[#242320] font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center gap-2"
              >
                <Download className="w-4 h-4 text-[#FF6C37]" />
                <span>{language === 'ar' ? 'تنزيل ملف Postman Collection' : 'Export Postman Collection'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Main Postman Workspace Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

          {/* Left Sidebar: Endpoints List (3 cols) */}
          <div className="lg:col-span-4 bg-white rounded-2xl border border-[#E5DFD5] p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#F1EDE6]">
              <span className="text-xs font-bold uppercase tracking-wider text-[#77736C] flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-[#FF6C37]" />
                {language === 'ar' ? 'مسارات الواجهة البرمجية' : 'API Collection'}
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded bg-orange-50 text-[#FF6C37] font-semibold">
                v2.1.0
              </span>
            </div>

            <div className="space-y-2">
              {ENDPOINTS.map((endpoint) => {
                const isSelected = endpoint.id === selectedEndpointId;
                return (
                  <button
                    key={endpoint.id}
                    onClick={() => {
                      setSelectedEndpointId(endpoint.id);
                      if (endpoint.authType === 'Basic Auth') {
                        setActiveTab('auth');
                      } else {
                        setActiveTab('body');
                      }
                    }}
                    className={`w-full text-left rtl:text-right p-3.5 rounded-xl transition-all border ${
                      isSelected
                        ? 'bg-[#FAF8F4] border-[#FF6C37] ring-1 ring-[#FF6C37]'
                        : 'border-[#E5DFD5] hover:border-stone-400 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-[#003087]">
                        {endpoint.method}
                      </span>
                      <span className="text-[10px] font-medium text-[#77736C]">
                        {endpoint.authType}
                      </span>
                    </div>
                    <div className="text-xs font-bold text-[#242320]">
                      {language === 'ar' ? endpoint.nameAr : endpoint.name}
                    </div>
                    <div className="text-[11px] text-[#77736C] line-clamp-1 mt-0.5">
                      {language === 'ar' ? endpoint.descriptionAr : endpoint.description}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Postman Sponsor Note */}
            <div className="pt-3 border-t border-[#F1EDE6] space-y-2 text-[11px] text-[#77736C]">
              <div className="flex items-center gap-1.5 text-[#242320] font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-[#FF6C37]" />
                <span>Postman Sponsor Integration</span>
              </div>
              <p className="leading-relaxed">
                {language === 'ar'
                  ? 'استخدام بوستمان لتأكيد تكامل واجهات الدفع واختبار سيناريوهات الأخطاء (Negative Testing) قبل إطلاق المنصة في مصر.'
                  : 'Automating contract testing, mock environments, and negative test responses for PayPal checkout in the Cairo event marketplace.'}
              </p>
            </div>
          </div>

          {/* Right Main Panel: Request Runner & Response Viewer (8 cols) */}
          <div className="lg:col-span-8 space-y-6">

            {/* Request Builder Card */}
            <div className="bg-white rounded-2xl border border-[#E5DFD5] shadow-xs overflow-hidden">
              
              {/* URL Address Bar */}
              <div className="p-4 bg-[#FAF8F4] border-b border-[#E5DFD5] flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-[#E5DFD5] shrink-0">
                  <span className="font-mono font-bold text-xs text-[#003087]">
                    {selectedEndpoint.method}
                  </span>
                </div>

                <div className="flex-1 flex items-center bg-white px-3 py-2 rounded-xl border border-[#E5DFD5] font-mono text-xs text-[#242320] overflow-x-auto">
                  <Globe className="w-3.5 h-3.5 text-[#77736C] shrink-0 mr-2 rtl:ml-2 rtl:mr-0" />
                  <span className="select-all">{selectedEndpoint.url}</span>
                </div>

                <button
                  onClick={handleSend}
                  disabled={isLoading}
                  className="px-5 py-2.5 bg-[#FF6C37] hover:bg-[#E85B2A] disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-sm flex items-center justify-center gap-2 shrink-0 cursor-pointer"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Send className="w-3.5 h-3.5" />
                  )}
                  <span>{isLoading ? 'Sending...' : 'Send'}</span>
                </button>
              </div>

              {/* Request Tabs */}
              <div className="border-b border-[#E5DFD5] px-4 flex gap-6 text-xs font-semibold bg-white">
                <button
                  onClick={() => setActiveTab('auth')}
                  className={`py-3 relative flex items-center gap-1.5 transition-colors ${
                    activeTab === 'auth' ? 'text-[#FF6C37]' : 'text-[#77736C] hover:text-[#242320]'
                  }`}
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>Authorization</span>
                  {activeTab === 'auth' && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF6C37]" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('body')}
                  className={`py-3 relative flex items-center gap-1.5 transition-colors ${
                    activeTab === 'body' ? 'text-[#FF6C37]' : 'text-[#77736C] hover:text-[#242320]'
                  }`}
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>Body</span>
                  {activeTab === 'body' && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF6C37]" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('headers')}
                  className={`py-3 relative flex items-center gap-1.5 transition-colors ${
                    activeTab === 'headers' ? 'text-[#FF6C37]' : 'text-[#77736C] hover:text-[#242320]'
                  }`}
                >
                  <span>Headers (3)</span>
                  {activeTab === 'headers' && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF6C37]" />
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('curl')}
                  className={`py-3 relative flex items-center gap-1.5 transition-colors ${
                    activeTab === 'curl' ? 'text-[#FF6C37]' : 'text-[#77736C] hover:text-[#242320]'
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>cURL Snippet</span>
                  {activeTab === 'curl' && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF6C37]" />
                  )}
                </button>
              </div>

              {/* Tab Contents */}
              <div className="p-5 text-xs text-[#242320] bg-white">
                
                {/* 1. Authorization Tab */}
                {activeTab === 'auth' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-[#F1EDE6]">
                      <span className="font-semibold text-[#77736C]">TYPE</span>
                      <span className="font-mono text-xs px-2.5 py-1 rounded bg-[#FAF8F4] border border-[#E5DFD5] font-bold text-[#003087]">
                        {selectedEndpoint.authType}
                      </span>
                    </div>

                    {selectedEndpoint.authType === 'Basic Auth' ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[11px] font-bold text-[#77736C] uppercase mb-1">
                            Username / Client ID
                          </label>
                          <input
                            type="text"
                            value={clientId}
                            onChange={(e) => setClientId(e.target.value)}
                            className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] font-mono text-xs focus:outline-none focus:border-[#FF6C37]"
                          />
                        </div>
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <label className="block text-[11px] font-bold text-[#77736C] uppercase">
                              Password / Client Secret
                            </label>
                            <button
                              type="button"
                              onClick={() => setShowSecret(!showSecret)}
                              className="text-[10px] text-[#77736C] hover:text-[#242320] flex items-center gap-1"
                            >
                              {showSecret ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                              <span>{showSecret ? 'Hide' : 'Show'}</span>
                            </button>
                          </div>
                          <input
                            type={showSecret ? 'text' : 'password'}
                            value={clientSecret}
                            onChange={(e) => setClientSecret(e.target.value)}
                            className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] font-mono text-xs focus:outline-none focus:border-[#FF6C37]"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <label className="block text-[11px] font-bold text-[#77736C] uppercase">
                          Bearer Access Token
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={bearerToken}
                            onChange={(e) => setBearerToken(e.target.value)}
                            className="flex-1 px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] font-mono text-xs focus:outline-none focus:border-[#FF6C37]"
                          />
                          <button
                            onClick={handleCopyToken}
                            className="px-3 py-2 bg-[#FAF8F4] hover:bg-stone-200 border border-[#E5DFD5] rounded-lg flex items-center gap-1.5"
                          >
                            {copiedToken ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5 text-[#77736C]" />}
                            <span className="font-semibold">{copiedToken ? 'Copied' : 'Copy'}</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 2. Body Tab */}
                {activeTab === 'body' && (
                  <div className="space-y-3">
                    {selectedEndpoint.id === 'oauth_token' ? (
                      <div>
                        <div className="flex items-center gap-3 mb-3 text-[11px] font-semibold text-[#77736C]">
                          <span className="px-2 py-0.5 rounded bg-orange-100 text-[#FF6C37] font-bold">x-www-form-urlencoded</span>
                        </div>
                        <table className="w-full text-left text-xs border border-[#E5DFD5] rounded-lg overflow-hidden">
                          <thead className="bg-[#FAF8F4] border-b border-[#E5DFD5] text-[#77736C] text-[11px]">
                            <tr>
                              <th className="p-2.5 font-bold">KEY</th>
                              <th className="p-2.5 font-bold">VALUE</th>
                              <th className="p-2.5 font-bold">DESCRIPTION</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td className="p-2.5 font-mono font-bold text-[#FF6C37]">grant_type</td>
                              <td className="p-2.5 font-mono">client_credentials</td>
                              <td className="p-2.5 text-[#77736C]">Standard OAuth2 client credentials grant</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[11px] font-semibold text-[#77736C]">JSON Payload</span>
                          <span className="text-[10px] text-[#77736C]">raw (application/json)</span>
                        </div>
                        <pre className="p-3 bg-[#1A1A18] text-[#F1EDE6] rounded-xl font-mono text-xs overflow-x-auto">
                          {selectedEndpoint.defaultBody}
                        </pre>
                      </div>
                    )}
                  </div>
                )}

                {/* 3. Headers Tab */}
                {activeTab === 'headers' && (
                  <div className="space-y-2">
                    <table className="w-full text-left text-xs border border-[#E5DFD5] rounded-lg overflow-hidden">
                      <thead className="bg-[#FAF8F4] border-b border-[#E5DFD5] text-[#77736C] text-[11px]">
                        <tr>
                          <th className="p-2.5 font-bold">KEY</th>
                          <th className="p-2.5 font-bold">VALUE</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-[#F1EDE6]">
                          <td className="p-2.5 font-mono font-semibold">Content-Type</td>
                          <td className="p-2.5 font-mono text-[#77736C]">
                            {selectedEndpoint.authType === 'Basic Auth' ? 'application/x-www-form-urlencoded' : 'application/json'}
                          </td>
                        </tr>
                        <tr className="border-b border-[#F1EDE6]">
                          <td className="p-2.5 font-mono font-semibold">Accept</td>
                          <td className="p-2.5 font-mono text-[#77736C]">application/json</td>
                        </tr>
                        <tr>
                          <td className="p-2.5 font-mono font-semibold">Accept-Language</td>
                          <td className="p-2.5 font-mono text-[#77736C]">en_US</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                )}

                {/* 4. cURL Snippet Tab */}
                {activeTab === 'curl' && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-[11px] font-semibold text-[#77736C]">
                        Equivalent Bash / Terminal Command
                      </span>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(getCurlSnippet());
                          showToast(language === 'ar' ? 'تم نسخ أمر cURL' : 'cURL command copied to clipboard');
                        }}
                        className="px-2.5 py-1 bg-[#FAF8F4] hover:bg-stone-200 border border-[#E5DFD5] rounded-lg text-[11px] font-semibold flex items-center gap-1"
                      >
                        <Copy className="w-3 h-3 text-[#77736C]" />
                        <span>Copy cURL</span>
                      </button>
                    </div>
                    <pre className="p-3 bg-[#1A1A18] text-[#F1EDE6] rounded-xl font-mono text-xs overflow-x-auto whitespace-pre-wrap">
                      {getCurlSnippet()}
                    </pre>
                  </div>
                )}

              </div>
            </div>

            {/* Response Viewer Card */}
            <div className="bg-white rounded-2xl border border-[#E5DFD5] shadow-xs overflow-hidden">
              <div className="p-4 bg-[#FAF8F4] border-b border-[#E5DFD5] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#77736C]">
                    Response
                  </span>
                  {responseStatus && (
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-green-100 text-green-700 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      {responseStatus} OK
                    </span>
                  )}
                  <span className="text-xs text-[#77736C] font-mono">
                    Time: {responseTime} ms
                  </span>
                  <span className="text-xs text-[#77736C] font-mono">
                    Size: 580 B
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {selectedEndpoint.id === 'oauth_token' && (
                    <button
                      onClick={handleCopyToken}
                      className="px-2.5 py-1 bg-white hover:bg-stone-100 border border-[#E5DFD5] rounded-lg text-xs font-semibold text-[#003087] flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Copy Access Token</span>
                    </button>
                  )}
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(JSON.stringify(getMockResponse(), null, 2));
                      showToast(language === 'ar' ? 'تم نسخ الاستجابة الكاملة' : 'Response JSON copied to clipboard');
                    }}
                    className="p-1.5 rounded-lg hover:bg-stone-200 text-[#77736C]"
                    title="Copy JSON"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="p-4 bg-[#141413]">
                <pre className="font-mono text-xs text-[#A8FF60] overflow-x-auto max-h-96 leading-relaxed">
                  {JSON.stringify(getMockResponse(), null, 2)}
                </pre>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
