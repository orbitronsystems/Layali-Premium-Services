import React from 'react';
import { useApp } from '../../context/AppContext';
import { Sparkles, Calendar, Zap, CreditCard, ChevronRight, Lock } from 'lucide-react';

export const SponsorsShowcaseBar: React.FC = () => {
  const { currentView, setCurrentView, language, openPayPalModal, vendors } = useApp();

  const handleOpenPayPalDemo = () => {
    if (vendors.length > 0) {
      openPayPalModal({
        vendor: vendors[0],
        quoteAmountEgp: 380000,
        depositAmountEgp: 76000
      });
    } else {
      setCurrentView('paypal_escrow');
    }
  };

  return (
    <div className="bg-[#1A1A18] text-[#F1EDE6] border-b border-[#33312C] text-xs py-2 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        
        {/* Left: Interactive Sponsors Badge */}
        <div className="flex items-center gap-2.5">
          <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#FFC439] bg-[#FFC439]/10 px-2.5 py-1 rounded-md border border-[#FFC439]/20">
            <Sparkles className="w-3.5 h-3.5 text-[#FFC439]" />
            {language === 'ar' ? 'الرعاة التفاعليين' : 'Interactive Sponsors'}
          </span>
          <span className="text-[#8E8A82] hidden sm:inline">·</span>
          <span className="text-[#B5B0A6] text-xs font-medium hidden sm:inline">
            {language === 'ar' 
              ? 'باي بال (الضمان والتسويات) · برينتوم (جدول اليوم) · زابيير (الأتمتة) · بوستمان (اختبار الواجهات)' 
              : 'PayPal Escrow · Bryntum Scheduler · Zapier Hub · Postman API Console'}
          </span>
        </div>

        {/* Right: Quick Launch Segmented Actions */}
        <div className="flex items-center flex-wrap gap-2">
          {/* 1. PayPal */}
          <button
            onClick={() => setCurrentView('paypal_escrow')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              currentView === 'paypal_escrow'
                ? 'bg-[#003087] text-white ring-1 ring-[#FFC439]'
                : 'bg-[#252522] text-[#B5B0A6] hover:text-white hover:bg-[#33312C]'
            }`}
          >
            <span className="text-[#FFC439] font-black italic">PP</span>
            <span>PayPal Escrow</span>
          </button>

          {/* 2. Bryntum */}
          <button
            onClick={() => setCurrentView('bryntum_timeline')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              currentView === 'bryntum_timeline'
                ? 'bg-[#B79A66] text-[#242320]'
                : 'bg-[#252522] text-[#B5B0A6] hover:text-white hover:bg-[#33312C]'
            }`}
          >
            <Calendar className="w-3.5 h-3.5 text-[#B79A66]" />
            <span>Bryntum Scheduler</span>
          </button>

          {/* 3. Zapier */}
          <button
            onClick={() => setCurrentView('zapier_automations')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              currentView === 'zapier_automations'
                ? 'bg-[#FF4F00] text-white'
                : 'bg-[#252522] text-[#B5B0A6] hover:text-white hover:bg-[#33312C]'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-[#FF4F00]" />
            <span>Zapier Hub</span>
          </button>

          {/* 4. Postman */}
          <button
            onClick={() => setCurrentView('postman_api')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              currentView === 'postman_api'
                ? 'bg-[#FF6C37] text-white'
                : 'bg-[#252522] text-[#B5B0A6] hover:text-white hover:bg-[#33312C]'
            }`}
          >
            <span className="font-extrabold text-[11px] text-[#FF6C37] bg-white px-1 py-0.2 rounded">PM</span>
            <span>Postman API</span>
          </button>
        </div>

      </div>
    </div>
  );
};
