import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BryntumScheduleItem, BryntumTrackId } from '../../types';
import { 
  Calendar, 
  Clock, 
  AlertTriangle, 
  Plus, 
  Trash2, 
  Edit3, 
  Download, 
  Share2, 
  Sparkles, 
  Layers, 
  CheckCircle2, 
  ChevronRight,
  Filter,
  Check
} from 'lucide-react';

interface TrackDefinition {
  id: BryntumTrackId;
  name: string;
  nameAr: string;
  icon: string;
  color: string;
  responsibleGroup: string;
}

const TRACKS: TrackDefinition[] = [
  { id: 'staging', name: 'Floral, Kosha & Staging', nameAr: 'الكوشة وهندسة الزهور والمسرح', icon: '🏛️', color: '#8E735B', responsibleGroup: 'Planners & Decorators' },
  { id: 'lighting_sound', name: 'Lighting & Sound Engineering', nameAr: 'هندسة الإضاءة والصوتيات', icon: '💡', color: '#3B6A9E', responsibleGroup: 'Production & FX Crews' },
  { id: 'photo_cinema', name: 'Photo, Video & Cinema Crews', nameAr: 'التصوير الفوتوغرافي والسينمائي', icon: '📸', color: '#7A8B7B', responsibleGroup: 'Visual Media Team' },
  { id: 'zaffa_entertainment', name: 'Zaffa, Performers & Live Shows', nameAr: 'الزفة المصرية والعروض الاستعراضية', icon: '💃', color: '#C47055', responsibleGroup: 'Entertainers & Dancers' },
  { id: 'catering_hospitality', name: 'Catering, Banquet & Cake', nameAr: 'الضيافة والبوفيه وتورتة الفرح', icon: '🍽️', color: '#657B6C', responsibleGroup: 'Hospitality & Chefs' }
];

// Timeline time slots from 12:00 to 02:00 (14 hours)
const TIME_HOURS = [
  '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', 
  '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00', '02:00'
];

export const BryntumRunOfShow: React.FC = () => {
  const { 
    bryntumSchedule, 
    addScheduleItem, 
    updateScheduleItem, 
    deleteScheduleItem, 
    resetBryntumPreset, 
    language,
    activeEvent,
    showToast
  } = useApp();

  const [activePreset, setActivePreset] = useState<'cairo_wedding' | 'gouna_beach' | 'corporate_gala'>('cairo_wedding');
  const [selectedItem, setSelectedItem] = useState<BryntumScheduleItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [filterTrack, setFilterTrack] = useState<string>('all');

  // New Block Form State
  const [newTitle, setNewTitle] = useState('');
  const [newTitleAr, setNewTitleAr] = useState('');
  const [newStartTime, setNewStartTime] = useState('18:00');
  const [newEndTime, setNewEndTime] = useState('19:30');
  const [newTrackId, setNewTrackId] = useState<BryntumTrackId>('staging');
  const [newVendorName, setNewVendorName] = useState('Palais du Nil Partner');
  const [newZone, setNewZone] = useState('Main Ballroom');
  const [newNotes, setNewNotes] = useState('');

  // Conflict Detection: check if any two items on the same track or zone overlap in time
  const detectConflicts = (items: BryntumScheduleItem[]) => {
    const conflicts: string[] = [];
    for (let i = 0; i < items.length; i++) {
      for (let j = i + 1; j < items.length; j++) {
        const a = items[i];
        const b = items[j];
        if (a.trackId === b.trackId || a.zone === b.zone) {
          // Check overlap
          if (a.startTime < b.endTime && b.startTime < a.endTime) {
            conflicts.push(a.id);
            conflicts.push(b.id);
          }
        }
      }
    }
    return Array.from(new Set(conflicts));
  };

  const conflictIds = detectConflicts(bryntumSchedule);

  const handleCreateBlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    addScheduleItem({
      title: newTitle,
      titleAr: newTitleAr || newTitle,
      startTime: newStartTime,
      endTime: newEndTime,
      trackId: newTrackId,
      vendorName: newVendorName,
      zone: newZone,
      zoneAr: newZone,
      status: 'confirmed',
      notes: newNotes,
      color: TRACKS.find((t) => t.id === newTrackId)?.color || '#B79A66'
    });

    setIsAddModalOpen(false);
    setNewTitle('');
    setNewTitleAr('');
    setNewNotes('');
  };

  const handleExportCallSheet = () => {
    showToast(language === 'ar' ? 'تم تنزيل جدول المواعيد وتوزيعه على الموردين (PDF)' : 'Master Call Sheet & Run-of-Show exported to PDF');
  };

  const filteredSchedule = filterTrack === 'all'
    ? bryntumSchedule
    : bryntumSchedule.filter((item) => item.trackId === filterTrack);

  return (
    <div className="py-8 bg-[#FAF8F4] min-h-screen space-y-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">

        {/* Sponsor Banner Header */}
        <div className="p-6 sm:p-8 bg-gradient-to-r from-[#242320] via-[#33312C] to-[#242320] rounded-2xl text-white shadow-xl relative overflow-hidden border border-[#44423D]">
          <div className="absolute top-0 right-0 -mt-8 -mr-8 w-60 h-60 bg-[#B79A66]/10 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="px-2.5 py-0.5 rounded bg-[#B79A66] text-[#242320] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Bryntum Scheduler</span>
                </div>
                <span className="text-xs text-[#8E8A82]">·</span>
                <span className="text-xs text-[#B5B0A6]">
                  {language === 'ar' ? 'محرك الجدولة عالي الأداء للأحداث' : 'Enterprise High-FPS Timeline Engine'}
                </span>
              </div>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold tracking-tight">
                {language === 'ar' ? 'جدول سير الفعالية وتنسيق الموردين (Run of Show)' : 'Day-of Event Run-of-Show Scheduler'}
              </h2>
              <p className="text-xs sm:text-sm text-[#B5B0A6] max-w-2xl leading-relaxed">
                {language === 'ar'
                  ? 'تنسيق متزامن بالدقيقة لكافة مقدمي الخدمات في قصر النيل: تركيب الكوشة، هندسة الصوت، زفة العروسين، الاستعراض الشرقي، ومراسم العشاء مع فحص تلقائي لأي تضارب في المواعيد.'
                  : 'Real-time multi-resource timeline coordinating floral staging, lighting soundchecks, royal Zaffah procession, belly dancer performance, and open buffet without staging conflicts.'}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="px-4 py-2.5 bg-[#B79A66] hover:bg-[#A38652] text-[#242320] font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>{language === 'ar' ? 'إضافة فقرة جديدة' : 'Add Timeline Block'}</span>
              </button>
              <button
                onClick={handleExportCallSheet}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 font-semibold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                <span>{language === 'ar' ? 'تصدير جدول المواعيد' : 'Export Call Sheet'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Preset Switcher & Conflict Indicator */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white rounded-2xl border border-[#E5DFD5] shadow-xs">
          <div className="flex items-center gap-2 overflow-x-auto">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#77736C] shrink-0">
              {language === 'ar' ? 'قوالب الفعاليات الجاهزة:' : 'Event Presets:'}
            </span>
            <button
              onClick={() => {
                setActivePreset('cairo_wedding');
                resetBryntumPreset('cairo_wedding');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors shrink-0 ${
                activePreset === 'cairo_wedding'
                  ? 'bg-[#242320] text-white font-semibold'
                  : 'bg-[#FAF8F4] text-[#77736C] hover:text-[#242320]'
              }`}
            >
              👑 {language === 'ar' ? 'زفاف قصر النيل الملكي' : 'Cairo Royal Wedding'}
            </button>
            <button
              onClick={() => {
                setActivePreset('gouna_beach');
                resetBryntumPreset('gouna_beach');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors shrink-0 ${
                activePreset === 'gouna_beach'
                  ? 'bg-[#242320] text-white font-semibold'
                  : 'bg-[#FAF8F4] text-[#77736C] hover:text-[#242320]'
              }`}
            >
              🌊 {language === 'ar' ? 'زفاف شاطئ الجونة' : 'El Gouna Beachfront'}
            </button>
            <button
              onClick={() => {
                setActivePreset('corporate_gala');
                resetBryntumPreset('corporate_gala');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors shrink-0 ${
                activePreset === 'corporate_gala'
                  ? 'bg-[#242320] text-white font-semibold'
                  : 'bg-[#FAF8F4] text-[#77736C] hover:text-[#242320]'
              }`}
            >
              🏢 {language === 'ar' ? 'حفل سنوي ومؤتمر' : 'Corporate Gala'}
            </button>
          </div>

          <div className="flex items-center gap-3">
            {conflictIds.length > 0 ? (
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{conflictIds.length / 2} {language === 'ar' ? 'تضارب زمني مكتشف' : 'Schedule Conflict Detected'}</span>
              </span>
            ) : (
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#E8F5E9] text-[#2E6B4F] flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{language === 'ar' ? 'الجدول متناسق 100%' : 'All Tracks Conflict-Free'}</span>
              </span>
            )}
          </div>
        </div>

        {/* Master Bryntum Timeline Grid */}
        <div className="bg-white rounded-2xl border border-[#E5DFD5] shadow-xs overflow-hidden">
          
          {/* Header Controls Bar */}
          <div className="p-4 border-b border-[#E5DFD5] flex flex-wrap items-center justify-between gap-4 bg-[#FAF8F4]">
            <div className="flex items-center gap-3">
              <span className="font-editorial text-lg font-semibold text-[#242320]">
                {language === 'ar' ? activeEvent.titleAr || activeEvent.title : activeEvent.title}
              </span>
              <span className="text-xs text-[#77736C]">
                ({filteredSchedule.length} {language === 'ar' ? 'فقرات مجدولة' : 'Scheduled Blocks'})
              </span>
            </div>

            {/* Track Filter */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-[#77736C]">{language === 'ar' ? 'تصفية المسار:' : 'Track Filter:'}</span>
              <select
                value={filterTrack}
                onChange={(e) => setFilterTrack(e.target.value)}
                className="px-2.5 py-1.5 bg-white border border-[#E5DFD5] rounded-lg text-xs focus:outline-none"
              >
                <option value="all">{language === 'ar' ? 'كافة المسارات' : 'All 5 Resource Tracks'}</option>
                {TRACKS.map((t) => (
                  <option key={t.id} value={t.id}>
                    {language === 'ar' ? t.nameAr : t.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Time Swimlanes */}
          <div className="divide-y divide-[#E5DFD5]">
            {TRACKS.filter((t) => filterTrack === 'all' || filterTrack === t.id).map((track) => {
              const trackItems = filteredSchedule.filter((item) => item.trackId === track.id);

              return (
                <div key={track.id} className="p-5 space-y-4 hover:bg-[#FAF8F4]/50 transition-colors">
                  {/* Track Row Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{track.icon}</span>
                      <div>
                        <h4 className="font-semibold text-sm text-[#242320] flex items-center gap-2">
                          <span>{language === 'ar' ? track.nameAr : track.name}</span>
                          <span 
                            className="w-2.5 h-2.5 rounded-full inline-block"
                            style={{ backgroundColor: track.color }}
                          />
                        </h4>
                        <span className="text-[11px] text-[#77736C]">
                          {track.responsibleGroup}
                        </span>
                      </div>
                    </div>

                    <span className="text-xs text-[#77736C]">
                      {trackItems.length} {language === 'ar' ? 'فقرات' : 'tasks'}
                    </span>
                  </div>

                  {/* Track Blocks Cards */}
                  {trackItems.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {trackItems.map((item) => {
                        const hasConflict = conflictIds.includes(item.id);

                        return (
                          <div
                            key={item.id}
                            onClick={() => setSelectedItem(item)}
                            className={`p-4 rounded-xl border text-xs space-y-2 cursor-pointer transition-all hover:shadow-md relative overflow-hidden bg-white ${
                              hasConflict 
                                ? 'border-rose-400 ring-2 ring-rose-200' 
                                : 'border-[#E5DFD5] hover:border-[#B79A66]'
                            }`}
                          >
                            <div 
                              className="absolute top-0 left-0 right-0 h-1"
                              style={{ backgroundColor: item.color || track.color }}
                            />

                            <div className="flex items-center justify-between text-[11px] text-[#77736C]">
                              <span className="font-mono font-bold text-[#242320] flex items-center gap-1">
                                <Clock className="w-3.5 h-3.5 text-[#B79A66]" />
                                {item.startTime} – {item.endTime}
                              </span>
                              <span className="text-[#B79A66] font-semibold truncate max-w-[120px]">
                                {language === 'ar' ? item.zoneAr : item.zone}
                              </span>
                            </div>

                            <h5 className="font-semibold text-sm text-[#242320] leading-snug">
                              {language === 'ar' ? item.titleAr : item.title}
                            </h5>

                            <div className="flex items-center justify-between pt-1 text-[11px] text-[#77736C]">
                              <span className="truncate max-w-[150px]">
                                👤 {language === 'ar' ? item.vendorNameAr || item.vendorName : item.vendorName}
                              </span>

                              {hasConflict && (
                                <span className="text-rose-600 font-bold flex items-center gap-1">
                                  <AlertTriangle className="w-3 h-3" />
                                  Conflict
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl border border-dashed border-[#E5DFD5] text-center text-xs text-[#77736C]">
                      {language === 'ar' ? 'لا توجد مهام مجدولة في هذا المسار حالياً' : 'No schedule blocks assigned to this track yet.'}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Modal: Item Details / Edit / Delete */}
        {selectedItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-[#E5DFD5] p-6 space-y-5 text-xs text-[#242320]">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5DFD5]">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-[#B79A66]" />
                  <span className="font-editorial text-xl font-semibold">
                    {language === 'ar' ? selectedItem.titleAr : selectedItem.title}
                  </span>
                </div>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="p-1.5 text-[#77736C] hover:text-[#242320] rounded-lg"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3 p-4 bg-[#FAF8F4] rounded-xl border border-[#E5DFD5]">
                <div>
                  <span className="text-[11px] text-[#77736C] block">{language === 'ar' ? 'الوقت المحدد' : 'Scheduled Window'}</span>
                  <span className="font-mono font-bold text-sm text-[#242320]">{selectedItem.startTime} – {selectedItem.endTime}</span>
                </div>
                <div>
                  <span className="text-[11px] text-[#77736C] block">{language === 'ar' ? 'الموقع / المسرح' : 'Stage / Zone'}</span>
                  <span className="font-semibold text-sm text-[#B79A66]">{selectedItem.zone}</span>
                </div>
                <div className="col-span-2 pt-2 border-t border-[#E5DFD5]">
                  <span className="text-[11px] text-[#77736C] block">{language === 'ar' ? 'المورد المسؤول' : 'Assigned Vendor'}</span>
                  <span className="font-semibold text-sm">{selectedItem.vendorName}</span>
                </div>
              </div>

              {selectedItem.notes && (
                <div className="p-3.5 bg-stone-50 rounded-xl border border-[#E5DFD5]">
                  <span className="font-semibold text-[11px] text-[#77736C] block mb-1">
                    {language === 'ar' ? 'الملاحظات الفنية:' : 'Technical Notes:'}
                  </span>
                  <p className="text-[#242320] leading-relaxed">
                    {language === 'ar' ? selectedItem.notesAr || selectedItem.notes : selectedItem.notes}
                  </p>
                </div>
              )}

              <div className="flex items-center justify-between pt-3 border-t border-[#E5DFD5]">
                <button
                  type="button"
                  onClick={() => {
                    deleteScheduleItem(selectedItem.id);
                    setSelectedItem(null);
                  }}
                  className="px-4 py-2 text-rose-600 hover:bg-rose-50 rounded-lg font-medium transition-colors flex items-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{language === 'ar' ? 'حذف الفقرة' : 'Delete Block'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedItem(null)}
                  className="px-5 py-2 bg-[#242320] text-white rounded-xl font-semibold uppercase tracking-wider text-xs"
                >
                  {language === 'ar' ? 'إغلاق' : 'Close'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Add New Block */}
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-[#E5DFD5] p-6 space-y-5 text-xs text-[#242320]">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5DFD5]">
                <div className="flex items-center gap-2">
                  <Plus className="w-5 h-5 text-[#B79A66]" />
                  <span className="font-editorial text-xl font-semibold">
                    {language === 'ar' ? 'إضافة فقرة جديدة لجدول برينتوم' : 'Add Bryntum Schedule Block'}
                  </span>
                </div>
                <button
                  onClick={() => setIsAddModalOpen(false)}
                  className="p-1.5 text-[#77736C] hover:text-[#242320] rounded-lg"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleCreateBlock} className="space-y-4">
                <div>
                  <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                    {language === 'ar' ? 'عنوان الفقرة (بالإنجليزية)' : 'Block Title (English)'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Wedding Cake Cutting & Fireworks"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none focus:border-[#B79A66]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                    {language === 'ar' ? 'عنوان الفقرة (بالعربية)' : 'Block Title (Arabic)'}
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: مراسم تقطيع الكعكة والألعاب النارية"
                    value={newTitleAr}
                    onChange={(e) => setNewTitleAr(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none focus:border-[#B79A66]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                      {language === 'ar' ? 'وقت البدء' : 'Start Time'}
                    </label>
                    <input
                      type="time"
                      value={newStartTime}
                      onChange={(e) => setNewStartTime(e.target.value)}
                      className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                      {language === 'ar' ? 'وقت الانتهاء' : 'End Time'}
                    </label>
                    <input
                      type="time"
                      value={newEndTime}
                      onChange={(e) => setNewEndTime(e.target.value)}
                      className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                      {language === 'ar' ? 'المسار المخصص' : 'Resource Track'}
                    </label>
                    <select
                      value={newTrackId}
                      onChange={(e) => setNewTrackId(e.target.value as BryntumTrackId)}
                      className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none"
                    >
                      {TRACKS.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.icon} {language === 'ar' ? t.nameAr : t.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                      {language === 'ar' ? 'الموقع / القاعة' : 'Zone / Location'}
                    </label>
                    <input
                      type="text"
                      value={newZone}
                      onChange={(e) => setNewZone(e.target.value)}
                      placeholder="e.g. Grand Ballroom Stage"
                      className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                    {language === 'ar' ? 'المورد المسؤول' : 'Vendor'}
                  </label>
                  <input
                    type="text"
                    value={newVendorName}
                    onChange={(e) => setNewVendorName(e.target.value)}
                    placeholder="Vendor Name"
                    className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                    {language === 'ar' ? 'ملاحظات فنية' : 'Technical Notes'}
                  </label>
                  <textarea
                    rows={2}
                    value={newNotes}
                    onChange={(e) => setNewNotes(e.target.value)}
                    placeholder="Special requirements, sound levels, lighting cue..."
                    className="w-full px-3 py-2 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E5DFD5]">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-4 py-2 border border-[#E5DFD5] rounded-xl hover:bg-stone-50"
                  >
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#242320] hover:bg-[#B79A66] text-white rounded-xl font-semibold uppercase tracking-wider text-xs transition-colors"
                  >
                    {language === 'ar' ? 'حفظ الفقرة' : 'Save to Bryntum Schedule'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
