import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatEgp } from '../../utils/translations';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  CheckCircle2, 
  RotateCcw, 
  ArrowUpRight, 
  Download, 
  FileText, 
  DollarSign, 
  Plus, 
  ExternalLink,
  Wallet,
  Sparkles,
  Info
} from 'lucide-react';

export const PayPalEscrowDashboard: React.FC = () => {
  const { 
    payPalTransactions, 
    releaseEscrowMilestone, 
    refundEscrowTransaction, 
    vendorPayPalBalance,
    withdrawVendorPayoutPayPal,
    openPayPalModal,
    vendors,
    language,
    setCurrentView 
  } = useApp();

  const [payoutEmail, setPayoutEmail] = useState('orbitronsystems@gmail.com');
  const [payoutAmount, setPayoutAmount] = useState('50000');
  const [selectedReceiptTx, setSelectedReceiptTx] = useState<any | null>(null);

  // Stats calculation
  const totalInEscrow = payPalTransactions
    .filter((t) => t.status === 'escrow_held')
    .reduce((acc, t) => acc + t.amountEgp, 0);

  const totalReleased = payPalTransactions
    .filter((t) => t.status === 'released')
    .reduce((acc, t) => acc + t.amountEgp, 0);

  const handleQuickTestDeposit = () => {
    const defaultVendor = vendors[0];
    openPayPalModal({
      vendor: defaultVendor,
      quoteAmountEgp: 380000,
      depositAmountEgp: 76000
    });
  };

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = Number(payoutAmount);
    if (!amount || amount <= 0) return;
    withdrawVendorPayoutPayPal(amount, payoutEmail);
  };

  return (
    <div className="py-8 bg-[#FAF8F4] min-h-screen space-y-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Header with PayPal branding */}
        <div className="p-6 sm:p-8 bg-gradient-to-r from-[#003087] via-[#0047BA] to-[#0079C1] rounded-2xl text-white shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="font-extrabold italic text-2xl tracking-tighter text-[#FFC439]">P<span className="text-white">P</span></span>
                <span className="text-xs uppercase font-bold tracking-widest px-2.5 py-0.5 rounded bg-white/20 text-white">
                  PayPal Sponsor Integration
                </span>
                <span className="text-xs text-white/70">·</span>
                <span className="text-xs text-white/80">Core Payment Partner</span>
              </div>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold tracking-tight">
                {language === 'ar' ? 'محفظة الضمان الذكي وتسويات باي بال' : 'PayPal Smart Escrow & Milestone Suite'}
              </h2>
              <p className="text-xs sm:text-sm text-white/80 max-w-2xl leading-relaxed">
                {language === 'ar'
                  ? 'حماية كاملة للعربون المالي للأعراس والفعاليات. تظل الأموال محجوزة بأمان حتى اعتماد مراحل التنفيذ والتسليم الرسمي.'
                  : 'Multi-milestone escrow locking funds until delivery verification. Featuring 3-tier milestone releases, multi-currency conversion, and automated PayPal Instant Payouts.'}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              <button
                onClick={() => setCurrentView('postman_api')}
                className="px-4 py-3 bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all border border-white/25 flex items-center gap-2 cursor-pointer"
              >
                <span className="font-extrabold text-[11px] text-[#FF6C37] bg-white px-1.5 py-0.5 rounded">PM</span>
                <span>{language === 'ar' ? 'اختبار الواجهة في بوستمان' : 'Postman API Console'}</span>
              </button>
              <button
                onClick={handleQuickTestDeposit}
                className="px-5 py-3 bg-[#FFC439] hover:bg-[#F2BA36] text-[#003087] font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{language === 'ar' ? 'تجربة حجز عربون جديد' : 'Test PayPal Deposit Flow'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* 3 KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          {/* 1. Total in Escrow */}
          <div className="bg-white p-6 rounded-2xl border border-[#E5DFD5] shadow-xs space-y-3">
            <div className="flex items-center justify-between text-xs text-[#77736C]">
              <span className="uppercase tracking-wider font-semibold">
                {language === 'ar' ? 'الأموال المحتجزة بالضمان' : 'Active Escrow Locked'}
              </span>
              <div className="w-8 h-8 rounded-lg bg-[#EBF3FC] text-[#003087] flex items-center justify-center">
                <Lock className="w-4 h-4" />
              </div>
            </div>
            <div>
              <span className="font-editorial text-3xl font-bold text-[#003087] block tabular-nums">
                {formatEgp(totalInEscrow, language)}
              </span>
              <span className="text-[11px] text-[#2E6B4F] flex items-center gap-1 mt-1 font-medium">
                <ShieldCheck className="w-3.5 h-3.5" />
                {payPalTransactions.filter((t) => t.status === 'escrow_held').length} {language === 'ar' ? 'حجوزات مؤمنة حالياً' : 'Protected Contracts'}
              </span>
            </div>
          </div>

          {/* 2. Total Released */}
          <div className="bg-white p-6 rounded-2xl border border-[#E5DFD5] shadow-xs space-y-3">
            <div className="flex items-center justify-between text-xs text-[#77736C]">
              <span className="uppercase tracking-wider font-semibold">
                {language === 'ar' ? 'المحرر للموردين بعد التسليم' : 'Released to Vendors'}
              </span>
              <div className="w-8 h-8 rounded-lg bg-[#E8F5E9] text-[#2E6B4F] flex items-center justify-center">
                <Unlock className="w-4 h-4" />
              </div>
            </div>
            <div>
              <span className="font-editorial text-3xl font-bold text-[#2E6B4F] block tabular-nums">
                {formatEgp(totalReleased, language)}
              </span>
              <span className="text-[11px] text-[#77736C] mt-1 block">
                {payPalTransactions.filter((t) => t.status === 'released').length} {language === 'ar' ? 'مراحل تم تسليمها بنجاح' : 'Milestones Fulfilled'}
              </span>
            </div>
          </div>

          {/* 3. Vendor Balance */}
          <div className="bg-white p-6 rounded-2xl border border-[#E5DFD5] shadow-xs space-y-3">
            <div className="flex items-center justify-between text-xs text-[#77736C]">
              <span className="uppercase tracking-wider font-semibold">
                {language === 'ar' ? 'رصيد محفظة المورد المتاح' : 'Vendor Wallet Balance'}
              </span>
              <div className="w-8 h-8 rounded-lg bg-[#FAF8F4] text-[#B79A66] flex items-center justify-center border border-[#E5DFD5]">
                <Wallet className="w-4 h-4" />
              </div>
            </div>
            <div>
              <span className="font-editorial text-3xl font-bold text-[#242320] block tabular-nums">
                {formatEgp(vendorPayPalBalance, language)}
              </span>
              <span className="text-[11px] text-[#0079C1] font-semibold mt-1 block">
                {language === 'ar' ? 'جاهز للسحب الفوري عبر باي بال' : 'Ready for Instant PayPal Payout'}
              </span>
            </div>
          </div>
        </div>

        {/* Transactions Ledger & Vendor Instant Payout Form */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left: Escrow Ledger Table (2 cols) */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-[#E5DFD5] shadow-xs p-6 space-y-5">
            <div className="flex items-center justify-between pb-4 border-b border-[#F1EDE6]">
              <div>
                <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block mb-0.5">
                  {language === 'ar' ? 'سجل العمليات والضمان' : 'PayPal Transaction Ledger'}
                </span>
                <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
                  {language === 'ar' ? 'عمليات الضمان المالي النشطة' : 'Escrow Contracts & Milestones'}
                </h3>
              </div>

              <span className="text-xs text-[#77736C]">
                {payPalTransactions.length} {language === 'ar' ? 'معاملات' : 'Transactions'}
              </span>
            </div>

            <div className="space-y-4">
              {payPalTransactions.map((tx) => {
                const isHeld = tx.status === 'escrow_held';
                const isReleased = tx.status === 'released';
                const isRefunded = tx.status === 'refunded';

                return (
                  <div 
                    key={tx.id}
                    className="p-5 rounded-xl border border-[#E5DFD5] bg-[#FAF8F4] space-y-4 hover:border-[#B79A66] transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5DFD5]">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-xs font-bold text-[#003087]">
                            {tx.id}
                          </span>
                          <span className="text-[#E5DFD5]">·</span>
                          <span className="text-[11px] text-[#77736C]">
                            {tx.orderId}
                          </span>
                        </div>
                        <h4 className="font-editorial text-lg font-semibold text-[#242320]">
                          {language === 'ar' ? tx.vendorNameAr || tx.vendorName : tx.vendorName}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2">
                        {isHeld && (
                          <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-[#EBF3FC] text-[#003087] flex items-center gap-1 border border-[#003087]/20">
                            <Lock className="w-3 h-3" />
                            {language === 'ar' ? 'محفوظ بالضمان' : 'Held in Escrow'}
                          </span>
                        )}
                        {isReleased && (
                          <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-[#E8F5E9] text-[#2E6B4F] flex items-center gap-1 border border-[#2E6B4F]/20">
                            <CheckCircle2 className="w-3 h-3" />
                            {language === 'ar' ? 'تم تحريره للمورد' : 'Released to Vendor'}
                          </span>
                        )}
                        {isRefunded && (
                          <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-rose-50 text-rose-800 flex items-center gap-1 border border-rose-200">
                            <RotateCcw className="w-3 h-3" />
                            {language === 'ar' ? 'مسترد بالكامل' : 'Refunded'}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div>
                        <span className="text-[11px] text-[#77736C] block">{language === 'ar' ? 'المرحلة' : 'Milestone Tier'}</span>
                        <span className="font-semibold text-[#242320]">{tx.tierName}</span>
                      </div>
                      <div>
                        <span className="text-[11px] text-[#77736C] block">{language === 'ar' ? 'القيمة والمبلغ' : 'Amount'}</span>
                        <span className="font-bold text-sm text-[#242320] tabular-nums">
                          {formatEgp(tx.amountEgp, language)}
                        </span>
                        {tx.currency !== 'EGP' && (
                          <span className="text-[10px] text-[#77736C] block">
                            ({tx.convertedAmount.toLocaleString()} {tx.currency})
                          </span>
                        )}
                      </div>
                      <div>
                        <span className="text-[11px] text-[#77736C] block">{language === 'ar' ? 'صاحب الحساب' : 'Payer'}</span>
                        <span className="font-medium text-[#242320]">{tx.payerName}</span>
                        <span className="text-[10px] text-[#77736C] block truncate">{tx.payerEmail}</span>
                      </div>
                    </div>

                    {/* Escrow Actions */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#E5DFD5]">
                      <span className="text-[11px] text-[#77736C]">
                        {tx.date}
                      </span>

                      <div className="flex items-center gap-2">
                        {isHeld && (
                          <>
                            <button
                              onClick={() => refundEscrowTransaction(tx.id)}
                              className="px-3 py-1.5 rounded-lg border border-[#E5DFD5] hover:border-rose-400 text-xs text-[#77736C] hover:text-rose-600 transition-colors flex items-center gap-1.5"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>{language === 'ar' ? 'استرداد (حماية المشتري)' : 'Refund'}</span>
                            </button>
                            <button
                              onClick={() => releaseEscrowMilestone(tx.id)}
                              className="px-4 py-1.5 rounded-lg bg-[#2E6B4F] hover:bg-[#255740] text-white text-xs font-semibold uppercase tracking-wider transition-colors flex items-center gap-1.5 shadow-xs"
                            >
                              <Unlock className="w-3.5 h-3.5" />
                              <span>{language === 'ar' ? 'تحرير الدفعة للمورد' : 'Release Milestone'}</span>
                            </button>
                          </>
                        )}
                        <button
                          onClick={() => setSelectedReceiptTx(tx)}
                          className="px-3 py-1.5 rounded-lg border border-[#003087] text-[#003087] hover:bg-[#003087] hover:text-white text-xs font-medium transition-colors flex items-center gap-1.5"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>{language === 'ar' ? 'الإيصال الرسمي' : 'PayPal Receipt'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Vendor PayPal Instant Payout (1 col) */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl border border-[#E5DFD5] shadow-xs p-6 space-y-5">
              <div>
                <span className="text-xs uppercase tracking-widest text-[#0079C1] font-semibold block mb-0.5">
                  {language === 'ar' ? 'سحب فوري للمورد' : 'Instant Vendor Payout'}
                </span>
                <h4 className="font-editorial text-2xl font-semibold text-[#242320]">
                  {language === 'ar' ? 'صرف المستحقات عبر باي بال' : 'PayPal Payouts API'}
                </h4>
                <p className="text-xs text-[#77736C] mt-1 leading-relaxed">
                  {language === 'ar'
                    ? 'تحويل الأرباح المحررة مباشرة إلى حساب باي بال الشخصي أو التجاري للمورد بلحظات.'
                    : 'Disburse released milestone funds directly to vendor PayPal balance using PayPal Payouts.'}
                </p>
              </div>

              <form onSubmit={handleWithdraw} className="space-y-4 text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                    {language === 'ar' ? 'حساب باي بال المستلم' : 'Recipient PayPal Email'}
                  </label>
                  <input
                    type="email"
                    required
                    value={payoutEmail}
                    onChange={(e) => setPayoutEmail(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none focus:border-[#003087]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                    {language === 'ar' ? 'المبلغ المطلوب سحبه (جنيه مصري)' : 'Withdrawal Amount (EGP)'}
                  </label>
                  <input
                    type="number"
                    min="1000"
                    max={vendorPayPalBalance}
                    required
                    value={payoutAmount}
                    onChange={(e) => setPayoutAmount(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#FAF8F4] rounded-lg border border-[#E5DFD5] text-xs focus:outline-none focus:border-[#003087] font-semibold"
                  />
                  <div className="flex justify-between items-center mt-1 text-[11px] text-[#77736C]">
                    <span>{language === 'ar' ? 'الرصيد المتاح:' : 'Available:'} {formatEgp(vendorPayPalBalance, language)}</span>
                    <button
                      type="button"
                      onClick={() => setPayoutAmount(vendorPayPalBalance.toString())}
                      className="text-[#0079C1] hover:underline font-medium"
                    >
                      {language === 'ar' ? 'الكل' : 'Max'}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={vendorPayPalBalance <= 0}
                  className="w-full py-3 bg-[#003087] hover:bg-[#002568] disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <ArrowUpRight className="w-4 h-4 text-[#FFC439]" />
                  <span>{language === 'ar' ? 'تحويل فوري إلى باي بال' : 'Execute Instant PayPal Payout'}</span>
                </button>
              </form>

              <div className="p-3.5 rounded-xl bg-[#FAF8F4] border border-[#E5DFD5] text-[11px] text-[#77736C] space-y-1.5">
                <div className="flex items-center gap-1.5 text-[#242320] font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#0079C1]" />
                  <span>{language === 'ar' ? 'حماية البائع المعتمدة' : 'PayPal Seller Protection'}</span>
                </div>
                <p className="leading-relaxed">
                  {language === 'ar'
                    ? 'جميع التحويلات موثقة بأرقام مرجعية معتمدة وحماية كاملة ضد المنازعات الاحتيالية.'
                    : 'All payouts processed with zero latency, automated tax invoicing, and dispute indemnity.'}
                </p>
              </div>
            </div>

            {/* Hackathon Sponsor Highlight */}
            <div className="p-5 rounded-2xl bg-[#003087]/5 border border-[#003087]/15 space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#003087] flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-[#FFC439]" />
                Sponsor Architecture
              </span>
              <p className="text-xs text-[#77736C] leading-relaxed">
                Integrated with <strong>PayPal Smart Payment Buttons</strong>, <strong>Orders API v2</strong>, and <strong>Payouts API</strong>.
              </p>
            </div>
          </div>

        </div>

        {/* Modal: Official Receipt Viewer */}
        {selectedReceiptTx && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-[#E5DFD5] p-6 space-y-5 text-xs text-[#242320]">
              <div className="flex items-center justify-between pb-3 border-b border-[#E5DFD5]">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold italic text-xl text-[#003087]">PayPal</span>
                  <span className="text-[10px] uppercase font-bold text-[#77736C]">Official Receipt</span>
                </div>
                <button
                  onClick={() => setSelectedReceiptTx(null)}
                  className="p-1 rounded-lg hover:bg-stone-100 text-[#77736C]"
                >
                  ✕
                </button>
              </div>

              <div className="p-4 bg-[#FAF8F4] rounded-xl border border-[#E5DFD5] space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#77736C]">Transaction ID</span>
                  <span className="font-mono font-bold text-[#003087]">{selectedReceiptTx.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#77736C]">Merchant / Vendor</span>
                  <span className="font-semibold">{selectedReceiptTx.vendorName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#77736C]">Stage Description</span>
                  <span className="font-semibold">{selectedReceiptTx.tierName}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-[#E5DFD5]">
                  <span className="font-semibold">Gross Captured</span>
                  <span className="font-bold text-sm text-[#2E6B4F]">{formatEgp(selectedReceiptTx.amountEgp, language)}</span>
                </div>
              </div>

              <div className="text-[11px] text-[#77736C] space-y-1">
                <p><strong>Payer:</strong> {selectedReceiptTx.payerName} ({selectedReceiptTx.payerEmail})</p>
                <p><strong>Captured:</strong> {selectedReceiptTx.date}</p>
                <p><strong>Status:</strong> {selectedReceiptTx.status.toUpperCase()}</p>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setSelectedReceiptTx(null)}
                  className="w-full py-2.5 bg-[#242320] text-white rounded-xl font-semibold uppercase tracking-wider text-xs"
                >
                  Close Receipt
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
