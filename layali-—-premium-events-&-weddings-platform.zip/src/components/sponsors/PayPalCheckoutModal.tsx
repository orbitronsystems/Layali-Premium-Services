import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CurrencyCode, PayPalTransaction } from '../../types';
import { formatEgp } from '../../utils/translations';
import { 
  X, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  Lock, 
  FileText, 
  Download, 
  Layers, 
  Calendar, 
  Building2, 
  Sparkles,
  Zap
} from 'lucide-react';

// Live approximate conversion rates relative to EGP
const CURRENCY_RATES: Record<CurrencyCode, { symbol: string; rate: number; name: string }> = {
  EGP: { symbol: 'EGP', rate: 1, name: 'Egyptian Pound' },
  USD: { symbol: '$', rate: 0.0203, name: 'US Dollar' },
  EUR: { symbol: '€', rate: 0.0189, name: 'Euro' },
  AED: { symbol: 'AED', rate: 0.0746, name: 'UAE Dirham' }
};

export const PayPalCheckoutModal: React.FC = () => {
  const { 
    isPayPalModalOpen, 
    closePayPalModal, 
    payPalTarget, 
    processPayPalPayment, 
    language,
    setCurrentView
  } = useApp();

  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>('EGP');
  const [selectedTier, setSelectedTier] = useState<1 | 2 | 3>(1);
  const [payerName, setPayerName] = useState('Tarek Mansour');
  const [payerEmail, setPayerEmail] = useState('tarek.mansour@example.eg');
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedTx, setCompletedTx] = useState<PayPalTransaction | null>(null);

  if (!isPayPalModalOpen || !payPalTarget) return null;

  const vendor = payPalTarget.vendor;
  const totalAmountEgp = payPalTarget.quoteAmountEgp 
    || payPalTarget.package?.priceEgp 
    || vendor.startingPriceEgp;

  // Milestone calculations:
  // Tier 1: 20% Deposit (or explicit depositAmountEgp)
  // Tier 2: 50% Production
  // Tier 3: 30% Final Settlement
  const tier1AmountEgp = payPalTarget.depositAmountEgp || Math.round(totalAmountEgp * 0.20);
  const tier2AmountEgp = Math.round(totalAmountEgp * 0.50);
  const tier3AmountEgp = Math.round(totalAmountEgp * 0.30);

  const activeAmountEgp = selectedTier === 1 
    ? tier1AmountEgp 
    : selectedTier === 2 
    ? tier2AmountEgp 
    : tier3AmountEgp;

  const rateInfo = CURRENCY_RATES[selectedCurrency];
  const convertedAmount = Number((activeAmountEgp * rateInfo.rate).toFixed(2));

  const tierNames = {
    1: {
      en: 'Milestone 1: 20% Booking Deposit (Date Lock)',
      ar: 'المرحلة 1: عربون تأكيد الحجز وحجز الموعد (20%)',
      descEn: 'Funds held securely in PayPal Smart Escrow until venue/vendor preliminary moodboard is signed off.',
      descAr: 'تظل الأموال محفوظة في حساب الضمان الذكي حتى اعتماد التصاميم والمخطط الأولي.'
    },
    2: {
      en: 'Milestone 2: 50% Production & Staging Lock',
      ar: 'المرحلة 2: تجهيزات الإنتاج والديكور (50%)',
      descEn: 'Released 48 hours prior to event upon site inspection and equipment delivery check.',
      descAr: 'يتم تحريرها قبل الفعالية بـ 48 ساعة بعد فحص الموقع واستلام المعدات.'
    },
    3: {
      en: 'Milestone 3: 30% Post-Event Settlement',
      ar: 'المرحلة 3: التسوية النهائية بعد انتهاء الفعالية (30%)',
      descEn: 'Released post-event after successful execution sign-off by couple / event host.',
      descAr: 'يتم تحريرها بعد انتهاء الفعالية بنجاح واعتماد صاحب الحفل.'
    }
  };

  const handlePayWithPayPal = () => {
    setIsProcessing(true);

    // Simulate PayPal Checkout SDK network roundtrip
    setTimeout(() => {
      const txId = `PAYID-${Math.random().toString(36).substring(2, 7).toUpperCase()}-EGY-${Math.floor(1000 + Math.random() * 9000)}`;
      const orderId = `ORD-${vendor.id.substring(0, 8).toUpperCase()}-${Date.now().toString().slice(-5)}`;

      const newTx: PayPalTransaction = {
        id: txId,
        orderId,
        vendorId: vendor.id,
        vendorName: vendor.name,
        vendorNameAr: vendor.nameAr,
        inquiryId: payPalTarget.inquiryId,
        amountEgp: activeAmountEgp,
        currency: selectedCurrency,
        convertedAmount,
        tier: selectedTier,
        tierName: tierNames[selectedTier].en,
        status: 'escrow_held',
        date: new Date().toISOString().replace('T', ' ').substring(0, 19),
        payerEmail,
        payerName,
        payerId: `PAYER-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
        notes: `Smart Escrow Deposit secured via PayPal for ${vendor.name}`
      };

      setIsProcessing(false);
      setCompletedTx(newTx);
      processPayPalPayment(newTx);
    }, 1200);
  };

  const handleClose = () => {
    setCompletedTx(null);
    closePayPalModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-[#FAF8F4] w-full max-w-xl rounded-2xl shadow-2xl border border-[#E5DFD5] overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top PayPal Brand Header */}
        <div className="bg-[#003087] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* PayPal Glyph */}
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <span className="font-bold text-xl italic tracking-tighter text-[#FFC439]">P<span className="text-white">P</span></span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold tracking-tight text-base">PayPal</span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-[#0079C1] text-white tracking-wider">
                  Smart Escrow
                </span>
              </div>
              <p className="text-xs text-white/80">
                {language === 'ar' ? 'بوابة الدفع وحماية العربون الذكي للفعاليات' : 'Milestone Deposit & Date Lock Guarantee'}
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="p-1.5 text-white/70 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-[#242320]">
          {!completedTx ? (
            <>
              {/* Vendor & Event Context */}
              <div className="p-4 bg-white rounded-xl border border-[#E5DFD5] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#77736C] uppercase tracking-wider font-medium">
                    {language === 'ar' ? 'المورد المعتمد' : 'Verified Vendor'}
                  </span>
                  <span className="text-[#B79A66] font-semibold">
                    {vendor.city} · {vendor.neighborhood}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-[#FAF8F4] border border-[#E5DFD5] overflow-hidden shrink-0">
                    <img 
                      src={vendor.coverImage} 
                      alt={vendor.name} 
                      className="w-full h-full object-cover" 
                    />
                  </div>
                  <div>
                    <h4 className="font-editorial text-lg font-semibold text-[#242320]">
                      {language === 'ar' ? vendor.nameAr : vendor.name}
                    </h4>
                    <p className="text-xs text-[#77736C]">
                      {payPalTarget.package?.name 
                        ? `${language === 'ar' ? payPalTarget.package.nameAr : payPalTarget.package.name} Package`
                        : `${formatEgp(totalAmountEgp, language)} Total Contract Value`}
                    </p>
                  </div>
                </div>
              </div>

              {/* Milestone Selection (1, 2, 3) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold uppercase tracking-wider text-[#77736C]">
                    {language === 'ar' ? 'اختر مرحلة السداد بالضمان' : 'Select Milestone Stage'}
                  </label>
                  <span className="text-[11px] text-[#0079C1] font-medium flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    {language === 'ar' ? 'أموالك محمية حتى التنفيذ' : 'Buyer Escrow Protected'}
                  </span>
                </div>

                <div className="space-y-2">
                  {([1, 2, 3] as const).map((tier) => {
                    const isSelected = selectedTier === tier;
                    const amount = tier === 1 ? tier1AmountEgp : tier === 2 ? tier2AmountEgp : tier3AmountEgp;
                    return (
                      <button
                        key={tier}
                        type="button"
                        onClick={() => setSelectedTier(tier)}
                        className={`w-full text-left rtl:text-right p-3.5 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                          isSelected
                            ? 'border-[#003087] bg-[#F0F5FA] ring-2 ring-[#003087]/20 shadow-xs'
                            : 'border-[#E5DFD5] bg-white hover:border-[#B79A66]'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] font-bold ${
                              isSelected ? 'bg-[#003087] text-white border-[#003087]' : 'border-[#77736C] text-[#77736C]'
                            }`}>
                              {tier}
                            </span>
                            <span className="text-xs font-semibold text-[#242320]">
                              {language === 'ar' ? tierNames[tier].ar : tierNames[tier].en}
                            </span>
                          </div>
                          <p className="text-[11px] text-[#77736C] pl-6 rtl:pl-0 rtl:pr-6 leading-relaxed">
                            {language === 'ar' ? tierNames[tier].descAr : tierNames[tier].descEn}
                          </p>
                        </div>
                        <div className="text-right rtl:text-left shrink-0">
                          <span className="font-semibold text-xs text-[#242320] block">
                            {formatEgp(amount, language)}
                          </span>
                          <span className="text-[10px] text-[#77736C]">
                            {tier === 1 ? '20%' : tier === 2 ? '50%' : '30%'}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Currency Selector */}
              <div className="space-y-2">
                <label className="text-xs font-semibold uppercase tracking-wider text-[#77736C]">
                  {language === 'ar' ? 'عملة السداد عبر باي بال' : 'Payment Currency'}
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(Object.keys(CURRENCY_RATES) as CurrencyCode[]).map((curr) => (
                    <button
                      key={curr}
                      type="button"
                      onClick={() => setSelectedCurrency(curr)}
                      className={`py-2 px-2 rounded-lg text-xs font-medium border text-center transition-colors ${
                        selectedCurrency === curr
                          ? 'border-[#003087] bg-[#003087] text-white font-semibold'
                          : 'border-[#E5DFD5] bg-white text-[#242320] hover:border-[#003087]'
                      }`}
                    >
                      <span>{curr}</span>
                      <span className="block text-[10px] opacity-75">
                        {curr === 'EGP' ? '1.0' : `~${CURRENCY_RATES[curr].rate.toFixed(3)}`}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Amount Breakdown Summary */}
              <div className="p-4 bg-[#FAF8F4] rounded-xl border border-[#E5DFD5] space-y-2 text-xs">
                <div className="flex justify-between text-[#77736C]">
                  <span>{language === 'ar' ? 'قيمة العربون المختار (جنيه مصري)' : 'Selected Milestone (EGP)'}</span>
                  <span className="font-medium text-[#242320]">{formatEgp(activeAmountEgp, language)}</span>
                </div>
                <div className="flex justify-between text-[#77736C]">
                  <span>{language === 'ar' ? 'رسوم حماية الضمان (0% عرض تجريبي)' : 'PayPal Escrow Protection Fee (0%)'}</span>
                  <span className="text-[#2E6B4F] font-semibold">{language === 'ar' ? 'مجاناً' : 'FREE'}</span>
                </div>
                <div className="pt-2 border-t border-[#E5DFD5] flex items-baseline justify-between">
                  <span className="font-semibold text-sm text-[#242320]">
                    {language === 'ar' ? 'إجمالي المحتجز في الضمان' : 'Total Held in Escrow'}
                  </span>
                  <div className="text-right rtl:text-left">
                    <span className="font-editorial text-2xl font-bold text-[#003087] tabular-nums block">
                      {selectedCurrency === 'EGP' ? formatEgp(activeAmountEgp, language) : `${rateInfo.symbol} ${convertedAmount.toLocaleString()} ${selectedCurrency}`}
                    </span>
                    {selectedCurrency !== 'EGP' && (
                      <span className="text-[10px] text-[#77736C]">
                        ≈ {formatEgp(activeAmountEgp, language)}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Payer Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                    {language === 'ar' ? 'اسم صاحب الحساب' : 'Cardholder / Payer Name'}
                  </label>
                  <input
                    type="text"
                    value={payerName}
                    onChange={(e) => setPayerName(e.target.value)}
                    className="w-full px-3 py-2 bg-white rounded-lg border border-[#E5DFD5] text-xs focus:outline-none focus:border-[#003087]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-[#77736C] uppercase mb-1">
                    {language === 'ar' ? 'بريد باي بال الإلكتروني' : 'PayPal Email'}
                  </label>
                  <input
                    type="email"
                    value={payerEmail}
                    onChange={(e) => setPayerEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-white rounded-lg border border-[#E5DFD5] text-xs focus:outline-none focus:border-[#003087]"
                  />
                </div>
              </div>

              {/* Authentic PayPal Buttons */}
              <div className="space-y-2.5 pt-2">
                {/* Yellow Smart Button */}
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handlePayWithPayPal}
                  className="w-full py-3.5 px-4 bg-[#FFC439] hover:bg-[#F2BA36] active:bg-[#E2AD30] text-[#003087] font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-[#003087] border-t-transparent rounded-full animate-spin" />
                      <span className="text-sm font-semibold">{language === 'ar' ? 'جاري الاتصال بباي بال...' : 'Connecting to PayPal...'}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-sm">
                      <span className="font-extrabold italic text-lg tracking-tight">PayPal</span>
                      <span className="font-semibold text-xs text-[#002C6C]">
                        {language === 'ar' ? 'سداد العربون بالضمان' : 'Pay Milestone Deposit'}
                      </span>
                    </div>
                  )}
                </button>

                {/* Secondary Debit/Credit Button */}
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handlePayWithPayPal}
                  className="w-full py-3 px-4 bg-[#2C2E2F] hover:bg-[#1E1F20] text-white font-medium rounded-xl text-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Lock className="w-3.5 h-3.5 text-white/80" />
                  <span>{language === 'ar' ? 'الدفع بواسطة البطاقة البنكية (مدعوم من باي بال)' : 'Debit or Credit Card (Powered by PayPal)'}</span>
                </button>
              </div>

              {/* Escrow Guarantee Disclaimer */}
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-[#EBF3FC] border border-[#C5DCFA] text-[11px] text-[#004085]">
                <ShieldCheck className="w-4 h-4 text-[#0079C1] shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  {language === 'ar'
                    ? 'ضمان باي بال لحجوزات الأفراح: لن يتم تحويل المبلغ للمورد حتى تأكيد الحجز وإتمام بنود العقد. يمكنك استرداد المبلغ بالكامل في حال عدم التزام المورد بالموعد.'
                    : 'PayPal Event Date Guarantee: Funds are held securely in smart escrow. Released to vendor only upon meeting stage deliverables or full refund under PayPal Buyer Protection.'}
                </p>
              </div>
            </>
          ) : (
            /* Payment Success Screen */
            <div className="text-center py-6 space-y-6">
              <div className="w-16 h-16 rounded-full bg-[#E8F5E9] text-[#2E6B4F] flex items-center justify-center mx-auto ring-8 ring-[#E8F5E9]/50 animate-in zoom-in-75 duration-300">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-1">
                <span className="text-xs uppercase tracking-widest font-semibold text-[#2E6B4F]">
                  {language === 'ar' ? 'تم تأكيد الدفع بنجاح' : 'Payment Successfully Captured'}
                </span>
                <h3 className="font-editorial text-2xl font-semibold text-[#242320]">
                  {language === 'ar' ? 'تم حجز الموعد وتأمين العربون' : 'Booking Deposit Held in Escrow'}
                </h3>
                <p className="text-xs text-[#77736C] max-w-md mx-auto">
                  {language === 'ar'
                    ? `تم تحصيل الدفعة بنجاح وإرسال إشعار رسمي للمورد (${vendor.name}).`
                    : `Your milestone payment is safely secured in smart escrow for ${vendor.name}.`}
                </p>
              </div>

              {/* Receipt Card */}
              <div className="p-4 bg-white rounded-xl border border-[#E5DFD5] text-left rtl:text-right space-y-3 text-xs max-w-md mx-auto shadow-xs">
                <div className="flex items-center justify-between pb-2 border-b border-[#F1EDE6]">
                  <span className="text-[11px] font-semibold text-[#77736C]">PayPal Transaction ID</span>
                  <span className="font-mono text-xs font-bold text-[#003087]">{completedTx.id}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#77736C]">{language === 'ar' ? 'المورد المعتمد' : 'Vendor'}</span>
                  <span className="font-semibold text-[#242320]">{vendor.name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#77736C]">{language === 'ar' ? 'المرحلة' : 'Milestone'}</span>
                  <span className="font-semibold text-[#242320]">{completedTx.tierName}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#77736C]">{language === 'ar' ? 'المبلغ المحتجز' : 'Escrow Amount'}</span>
                  <span className="font-bold text-sm text-[#2E6B4F]">
                    {formatEgp(completedTx.amountEgp, language)}
                  </span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-[#F1EDE6] text-[11px] text-[#77736C]">
                  <span>{completedTx.date}</span>
                  <span className="text-[#0079C1] font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    Verified Escrow
                  </span>
                </div>
              </div>

              {/* Next Steps Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    handleClose();
                    setCurrentView('bryntum_timeline');
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 bg-[#242320] hover:bg-[#B79A66] text-white text-xs font-semibold uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  <Calendar className="w-4 h-4" />
                  <span>{language === 'ar' ? 'عرض جدول برينتوم للفعالية' : 'Open Bryntum Timeline'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleClose();
                    setCurrentView('paypal_escrow');
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 border border-[#003087] text-[#003087] hover:bg-[#003087] hover:text-white text-xs font-semibold uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>{language === 'ar' ? 'إدارة محفظة الضمان' : 'View Escrow Ledger'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
