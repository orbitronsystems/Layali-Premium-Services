import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';
import { X, Plus, FolderPlus, Check, Sparkles, Image as ImageIcon } from 'lucide-react';

export const SaveToCollectionModal: React.FC = () => {
  const { 
    saveTargetPin, 
    closeSaveToCollectionModal, 
    collections, 
    createCollection, 
    savePinToCollection, 
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newBoardName, setNewBoardName] = useState('');
  const [newBoardDesc, setNewBoardDesc] = useState('');

  if (!saveTargetPin) return null;

  const handleCreateAndSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBoardName.trim()) return;
    const newId = createCollection(newBoardName.trim(), newBoardName.trim(), newBoardDesc.trim());
    savePinToCollection(saveTargetPin.id, newId);
    setNewBoardName('');
    setNewBoardDesc('');
    setIsCreatingNew(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div 
        className="bg-[#FAF8F4] w-full max-w-md rounded-2xl shadow-2xl border border-[#E5DFD5] overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="p-5 border-b border-[#E5DFD5] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#B79A66]" />
            <h2 className="font-editorial text-xl font-semibold text-[#242320]">
              {dict.chooseCollectionTitle}
            </h2>
          </div>
          <button
            onClick={closeSaveToCollectionModal}
            className="p-1.5 text-[#77736C] hover:text-[#242320] rounded-full hover:bg-[#FAF8F4] transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Pin Preview summary */}
        <div className="p-4 bg-[#F5F1EA] border-b border-[#E5DFD5] flex items-center gap-3">
          <img
            src={saveTargetPin.imageUrl}
            alt={language === 'ar' ? saveTargetPin.titleAr : saveTargetPin.title}
            className="w-14 h-14 rounded-lg object-cover shadow-sm border border-white shrink-0"
            referrerPolicy="no-referrer"
          />
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-[#242320] truncate">
              {language === 'ar' ? saveTargetPin.titleAr : saveTargetPin.title}
            </p>
            <p className="text-xs text-[#77736C] truncate">
              {language === 'ar' ? saveTargetPin.vendorNameAr : saveTargetPin.vendorName} · {saveTargetPin.vendorCity}
            </p>
          </div>
        </div>

        {/* Existing Collections List */}
        <div className="p-5 max-h-72 overflow-y-auto space-y-2">
          <p className="text-xs uppercase font-semibold tracking-wider text-[#77736C] mb-3">
            {language === 'ar' ? 'اختر اللوحة لحفظ الفكرة' : 'Select a board to save'}
          </p>

          {collections.map((col) => {
            const isAlreadySaved = col.pinIds.includes(saveTargetPin.id);

            return (
              <div
                key={col.id}
                className="flex items-center justify-between p-3 rounded-xl bg-white border border-[#E5DFD5] hover:border-[#B79A66] transition-all group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-lg bg-[#FAF8F4] border border-[#E5DFD5] flex items-center justify-center shrink-0 overflow-hidden">
                    {col.coverImageUrl ? (
                      <img
                        src={col.coverImageUrl}
                        alt=""
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <ImageIcon className="w-4 h-4 text-[#77736C]" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-[#242320] truncate">
                      {language === 'ar' ? col.nameAr : col.name}
                    </p>
                    <p className="text-xs text-[#77736C]">
                      {col.pinIds.length} {language === 'ar' ? 'فكرة محفوظة' : 'saved items'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => savePinToCollection(saveTargetPin.id, col.id)}
                  disabled={isAlreadySaved}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all shrink-0 flex items-center gap-1.5 ${
                    isAlreadySaved
                      ? 'bg-[#F1EDE6] text-[#77736C] cursor-default'
                      : 'bg-[#242320] text-white hover:bg-[#B79A66]'
                  }`}
                >
                  {isAlreadySaved ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>{dict.savedFavorite}</span>
                    </>
                  ) : (
                    <span>{dict.saveFavorite}</span>
                  )}
                </button>
              </div>
            );
          })}
        </div>

        {/* Create New Board Accordion */}
        <div className="p-4 bg-white border-t border-[#E5DFD5]">
          {!isCreatingNew ? (
            <button
              onClick={() => setIsCreatingNew(true)}
              className="w-full py-2.5 px-4 rounded-xl border border-dashed border-[#B79A66] text-[#B79A66] hover:bg-[#FAF8F4] text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>{dict.createCollectionBtn}</span>
            </button>
          ) : (
            <form onSubmit={handleCreateAndSave} className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#242320] flex items-center gap-1.5">
                  <FolderPlus className="w-4 h-4 text-[#B79A66]" />
                  <span>{language === 'ar' ? 'إنشاء لوحة جديدة' : 'Create New Board'}</span>
                </span>
                <button
                  type="button"
                  onClick={() => setIsCreatingNew(false)}
                  className="text-xs text-[#77736C] hover:text-[#242320]"
                >
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>
              </div>

              <input
                type="text"
                required
                value={newBoardName}
                onChange={(e) => setNewBoardName(e.target.value)}
                placeholder={dict.collectionNamePlaceholder}
                className="w-full px-3 py-2 text-sm bg-[#FAF8F4] border border-[#E5DFD5] rounded-lg focus:outline-none focus:border-[#B79A66]"
                autoFocus
              />

              <input
                type="text"
                value={newBoardDesc}
                onChange={(e) => setNewBoardDesc(e.target.value)}
                placeholder={language === 'ar' ? 'وصف مختصر (اختياري)' : 'Brief description (optional)'}
                className="w-full px-3 py-2 text-xs bg-[#FAF8F4] border border-[#E5DFD5] rounded-lg focus:outline-none focus:border-[#B79A66]"
              />

              <div className="flex gap-2 pt-1">
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold uppercase tracking-wider bg-[#242320] text-white hover:bg-[#B79A66] rounded-lg transition-colors"
                >
                  {language === 'ar' ? 'إنشاء وحفظ الفكرة' : 'Create & Save Pin'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
