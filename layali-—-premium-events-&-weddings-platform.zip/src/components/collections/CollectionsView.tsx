import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, getCategoryLabel } from '../../utils/translations';
import { 
  Folder, 
  Plus, 
  Trash2, 
  Edit3, 
  ArrowLeft, 
  Sparkles, 
  Heart, 
  Phone, 
  MessageCircle, 
  ExternalLink,
  Layers,
  ArrowRight
} from 'lucide-react';

export const CollectionsView: React.FC = () => {
  const { 
    collections, 
    pins, 
    activeCollectionId, 
    setActiveCollectionId, 
    createCollection, 
    deleteCollection, 
    renameCollection, 
    removePinFromCollection, 
    setSelectedPinId, 
    openInquiryModal,
    vendors,
    setCurrentView,
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  // Currently opened collection (if drilled down)
  const currentCollection = useMemo(() => {
    return collections.find((c) => c.id === activeCollectionId) || null;
  }, [collections, activeCollectionId]);

  // Pins inside the active collection
  const collectionPins = useMemo(() => {
    if (!currentCollection) return [];
    return pins.filter((p) => currentCollection.pinIds.includes(p.id));
  }, [pins, currentCollection]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const newId = createCollection(newTitle.trim(), newTitle.trim(), newDesc.trim());
    setNewTitle('');
    setNewDesc('');
    setIsCreating(false);
    setActiveCollectionId(newId);
  };

  const handleStartRename = (id: string, currentName: string) => {
    setEditingId(id);
    setEditingTitle(currentName);
  };

  const handleSaveRename = (id: string) => {
    if (editingTitle.trim()) {
      renameCollection(id, editingTitle.trim(), editingTitle.trim());
    }
    setEditingId(null);
  };

  return (
    <section className="py-8 bg-[#FAF8F4] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Navigation & Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E5DFD5]">
          <div>
            {currentCollection ? (
              <div className="space-y-2">
                <button
                  onClick={() => setActiveCollectionId(null)}
                  className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#77736C] hover:text-[#242320] transition-colors"
                >
                  <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
                  <span>{language === 'ar' ? 'العودة لجميع اللوحات' : 'All Saved Collections'}</span>
                </button>
                <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#242320]">
                  {language === 'ar' ? currentCollection.nameAr : currentCollection.name}
                </h1>
                {currentCollection.description && (
                  <p className="text-sm text-[#77736C]">
                    {language === 'ar' ? currentCollection.descriptionAr || currentCollection.description : currentCollection.description}
                  </p>
                )}
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Sparkles className="w-4 h-4 text-[#B79A66]" />
                  <span className="text-[11px] uppercase tracking-widest text-[#B79A66] font-semibold">
                    {dict.navMoodboard}
                  </span>
                </div>
                <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#242320]">
                  {dict.collectionsTitle}
                </h1>
                <p className="text-sm text-[#77736C] mt-1">
                  {dict.collectionsSubtitle}
                </p>
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-3 shrink-0">
            {currentCollection ? (
              <button
                onClick={() => {
                  if (window.confirm(dict.deleteCollectionConfirm)) {
                    deleteCollection(currentCollection.id);
                  }
                }}
                className="px-3.5 py-2 text-xs font-semibold rounded-lg border border-red-200 text-red-600 hover:bg-red-50 flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{language === 'ar' ? 'حذف اللوحة' : 'Delete Board'}</span>
              </button>
            ) : (
              <button
                onClick={() => setIsCreating(true)}
                className="px-4 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#242320] text-white hover:bg-[#B79A66] rounded-lg flex items-center gap-2 transition-colors shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>{dict.createCollectionBtn}</span>
              </button>
            )}
          </div>
        </div>

        {/* Create collection inline modal */}
        {isCreating && (
          <form
            onSubmit={handleCreate}
            className="p-6 bg-white rounded-2xl border border-[#B79A66]/40 shadow-md space-y-4 max-w-xl mx-auto animate-in fade-in"
          >
            <h3 className="font-editorial text-xl font-semibold text-[#242320]">
              {language === 'ar' ? 'إنشاء لوحة إلهام جديدة' : 'Create a New Inspiration Board'}
            </h3>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#77736C] mb-1">
                {language === 'ar' ? 'اسم اللوحة' : 'Board Name'}
              </label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder={dict.collectionNamePlaceholder}
                className="w-full px-4 py-2.5 text-sm bg-[#FAF8F4] border border-[#E5DFD5] rounded-xl focus:outline-none focus:border-[#B79A66]"
                autoFocus
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#77736C] mb-1">
                {language === 'ar' ? 'الوصف (اختياري)' : 'Description (Optional)'}
              </label>
              <input
                type="text"
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder={language === 'ar' ? 'مثال: أفكار إضاءة المسرح وكوشة الفرح' : 'e.g. Lighting, kosha staging, and floral ideas'}
                className="w-full px-4 py-2.5 text-sm bg-[#FAF8F4] border border-[#E5DFD5] rounded-xl focus:outline-none focus:border-[#B79A66]"
              />
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 text-xs font-semibold text-[#77736C] hover:text-[#242320]"
              >
                {language === 'ar' ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-semibold uppercase tracking-wider bg-[#242320] text-white hover:bg-[#B79A66] rounded-xl transition-colors"
              >
                {language === 'ar' ? 'إنشاء اللوحة' : 'Create Board'}
              </button>
            </div>
          </form>
        )}

        {/* VIEW A: DRILLED DOWN INTO A SINGLE COLLECTION */}
        {currentCollection ? (
          <div>
            {collectionPins.length > 0 ? (
              <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-4 space-y-4">
                {collectionPins.map((pin) => (
                  <div
                    key={pin.id}
                    onClick={() => setSelectedPinId(pin.id)}
                    className="break-inside-avoid bg-white rounded-2xl overflow-hidden border border-[#E5DFD5] group cursor-pointer hover:shadow-lg transition-all relative"
                  >
                    <div className="relative overflow-hidden bg-[#E5DFD5]">
                      <img
                        src={pin.imageUrl}
                        alt={language === 'ar' ? pin.titleAr : pin.title}
                        className="w-full h-auto object-cover group-hover:scale-102 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Remove from this board button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          removePinFromCollection(pin.id, currentCollection.id);
                        }}
                        className="absolute top-3 right-3 rtl:right-auto rtl:left-3 p-2 bg-black/60 hover:bg-red-600 text-white rounded-full backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all"
                        title={language === 'ar' ? 'إزالة من اللوحة' : 'Remove from board'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="p-4 space-y-2">
                      <div className="flex items-center justify-between text-[11px] text-[#77736C]">
                        <span className="font-semibold text-[#B79A66] uppercase tracking-wider">
                          {getCategoryLabel(pin.vendorCategory, language)}
                        </span>
                        <span>{pin.vendorCity}</span>
                      </div>
                      
                      <h4 className="text-sm font-semibold text-[#242320] group-hover:text-[#B79A66] transition-colors leading-snug">
                        {language === 'ar' ? pin.titleAr : pin.title}
                      </h4>

                      <div className="pt-2 border-t border-[#F1EDE6] flex items-center justify-between text-xs text-[#77736C]">
                        <span className="font-medium text-[#242320] truncate">
                          {language === 'ar' ? pin.vendorNameAr : pin.vendorName}
                        </span>
                        <div className="flex items-center gap-2">
                          <a
                            href={`https://wa.me/${pin.vendorWhatsapp}?text=${encodeURIComponent('Hello, I saw your work on Layali and would like to inquire about pricing.')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-[#25D366] hover:opacity-80 p-1"
                            title={dict.whatsappVendor}
                          >
                            <MessageCircle className="w-4 h-4 fill-current" />
                          </a>
                          <a
                            href={`tel:${pin.vendorPhone}`}
                            onClick={(e) => e.stopPropagation()}
                            className="text-[#242320] hover:text-[#B79A66] p-1"
                            title={dict.callVendor}
                          >
                            <Phone className="w-4 h-4" />
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center bg-white rounded-2xl border border-dashed border-[#E5DFD5] space-y-3">
                <Folder className="w-10 h-10 text-[#B79A66] mx-auto opacity-60" />
                <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                  {dict.noPinsInCollection}
                </h3>
                <p className="text-sm text-[#77736C] max-w-md mx-auto">
                  {language === 'ar'
                    ? 'تصفح صور الأفراح والمناسبات واضغط على "حفظ" لإضافتها إلى هذه اللوحة.'
                    : 'Explore event inspiration and click "Save" on any visual to add it to this board.'}
                </p>
                <button
                  onClick={() => setCurrentView('home')}
                  className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#242320] text-white hover:bg-[#B79A66] rounded-xl transition-colors inline-block mt-2"
                >
                  {language === 'ar' ? 'تصفح الإلهام الآن' : 'Explore Visual Inspiration'}
                </button>
              </div>
            )}
          </div>
        ) : (
          /* VIEW B: ALL COLLECTIONS GRID */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {collections.map((col) => {
              const coverPin = pins.find((p) => p.id === col.pinIds[0]);
              const coverUrl = col.coverImageUrl || coverPin?.imageUrl;

              return (
                <div
                  key={col.id}
                  onClick={() => setActiveCollectionId(col.id)}
                  className="bg-white rounded-2xl overflow-hidden border border-[#E5DFD5] group cursor-pointer hover:shadow-xl hover:border-[#B79A66]/50 transition-all flex flex-col"
                >
                  {/* Visual Preview Banner */}
                  <div className="relative h-48 bg-[#F1EDE6] overflow-hidden">
                    {coverUrl ? (
                      <img
                        src={coverUrl}
                        alt=""
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[#77736C]">
                        <Layers className="w-8 h-8 opacity-40" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    
                    {/* Item count badge */}
                    <div className="absolute bottom-3 left-3 rtl:left-auto rtl:right-3 px-3 py-1 bg-black/50 backdrop-blur-md rounded-full text-white text-xs font-medium">
                      {col.pinIds.length} {language === 'ar' ? 'فكرة محفوظة' : 'saved items'}
                    </div>
                  </div>

                  {/* Metadata */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {editingId === col.id ? (
                        <div
                          onClick={(e) => e.stopPropagation()}
                          className="flex items-center gap-2 mb-2"
                        >
                          <input
                            type="text"
                            value={editingTitle}
                            onChange={(e) => setEditingTitle(e.target.value)}
                            className="flex-1 px-2.5 py-1 text-sm border border-[#B79A66] rounded focus:outline-none"
                            autoFocus
                          />
                          <button
                            onClick={() => handleSaveRename(col.id)}
                            className="px-3 py-1 text-xs bg-[#242320] text-white rounded font-semibold"
                          >
                            OK
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <h3 className="font-editorial text-2xl font-semibold text-[#242320] group-hover:text-[#B79A66] transition-colors truncate">
                            {language === 'ar' ? col.nameAr : col.name}
                          </h3>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleStartRename(col.id, language === 'ar' ? col.nameAr : col.name);
                            }}
                            className="text-[#77736C] hover:text-[#242320] p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            title={language === 'ar' ? 'تعديل الاسم' : 'Rename'}
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}

                      <p className="text-xs text-[#77736C] line-clamp-2 mt-1">
                        {language === 'ar' ? col.descriptionAr || col.description : col.description}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-[#F1EDE6] mt-4 flex items-center justify-between text-xs text-[#B79A66] font-semibold uppercase tracking-wider">
                      <span>{language === 'ar' ? 'فتح اللوحة' : 'Open Board'}</span>
                      <ArrowRight className="w-4 h-4 rtl:rotate-180 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
