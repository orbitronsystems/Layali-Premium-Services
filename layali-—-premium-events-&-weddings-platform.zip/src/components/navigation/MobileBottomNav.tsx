import React from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS } from '../../utils/translations';
import { Compass, FolderHeart, Calendar, Sparkles } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { 
    currentView, 
    setCurrentView, 
    feedViewMode, 
    setFeedViewMode, 
    likedPinIds, 
    collections,
    setIsOnboardingModalOpen,
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];
  const totalSaved = likedPinIds.length;

  return (
    <nav 
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF8F4]/95 backdrop-blur-md border-t border-[#E5DFD5] px-4 py-2 safe-area-bottom"
      aria-label="Mobile Navigation"
    >
      <div className="flex items-center justify-around max-w-md mx-auto">
        {/* 1. Feed / Discover */}
        <button
          onClick={() => {
            setFeedViewMode('pins');
            setCurrentView('home');
          }}
          className={`flex flex-col items-center gap-1 py-1 px-3 text-[11px] font-medium transition-colors ${
            currentView === 'home' && feedViewMode === 'pins'
              ? 'text-[#242320] font-semibold'
              : 'text-[#77736C] hover:text-[#242320]'
          }`}
        >
          <Compass className="w-5 h-5" />
          <span>{dict.navDiscover}</span>
        </button>

        {/* 2. Tailor / Onboard */}
        <button
          onClick={() => setIsOnboardingModalOpen(true)}
          className="flex flex-col items-center gap-1 py-1 px-3 text-[11px] font-medium text-[#77736C] hover:text-[#B79A66] transition-colors"
        >
          <Sparkles className="w-5 h-5 text-[#B79A66]" />
          <span>{language === 'ar' ? 'تخصيص' : 'Tailor'}</span>
        </button>

        {/* 3. Saved Boards */}
        <button
          onClick={() => setCurrentView('collections')}
          className={`flex flex-col items-center gap-1 py-1 px-3 text-[11px] font-medium transition-colors relative ${
            currentView === 'collections'
              ? 'text-[#242320] font-semibold'
              : 'text-[#77736C] hover:text-[#242320]'
          }`}
        >
          <div className="relative">
            <FolderHeart className="w-5 h-5" />
            {totalSaved > 0 && (
              <span className="absolute -top-1 -right-2 w-4 h-4 rounded-full bg-[#B79A66] text-[#242320] text-[9px] font-bold flex items-center justify-center">
                {totalSaved}
              </span>
            )}
          </div>
          <span>{dict.navMoodboard}</span>
        </button>

        {/* 4. Planning Workspace */}
        <button
          onClick={() => setCurrentView('workspace')}
          className={`flex flex-col items-center gap-1 py-1 px-3 text-[11px] font-medium transition-colors ${
            currentView === 'workspace' || currentView === 'inquiries'
              ? 'text-[#242320] font-semibold'
              : 'text-[#77736C] hover:text-[#242320]'
          }`}
        >
          <Calendar className="w-5 h-5" />
          <span>{dict.navWorkspace}</span>
        </button>
      </div>
    </nav>
  );
};
