import React from 'react';
import { useApp } from '../../context/AppContext';
import { TRANSLATIONS, formatEgp, getCategoryLabel } from '../../utils/translations';
import { 
  X, 
  Heart, 
  Phone, 
  Mail, 
  MessageCircle, 
  MapPin, 
  CheckCircle2, 
  ArrowRight, 
  Calendar, 
  Share2,
  Sparkles,
  FolderPlus
} from 'lucide-react';

export const PinDetailModal: React.FC = () => {
  const { 
    selectedPin, 
    setSelectedPinId, 
    likedPinIds, 
    toggleLikePin, 
    vendors, 
    setSelectedVendorId, 
    openInquiryModal, 
    openSaveToCollectionModal,
    openCategoryPage,
    setFeedCategoryFilter,
    language,
    showToast,
    openPayPalModal 
  } = useApp();

  if (!selectedPin) return null;

  const dict = TRANSLATIONS[language];
  const isLiked = likedPinIds.includes(selectedPin.id);

  // Find full vendor object if available
  const fullVendor = vendors.find((v) => v.id === selectedPin.vendorId);
  const vendorPhone = fullVendor?.phone || selectedPin.vendorPhone;
  const vendorEmail = fullVendor?.email || selectedPin.vendorEmail;
  const vendorWhatsapp = fullVendor?.whatsapp || selectedPin.vendorWhatsapp;

  const handleSeeAllInCat = () => {
    openCategoryPage(selectedPin.vendorCategory);
    setSelectedPinId(null);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast(language === 'ar' ? 'تم نسخ رابط الإلهام للمشاركة' : 'Inspiration link copied to clipboard');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div 
        role="dialog"
        aria-modal="true"
        aria-labelledby="pin-detail-title"
        className="bg-[#FAF8F4] w-full max-w-5xl rounded-2xl shadow-2xl border border-[#E5DFD5] overflow-hidden my-auto max-h-[94vh] flex flex-col md:flex-row"
      >
        {/* Left Column: Visual Showcase (Pinterest High-Res Picture) */}
        <div className="md:w-7/12 bg-[#1A1A18] relative flex items-center justify-center p-4 min-h-[380px] md:min-h-[580px]">
          <img
            src={selectedPin.imageUrl}
            alt={language === 'ar' ? selectedPin.titleAr : selectedPin.title}
            className="w-full h-full max-h-[82vh] object-contain rounded-lg"
            referrerPolicy="no-referrer"
          />

          {/* Quick Floating Action on Photo */}
          <div className="absolute top-4 left-4 rtl:left-auto rtl:right-4 flex items-center gap-2">
            <button
              onClick={() => openSaveToCollectionModal(selectedPin)}
              className="p-2.5 rounded-full bg-black/50 hover:bg-[#B79A66] text-white backdrop-blur-md transition-colors shadow-md"
              title={dict.saveToBoard}
            >
              <FolderPlus className="w-5 h-5" />
            </button>
            <button
              onClick={() => toggleLikePin(selectedPin.id)}
              className={`p-2.5 rounded-full backdrop-blur-md transition-all shadow-md ${
                isLiked 
                  ? 'bg-[#B79A66] text-[#242320]' 
                  : 'bg-black/50 text-white hover:bg-black/80'
              }`}
              title={dict.saveFavorite}
            >
              <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
            </button>
            <button
              onClick={handleShare}
              className="p-2.5 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md transition-colors shadow-md"
              title="Share"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Column: Pin Details & Direct Vendor Contact Card */}
        <div className="md:w-5/12 bg-[#FFFFFF] p-6 sm:p-8 flex flex-col justify-between overflow-y-auto max-h-[94vh] space-y-6">
          {/* Header Bar */}
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#F1EDE6]">
              <div className="flex items-center gap-2 text-xs">
                <span className="text-[11px] uppercase tracking-widest text-[#B79A66] font-semibold">
                  {getCategoryLabel(selectedPin.vendorCategory, language)}
                </span>
                <span>·</span>
                <span className="text-[#77736C]">
                  {language === 'ar' ? selectedPin.vendorCityAr : selectedPin.vendorCity}
                </span>
              </div>

              <button
                onClick={() => setSelectedPinId(null)}
                className="p-1.5 text-[#77736C] hover:text-[#242320] transition-colors rounded-full hover:bg-[#FAF8F4]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Pin Title & Story */}
            <div className="pt-4 space-y-3">
              <h2 id="pin-detail-title" className="font-editorial text-2xl sm:text-3xl font-semibold text-[#242320] leading-snug">
                {language === 'ar' ? selectedPin.titleAr : selectedPin.title}
              </h2>

              <p className="text-xs sm:text-sm text-[#77736C] leading-relaxed">
                {language === 'ar' ? selectedPin.descriptionAr : selectedPin.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {selectedPin.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] text-[#B79A66] font-medium hover:underline cursor-pointer"
                    onClick={() => {
                      setFeedCategoryFilter(selectedPin.vendorCategory);
                      setSelectedPinId(null);
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* VENDOR DIRECT CONTACT CARD (Core feature requested by client!) */}
          <div className="p-5 rounded-xl border border-[#E5DFD5] bg-[#FAF8F4] space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-[10px] uppercase tracking-widest text-[#B79A66] font-semibold block mb-0.5">
                  {language === 'ar' ? 'الجهة المنفذة لهذا العمل' : 'Creator & Service Provider'}
                </span>
                <h3 className="font-editorial text-xl font-semibold text-[#242320]">
                  {language === 'ar' ? selectedPin.vendorNameAr : selectedPin.vendorName}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-[#2E6B4F] mt-0.5 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{language === 'ar' ? 'مورد معتمد رسمياً في مصر' : 'Verified Egyptian Partner'}</span>
                </div>
              </div>

              <div className="text-right rtl:text-left text-xs">
                <span className="text-[10px] text-[#77736C] block">{dict.startingFrom}</span>
                <span className="font-semibold text-sm text-[#242320] tabular-nums">
                  {formatEgp(selectedPin.vendorStartingPriceEgp, language)}
                </span>
              </div>
            </div>

            {/* DIRECT DIAL & WHATSAPP BUTTONS */}
            <div className="pt-2 grid grid-cols-2 gap-2 text-xs">
              {/* Direct Phone Dial */}
              <a
                href={`tel:${vendorPhone.replace(/\s+/g, '')}`}
                className="py-2.5 px-3 bg-[#FFFFFF] border border-[#E5DFD5] hover:border-[#242320] text-[#242320] rounded-lg font-semibold flex items-center justify-center gap-2 transition-all shadow-xs"
              >
                <Phone className="w-4 h-4 text-[#B79A66]" />
                <span className="truncate">{vendorPhone}</span>
              </a>

              {/* Direct WhatsApp Chat */}
              <a
                href={`https://wa.me/${vendorWhatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                  language === 'ar'
                    ? `مرحباً، أود الاستفسار عن باقات وأسعار ${selectedPin.titleAr} المعروضة في منصة ليالي.`
                    : `Hello, I am interested in your services for ${selectedPin.title} seen on Layali.`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="py-2.5 px-3 bg-[#2E6B4F] hover:bg-[#255740] text-white rounded-lg font-semibold flex items-center justify-center gap-2 transition-all shadow-xs"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{language === 'ar' ? 'واتساب مباشر' : 'WhatsApp'}</span>
              </a>
            </div>

            {/* Direct Email */}
            <div className="pt-1">
              <a
                href={`mailto:${vendorEmail}?subject=${encodeURIComponent(selectedPin.title)}`}
                className="text-xs text-[#77736C] hover:text-[#242320] flex items-center gap-2 hover:underline"
              >
                <Mail className="w-3.5 h-3.5 text-[#B79A66]" />
                <span>{vendorEmail}</span>
              </a>
            </div>

            {/* Cross-Redirection: "See all belly dancers" or "See all lighting vendors" */}
            <div className="pt-2 border-t border-[#E5DFD5]">
              <button
                onClick={handleSeeAllInCat}
                className="w-full text-xs text-[#B79A66] hover:text-[#A38652] font-semibold flex items-center justify-between py-1 transition-colors group"
              >
                <span>
                  {dict.seeAllInCat} {getCategoryLabel(selectedPin.vendorCategory, language)}
                </span>
                <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Action Row */}
          <div className="pt-2 flex flex-wrap items-center gap-2">
            {fullVendor && (
              <button
                onClick={() => {
                  const v = fullVendor;
                  setSelectedPinId(null);
                  openPayPalModal({
                    vendor: v,
                    quoteAmountEgp: v.startingPriceEgp,
                    depositAmountEgp: Math.round(v.startingPriceEgp * 0.20)
                  });
                }}
                className="w-full py-2.5 px-3 bg-[#FFC439] hover:bg-[#F2BA36] text-[#003087] rounded-lg text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <span className="font-extrabold italic text-sm">PP</span>
                <span>{language === 'ar' ? 'حجز العربون فوراً عبر باي بال' : 'Book with PayPal Escrow Deposit'}</span>
              </button>
            )}

            {fullVendor && (
              <button
                onClick={() => {
                  setSelectedPinId(null);
                  setSelectedVendorId(fullVendor.id);
                }}
                className="flex-1 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#242320] border border-[#242320] hover:bg-[#242320] hover:text-white rounded-lg transition-colors"
              >
                {dict.viewProfile}
              </button>
            )}

            <button
              onClick={() => {
                if (fullVendor) {
                  setSelectedPinId(null);
                  openInquiryModal(fullVendor);
                }
              }}
              className="flex-1 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] rounded-lg transition-colors shadow-xs"
            >
              {dict.requestQuote}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
