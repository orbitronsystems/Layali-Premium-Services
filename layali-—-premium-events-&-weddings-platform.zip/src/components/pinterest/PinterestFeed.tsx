import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { VendorCategory, PinItem } from '../../types';
import { TRANSLATIONS, formatEgp, getCategoryLabel } from '../../utils/translations';
import { 
  Heart, 
  Phone, 
  MessageCircle, 
  Mail, 
  MapPin, 
  Search, 
  Sparkles, 
  Grid, 
  Users, 
  Layers,
  CheckCircle2,
  ArrowRight,
  FolderPlus
} from 'lucide-react';
import { PersonalizedFeedBanner } from '../onboarding/PersonalizedFeedBanner';
import { SearchWithSuggestions } from '../search/SearchWithSuggestions';

export const PinterestFeed: React.FC = () => {
  const { 
    pins, 
    vendors, 
    likedPinIds, 
    toggleLikePin, 
    setSelectedPinId, 
    setSelectedVendorId, 
    openInquiryModal, 
    openSaveToCollectionModal,
    feedCategoryFilter, 
    setFeedCategoryFilter, 
    feedViewMode, 
    setFeedViewMode, 
    onboarding,
    language 
  } = useApp();

  const dict = TRANSLATIONS[language];
  const [searchQuery, setSearchQuery] = useState('');

  // Categories requested specifically by client
  const categoryFilters: { id: VendorCategory | 'all'; label: string }[] = [
    { id: 'all', label: dict.categoryAll },
    { id: 'lighting_fx', label: dict.catLighting },
    { id: 'venues', label: dict.catVenues },
    { id: 'wedding_planners', label: dict.catPlanners },
    { id: 'belly_dancers', label: dict.catBellyDancers },
    { id: 'hosting_ushers', label: dict.catHosting },
    { id: 'event_management', label: dict.catEventManagement },
    { id: 'photography', label: dict.catPhoto },
    { id: 'floral_decor', label: dict.catFloral },
    { id: 'catering', label: dict.catCatering }
  ];

  // Filter Pins
  const filteredPins = useMemo(() => {
    return pins.filter((pin) => {
      // Moodboard filter
      if (feedViewMode === 'moodboard' && !likedPinIds.includes(pin.id)) {
        return false;
      }
      // Onboarding personalization
      if (onboarding && onboarding.isActive && feedCategoryFilter === 'all') {
        const matchesType = pin.eventTypes?.includes(onboarding.eventType);
        const matchesCat = onboarding.categories?.includes(pin.vendorCategory);
        if (!matchesType && !matchesCat) return false;
      }
      // Category filter
      if (feedCategoryFilter !== 'all' && pin.vendorCategory !== feedCategoryFilter) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = pin.title.toLowerCase().includes(q) || pin.titleAr.includes(q);
        const matchVendor = pin.vendorName.toLowerCase().includes(q) || pin.vendorNameAr.includes(q);
        const matchTags = pin.tags.some((t) => t.toLowerCase().includes(q));
        if (!matchTitle && !matchVendor && !matchTags) return false;
      }
      return true;
    });
  }, [pins, feedCategoryFilter, feedViewMode, likedPinIds, searchQuery, onboarding]);

  // Filter Vendors for the "All Vendors in Category" tab
  const filteredVendors = useMemo(() => {
    return vendors.filter((v) => {
      if (v.status !== 'active') return false;
      if (feedCategoryFilter !== 'all' && v.category !== feedCategoryFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = v.name.toLowerCase().includes(q) || v.nameAr.includes(q);
        const matchDesc = v.description.toLowerCase().includes(q) || v.descriptionAr.includes(q);
        if (!matchName && !matchDesc) return false;
      }
      return true;
    });
  }, [vendors, feedCategoryFilter, searchQuery]);

  return (
    <section className="py-8 bg-[#FAF8F4] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Personalized Feed Banner (If active onboarding) */}
        <PersonalizedFeedBanner />

        {/* Editorial Sub-Header & Search Bar */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-4 border-b border-[#E5DFD5]">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4 text-[#B79A66]" />
              <span className="text-[11px] uppercase tracking-widest text-[#B79A66] font-semibold">
                {language === 'ar' ? 'معرض الإلهام البصري الفاخر' : 'Luxury Visual Inspiration Feed'}
              </span>
            </div>
            <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#242320]">
              {feedViewMode === 'moodboard'
                ? (language === 'ar' ? 'لوحة إلهامي المفضلة' : 'My Curated Moodboard')
                : (language === 'ar' ? 'استكشف ألبومات وأعمال الموردين في مصر' : 'Browse Vendor Works & Portfolios')}
            </h1>
            <p className="text-xs text-[#77736C] mt-1">
              {language === 'ar'
                ? 'انقر على أي صورة لمعاينة التفاصيل وبيانات الاتصال المباشر بالمورد (الهاتف، واتساب، البريد).'
                : 'Click any visual to inspect details and get the direct phone dialer, WhatsApp, and vendor info.'}
            </p>
          </div>

          {/* View Mode Toggle: Pins vs All Vendors vs My Moodboard */}
          <div className="flex items-center bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] p-1 text-xs shrink-0">
            <button
              onClick={() => setFeedViewMode('pins')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
                feedViewMode === 'pins'
                  ? 'bg-[#242320] text-white shadow-xs'
                  : 'text-[#77736C] hover:text-[#242320]'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              <span>{dict.viewModePins}</span>
            </button>

            <button
              onClick={() => setFeedViewMode('vendors')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
                feedViewMode === 'vendors'
                  ? 'bg-[#242320] text-white shadow-xs'
                  : 'text-[#77736C] hover:text-[#242320]'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{dict.viewModeVendors} ({filteredVendors.length})</span>
            </button>

            <button
              onClick={() => setFeedViewMode('moodboard')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
                feedViewMode === 'moodboard'
                  ? 'bg-[#B79A66] text-[#242320] shadow-xs'
                  : 'text-[#77736C] hover:text-[#242320]'
              }`}
            >
              <Heart className="w-3.5 h-3.5 fill-current" />
              <span>{dict.viewModeMoodboard} ({likedPinIds.length})</span>
            </button>
          </div>
        </div>

        {/* Guided Search with Popular Suggestions & Category Filter Ribbon */}
        <div className="space-y-4">
          <div className="max-w-xl">
            <SearchWithSuggestions
              value={searchQuery}
              onChange={setSearchQuery}
              placeholder={dict.searchPlaceholder}
            />
          </div>

          {/* Category Reference Buttons (Client's exact categories) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {categoryFilters.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setFeedCategoryFilter(cat.id)}
                className={`px-3.5 py-2 text-xs font-medium rounded-full transition-all whitespace-nowrap shrink-0 border ${
                  feedCategoryFilter === cat.id
                    ? 'bg-[#242320] text-white border-[#242320] shadow-sm'
                    : 'bg-[#FFFFFF] text-[#77736C] border-[#E5DFD5] hover:border-[#242320] hover:text-[#242320]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Dynamic Result Count */}
        <div className="flex items-center justify-between text-xs text-[#77736C] pt-1">
          <span>
            {feedViewMode === 'vendors' 
              ? `${filteredVendors.length} ${language === 'ar' ? 'مورد معتمد متاح' : 'verified vendors available'}`
              : `${filteredPins.length} ${language === 'ar' ? 'صورة إلهام بصري' : 'inspiration pins available'}`}
          </span>

          {feedCategoryFilter !== 'all' && (
            <button
              onClick={() => setFeedCategoryFilter('all')}
              className="text-[#B79A66] hover:underline"
            >
              {dict.clearFilters}
            </button>
          )}
        </div>

        {/* VIEW 1 & 3: PINTEREST MASONRY GRID (Visual Feed & Moodboard) */}
        {(feedViewMode === 'pins' || feedViewMode === 'moodboard') && (
          <div>
            {filteredPins.length > 0 ? (
              <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-4 space-y-4">
                {filteredPins.map((pin) => {
                  const isLiked = likedPinIds.includes(pin.id);

                  return (
                    <div
                      key={pin.id}
                      onClick={() => setSelectedPinId(pin.id)}
                      className="break-inside-avoid bg-[#FFFFFF] rounded-2xl overflow-hidden border border-[#E5DFD5] group cursor-pointer hover:shadow-lg transition-all duration-300 relative"
                    >
                      {/* Image Container with subtle zoom */}
                      <div className="relative overflow-hidden bg-[#E5DFD5]">
                        <img
                          src={pin.imageUrl}
                          alt={language === 'ar' ? pin.titleAr : pin.title}
                          className="w-full h-auto object-cover group-hover:scale-103 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />

                        {/* Top Overlay: Like / Save to Board */}
                        <div className="absolute top-3 right-3 rtl:right-auto rtl:left-3 z-10 flex items-center gap-1.5">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              openSaveToCollectionModal(pin);
                            }}
                            className="p-2 rounded-full bg-black/40 hover:bg-[#B79A66] text-white backdrop-blur-md transition-all shadow-md opacity-90 group-hover:opacity-100"
                            title={dict.saveToBoard}
                          >
                            <FolderPlus className="w-4 h-4" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleLikePin(pin.id);
                            }}
                            className={`p-2 rounded-full backdrop-blur-md transition-all shadow-md ${
                              isLiked
                                ? 'bg-[#B79A66] text-[#242320]'
                                : 'bg-black/40 text-white hover:bg-black/70 opacity-90 group-hover:opacity-100'
                            }`}
                            title={isLiked ? dict.savedFavorite : dict.saveFavorite}
                          >
                            <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                          </button>
                        </div>

                        {/* Bottom Gradient overlay on hover */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                          <span className="text-white text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
                            <span>{language === 'ar' ? 'معاينة تفاصيل المورد' : 'View Vendor & Contact'}</span>
                            <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
                          </span>
                        </div>
                      </div>

                      {/* Pin Info Below Image */}
                      <div className="p-4 space-y-2">
                        <div className="flex items-center justify-between text-[11px] text-[#77736C]">
                          <span className="font-semibold text-[#B79A66] uppercase tracking-wider">
                            {getCategoryLabel(pin.vendorCategory, language)}
                          </span>
                          <span>{language === 'ar' ? pin.vendorCityAr : pin.vendorCity}</span>
                        </div>

                        <h3 className="font-editorial text-lg font-semibold text-[#242320] leading-snug group-hover:text-[#B79A66] transition-colors line-clamp-2">
                          {language === 'ar' ? pin.titleAr : pin.title}
                        </h3>

                        {/* Vendor Attribution & Dial Action */}
                        <div className="pt-2 flex items-center justify-between border-t border-[#F1EDE6] text-xs">
                          <span className="text-[#242320] font-medium truncate max-w-[150px]">
                            {language === 'ar' ? pin.vendorNameAr : pin.vendorName}
                          </span>

                          <span className="text-[11px] text-[#77736C] tabular-nums">
                            {formatEgp(pin.vendorStartingPriceEgp, language)}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-16 text-center bg-[#FFFFFF] rounded-2xl border border-[#E5DFD5] space-y-3">
                <Heart className="w-8 h-8 text-[#B79A66] mx-auto opacity-40" />
                <p className="text-sm text-[#77736C]">{dict.emptyResults}</p>
                {feedViewMode === 'moodboard' && (
                  <button
                    onClick={() => setFeedViewMode('pins')}
                    className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] rounded hover:bg-[#B79A66] transition-colors"
                  >
                    {language === 'ar' ? 'تصفح وأضف لقطات لإلهامك' : 'Explore and Save Pins'}
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* VIEW 2: ALL VENDORS IN CATEGORY (The exact redirection requested by client!) */}
        {feedViewMode === 'vendors' && (
          <div className="space-y-6">
            <div className="p-4 bg-[#FFFFFF] rounded-xl border border-[#E5DFD5] flex items-center justify-between">
              <div>
                <span className="text-xs uppercase tracking-widest text-[#B79A66] font-semibold block mb-0.5">
                  {language === 'ar' ? 'دليل الموردين المعتمدين' : 'Verified Partner Network'}
                </span>
                <h2 className="font-editorial text-2xl font-semibold text-[#242320]">
                  {feedCategoryFilter === 'all'
                    ? (language === 'ar' ? 'كافة الشركات ومقدمي الخدمات في مصر' : 'All Egyptian Event Artisans & Firms')
                    : `${dict.seeAllInCat} ${getCategoryLabel(feedCategoryFilter as VendorCategory, language)}`}
                </h2>
              </div>
            </div>

            {filteredVendors.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredVendors.map((vendor) => (
                  <div
                    key={vendor.id}
                    className="bg-[#FFFFFF] rounded-2xl border border-[#E5DFD5] overflow-hidden flex flex-col justify-between group hover:shadow-md transition-all"
                  >
                    <div>
                      {/* Cover Photo */}
                      <div 
                        onClick={() => setSelectedVendorId(vendor.id)}
                        className="relative aspect-[16/10] bg-[#E5DFD5] overflow-hidden cursor-pointer"
                      >
                        <img
                          src={vendor.coverImage}
                          alt={language === 'ar' ? vendor.nameAr : vendor.name}
                          className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-3 left-3 rtl:left-auto rtl:right-3 bg-black/60 backdrop-blur-md text-white text-[10px] uppercase tracking-wider font-semibold px-2.5 py-1 rounded">
                          {getCategoryLabel(vendor.category, language)}
                        </div>
                        <div className="absolute bottom-3 left-3 rtl:left-auto rtl:right-3 bg-[#242320]/80 backdrop-blur-md text-white text-xs px-2.5 py-1 rounded">
                          {dict.startingFrom} {formatEgp(vendor.startingPriceEgp, language)}
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-5 space-y-3">
                        <div className="flex items-center gap-1.5 text-xs text-[#77736C]">
                          <MapPin className="w-3.5 h-3.5 text-[#B79A66]" />
                          <span>{language === 'ar' ? vendor.neighborhoodAr : vendor.neighborhood}</span>
                        </div>

                        <h3 
                          onClick={() => setSelectedVendorId(vendor.id)}
                          className="font-editorial text-xl font-semibold text-[#242320] hover:text-[#B79A66] transition-colors cursor-pointer"
                        >
                          {language === 'ar' ? vendor.nameAr : vendor.name}
                        </h3>

                        <p className="text-xs text-[#77736C] line-clamp-2 leading-relaxed">
                          {language === 'ar' ? vendor.descriptionAr : vendor.description}
                        </p>

                        {/* DIRECT DIAL & WHATSAPP BUTTONS (Requested by client) */}
                        <div className="pt-2 grid grid-cols-2 gap-2 text-xs border-t border-[#F1EDE6]">
                          <a
                            href={`tel:${vendor.phone.replace(/\s+/g, '')}`}
                            className="py-2 px-3 border border-[#E5DFD5] hover:border-[#242320] text-[#242320] rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-colors bg-[#FAF8F4]"
                          >
                            <Phone className="w-3.5 h-3.5 text-[#B79A66]" />
                            <span className="truncate">{vendor.phone}</span>
                          </a>

                          <a
                            href={`https://wa.me/${vendor.whatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                              language === 'ar'
                                ? `مرحباً، أود الاستفسار عن خدمات وحجوزات ${vendor.nameAr} المعروضة في منصة ليالي.`
                                : `Hello, I would like to inquire about services for ${vendor.name} seen on Layali.`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="py-2 px-3 bg-[#2E6B4F] hover:bg-[#255740] text-white rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-colors"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>{language === 'ar' ? 'واتساب' : 'WhatsApp'}</span>
                          </a>
                        </div>
                      </div>
                    </div>

                    {/* Card Actions */}
                    <div className="p-5 pt-0 grid grid-cols-2 gap-2">
                      <button
                        onClick={() => setSelectedVendorId(vendor.id)}
                        className="w-full py-2 text-xs font-medium border border-[#E5DFD5] hover:border-[#242320] rounded-lg text-[#242320] transition-colors"
                      >
                        {dict.viewProfile}
                      </button>

                      <button
                        onClick={() => openInquiryModal(vendor)}
                        className="w-full py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#242320] hover:bg-[#B79A66] rounded-lg transition-colors shadow-xs"
                      >
                        {dict.requestQuote}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-16 text-center bg-[#FFFFFF] rounded-2xl border border-[#E5DFD5] text-xs text-[#77736C]">
                {dict.emptyResults}
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
